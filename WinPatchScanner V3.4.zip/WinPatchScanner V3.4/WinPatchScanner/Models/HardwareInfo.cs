namespace WinPatchScanner.Models
{
    /// <summary>System-level hardware configuration - one row per machine, backing the
    /// Hardware tab's overview panel and its exported reports.</summary>
    public class HardwareInfo
    {
        public string Manufacturer { get; set; } = "";
        public string Model { get; set; } = "";
        public string SystemSerialNumber { get; set; } = "";
        public string ChassisType { get; set; } = "";

        public string BiosManufacturer { get; set; } = "";
        public string BiosVersion { get; set; } = "";
        public string BiosReleaseDate { get; set; } = "";
        public string BiosSerialNumber { get; set; } = "";

        public string MotherboardManufacturer { get; set; } = "";
        public string MotherboardProduct { get; set; } = "";
        public string MotherboardSerialNumber { get; set; } = "";

        public string CpuName { get; set; } = "";
        public string CpuManufacturer { get; set; } = "";
        public int CpuCores { get; set; }
        public int CpuLogicalProcessors { get; set; }
        public double CpuMaxClockMHz { get; set; }

        public double TotalRamGB { get; set; }
        public int MemoryModuleCount { get; set; }

        public int DiskCount { get; set; }
        public double TotalDiskGB { get; set; }

        // Warranty - filled in separately by WarrantyLookupService, since it needs a
        // network call and (for most OEMs) isn't available at all without an API key.
        public string WarrantyStatus { get; set; } = "Not checked";
        public string WarrantyEndDate { get; set; } = "";
        public string WarrantyProvider { get; set; } = "";
        public string WarrantyCheckUrl { get; set; } = "";
        public string WarrantyNote { get; set; } = "";

        /// <summary>The serial number to use for a warranty lookup - the system/service-tag
        /// serial when present, falling back to the BIOS serial (the two are usually the
        /// same number on OEM desktops/laptops).</summary>
        public string WarrantySerialNumber =>
            !string.IsNullOrWhiteSpace(SystemSerialNumber) && SystemSerialNumber != "0"
                ? SystemSerialNumber
                : BiosSerialNumber;
    }
}
