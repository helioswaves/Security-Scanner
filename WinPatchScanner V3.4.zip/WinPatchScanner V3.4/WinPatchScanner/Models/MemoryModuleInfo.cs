namespace WinPatchScanner.Models
{
    /// <summary>One installed RAM stick (one Win32_PhysicalMemory row), for the
    /// Hardware tab's memory grid.</summary>
    public class MemoryModuleInfo
    {
        public string DeviceLocator { get; set; } = "";
        public string Manufacturer { get; set; } = "";
        public string PartNumber { get; set; } = "";
        public string SerialNumber { get; set; } = "";
        public double CapacityGB { get; set; }
        public double SpeedMHz { get; set; }
        public string FormFactor { get; set; } = "";
        public string MemoryType { get; set; } = "";
    }
}
