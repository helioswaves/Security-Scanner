namespace WinPatchScanner.Models
{
    /// <summary>One physical disk (one Win32_DiskDrive row), for the Hardware tab's
    /// disk grid.</summary>
    public class DiskDriveInfo
    {
        public string Model { get; set; } = "";
        public string InterfaceType { get; set; } = "";
        public string MediaType { get; set; } = "";
        public double SizeGB { get; set; }
        public string SerialNumber { get; set; } = "";
        public string FirmwareRevision { get; set; } = "";
    }
}
