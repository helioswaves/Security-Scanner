using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using WinPatchScanner.Models;

namespace WinPatchScanner.Services
{
    /// <summary>CSV export for the Hardware tab: system/BIOS/board/CPU overview,
    /// warranty status, then every memory module and disk drive.</summary>
    public static class HardwareCsvBuilder
    {
        public static string Build(string hostname, HardwareInfo info, List<MemoryModuleInfo> memory,
            List<DiskDriveInfo> disks, DateTime scanTime)
        {
            var sb = new StringBuilder();
            sb.AppendLine(Csv("Report", "Hardware Configuration"));
            sb.AppendLine(Csv("Host", hostname));
            sb.AppendLine(Csv("Scan Time", scanTime.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture)));
            sb.AppendLine();

            sb.AppendLine(Csv("System", ""));
            sb.AppendLine(Csv("Manufacturer (OEM)", info.Manufacturer));
            sb.AppendLine(Csv("Model", info.Model));
            sb.AppendLine(Csv("Chassis Type", info.ChassisType));
            sb.AppendLine(Csv("System Serial Number", info.SystemSerialNumber));
            sb.AppendLine();

            sb.AppendLine(Csv("BIOS", ""));
            sb.AppendLine(Csv("BIOS Manufacturer", info.BiosManufacturer));
            sb.AppendLine(Csv("BIOS Version", info.BiosVersion));
            sb.AppendLine(Csv("BIOS Release Date", info.BiosReleaseDate));
            sb.AppendLine(Csv("BIOS Serial Number", info.BiosSerialNumber));
            sb.AppendLine();

            sb.AppendLine(Csv("Motherboard", ""));
            sb.AppendLine(Csv("Motherboard Manufacturer", info.MotherboardManufacturer));
            sb.AppendLine(Csv("Motherboard Product", info.MotherboardProduct));
            sb.AppendLine(Csv("Motherboard Serial Number", info.MotherboardSerialNumber));
            sb.AppendLine();

            sb.AppendLine(Csv("CPU", ""));
            sb.AppendLine(Csv("CPU Name", info.CpuName));
            sb.AppendLine(Csv("CPU Manufacturer", info.CpuManufacturer));
            sb.AppendLine(Csv("Cores", info.CpuCores.ToString(CultureInfo.InvariantCulture)));
            sb.AppendLine(Csv("Logical Processors", info.CpuLogicalProcessors.ToString(CultureInfo.InvariantCulture)));
            sb.AppendLine(Csv("Max Clock (MHz)", info.CpuMaxClockMHz.ToString(CultureInfo.InvariantCulture)));
            sb.AppendLine();

            sb.AppendLine(Csv("Memory", ""));
            sb.AppendLine(Csv("Total RAM (GB)", info.TotalRamGB.ToString(CultureInfo.InvariantCulture)));
            sb.AppendLine(Csv("Module Count", info.MemoryModuleCount.ToString(CultureInfo.InvariantCulture)));
            sb.AppendLine();

            sb.AppendLine(Csv("Disks", ""));
            sb.AppendLine(Csv("Disk Count", info.DiskCount.ToString(CultureInfo.InvariantCulture)));
            sb.AppendLine(Csv("Total Disk (GB)", info.TotalDiskGB.ToString(CultureInfo.InvariantCulture)));
            sb.AppendLine();

            sb.AppendLine(Csv("Warranty", ""));
            sb.AppendLine(Csv("Status", info.WarrantyStatus));
            sb.AppendLine(Csv("End Date", info.WarrantyEndDate));
            sb.AppendLine(Csv("Provider", info.WarrantyProvider));
            sb.AppendLine(Csv("Check URL", info.WarrantyCheckUrl));
            sb.AppendLine(Csv("Note", info.WarrantyNote));
            sb.AppendLine();

            sb.AppendLine(Csv("Memory Modules", ""));
            sb.AppendLine(Csv("Device Locator", "Manufacturer", "Part Number", "Serial Number", "Capacity (GB)", "Speed (MHz)", "Type", "Form Factor"));
            foreach (var m in memory)
                sb.AppendLine(Csv(m.DeviceLocator, m.Manufacturer, m.PartNumber, m.SerialNumber,
                    m.CapacityGB.ToString(CultureInfo.InvariantCulture), m.SpeedMHz.ToString(CultureInfo.InvariantCulture),
                    m.MemoryType, m.FormFactor));
            sb.AppendLine();

            sb.AppendLine(Csv("Disk Drives", ""));
            sb.AppendLine(Csv("Model", "Interface", "Media Type", "Size (GB)", "Serial Number", "Firmware"));
            foreach (var d in disks)
                sb.AppendLine(Csv(d.Model, d.InterfaceType, d.MediaType,
                    d.SizeGB.ToString(CultureInfo.InvariantCulture), d.SerialNumber, d.FirmwareRevision));

            return sb.ToString();
        }

        private static string Csv(params string?[] fields) => string.Join(",", fields.Select(Escape));

        private static string Escape(string? field)
        {
            field ??= "";
            bool needsQuoting = field.Contains(',') || field.Contains('"') || field.Contains('\n') || field.Contains('\r');
            if (!needsQuoting) return field;
            return "\"" + field.Replace("\"", "\"\"") + "\"";
        }
    }
}
