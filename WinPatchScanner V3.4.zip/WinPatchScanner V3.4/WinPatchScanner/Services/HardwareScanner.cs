using System;
using System.Collections.Generic;
using System.Linq;
using System.Management;
using WinPatchScanner.Models;

namespace WinPatchScanner.Services
{
    public class HardwareScanResult
    {
        public HardwareInfo Info { get; set; } = new();
        public List<MemoryModuleInfo> MemoryModules { get; set; } = new();
        public List<DiskDriveInfo> Disks { get; set; } = new();
    }

    /// <summary>
    /// Detects the machine's hardware configuration entirely via WMI
    /// (Win32_ComputerSystem, Win32_ComputerSystemProduct, Win32_BIOS, Win32_BaseBoard,
    /// Win32_Processor, Win32_PhysicalMemory, Win32_DiskDrive). Entirely read-only, no
    /// elevation required, and every class is queried independently so one missing or
    /// access-denied class (uncommon, but seen on some VMs/locked-down images) only
    /// blanks that one section rather than failing the whole scan.
    /// </summary>
    public class HardwareScanner
    {
        public event Action<string>? StatusChanged;

        public HardwareScanResult Scan()
        {
            var info = new HardwareInfo();

            StatusChanged?.Invoke("Reading system & BIOS information...");
            ReadComputerSystem(info);
            ReadComputerSystemProduct(info);
            ReadBios(info);
            ReadBaseBoard(info);

            StatusChanged?.Invoke("Reading CPU information...");
            ReadProcessor(info);

            StatusChanged?.Invoke("Reading memory modules...");
            var memory = ReadMemory(info);

            StatusChanged?.Invoke("Reading disk drives...");
            var disks = ReadDisks(info);

            StatusChanged?.Invoke("Hardware detection complete.");

            return new HardwareScanResult { Info = info, MemoryModules = memory, Disks = disks };
        }

        private static void ReadComputerSystem(HardwareInfo info)
        {
            try
            {
                using var searcher = new ManagementObjectSearcher(
                    "SELECT Manufacturer, Model FROM Win32_ComputerSystem");
                foreach (ManagementObject mo in searcher.Get())
                {
                    info.Manufacturer = Clean(mo["Manufacturer"]);
                    info.Model = Clean(mo["Model"]);
                    break;
                }
            }
            catch { /* leave blank - not fatal */ }
        }

        private static void ReadComputerSystemProduct(HardwareInfo info)
        {
            try
            {
                using var searcher = new ManagementObjectSearcher(
                    "SELECT IdentifyingNumber FROM Win32_ComputerSystemProduct");
                foreach (ManagementObject mo in searcher.Get())
                {
                    info.SystemSerialNumber = Clean(mo["IdentifyingNumber"]);
                    break;
                }
            }
            catch { /* leave blank */ }

            try
            {
                using var searcher = new ManagementObjectSearcher("SELECT ChassisTypes FROM Win32_SystemEnclosure");
                foreach (ManagementObject mo in searcher.Get())
                {
                    if (mo["ChassisTypes"] is ushort[] types && types.Length > 0)
                        info.ChassisType = ChassisTypeToText(types[0]);
                    break;
                }
            }
            catch { /* leave blank */ }
        }

        private static void ReadBios(HardwareInfo info)
        {
            try
            {
                using var searcher = new ManagementObjectSearcher(
                    "SELECT Manufacturer, SMBIOSBIOSVersion, ReleaseDate, SerialNumber FROM Win32_BIOS");
                foreach (ManagementObject mo in searcher.Get())
                {
                    info.BiosManufacturer = Clean(mo["Manufacturer"]);
                    info.BiosVersion = Clean(mo["SMBIOSBIOSVersion"]);
                    info.BiosSerialNumber = Clean(mo["SerialNumber"]);
                    string? releaseDate = mo["ReleaseDate"] as string;
                    info.BiosReleaseDate = TryConvertWmiDate(releaseDate);
                    break;
                }
            }
            catch { /* leave blank */ }
        }

        private static void ReadBaseBoard(HardwareInfo info)
        {
            try
            {
                using var searcher = new ManagementObjectSearcher(
                    "SELECT Manufacturer, Product, SerialNumber FROM Win32_BaseBoard");
                foreach (ManagementObject mo in searcher.Get())
                {
                    info.MotherboardManufacturer = Clean(mo["Manufacturer"]);
                    info.MotherboardProduct = Clean(mo["Product"]);
                    info.MotherboardSerialNumber = Clean(mo["SerialNumber"]);
                    break;
                }
            }
            catch { /* leave blank */ }
        }

        private static void ReadProcessor(HardwareInfo info)
        {
            try
            {
                using var searcher = new ManagementObjectSearcher(
                    "SELECT Name, Manufacturer, NumberOfCores, NumberOfLogicalProcessors, MaxClockSpeed FROM Win32_Processor");
                foreach (ManagementObject mo in searcher.Get())
                {
                    info.CpuName = Clean(mo["Name"]);
                    info.CpuManufacturer = Clean(mo["Manufacturer"]);
                    info.CpuCores = SafeToInt(mo["NumberOfCores"]);
                    info.CpuLogicalProcessors = SafeToInt(mo["NumberOfLogicalProcessors"]);
                    info.CpuMaxClockMHz = SafeToInt(mo["MaxClockSpeed"]);
                    break; // first socket only - the overwhelming majority of machines have one
                }
            }
            catch { /* leave blank */ }
        }

        private static List<MemoryModuleInfo> ReadMemory(HardwareInfo info)
        {
            var modules = new List<MemoryModuleInfo>();
            try
            {
                using var searcher = new ManagementObjectSearcher(
                    "SELECT DeviceLocator, Manufacturer, PartNumber, SerialNumber, Capacity, Speed, FormFactor, SMBIOSMemoryType FROM Win32_PhysicalMemory");
                foreach (ManagementObject mo in searcher.Get())
                {
                    modules.Add(new MemoryModuleInfo
                    {
                        DeviceLocator = Clean(mo["DeviceLocator"]),
                        Manufacturer = Clean(mo["Manufacturer"]),
                        PartNumber = Clean(mo["PartNumber"]),
                        SerialNumber = Clean(mo["SerialNumber"]),
                        CapacityGB = Math.Round(SafeToLong(mo["Capacity"]) / 1024.0 / 1024.0 / 1024.0, 1),
                        SpeedMHz = SafeToInt(mo["Speed"]),
                        FormFactor = FormFactorToText(SafeToInt(mo["FormFactor"])),
                        MemoryType = MemoryTypeToText(SafeToInt(mo["SMBIOSMemoryType"])),
                    });
                }
            }
            catch { /* leave empty */ }

            info.MemoryModuleCount = modules.Count;
            info.TotalRamGB = Math.Round(modules.Sum(m => m.CapacityGB), 1);

            // Fall back to the OS-reported total if Win32_PhysicalMemory came back empty
            // (seen on some VMs/hypervisors that don't expose per-DIMM SMBIOS data).
            if (info.TotalRamGB == 0)
            {
                try
                {
                    using var searcher = new ManagementObjectSearcher("SELECT TotalPhysicalMemory FROM Win32_ComputerSystem");
                    foreach (ManagementObject mo in searcher.Get())
                    {
                        info.TotalRamGB = Math.Round(SafeToLong(mo["TotalPhysicalMemory"]) / 1024.0 / 1024.0 / 1024.0, 1);
                        break;
                    }
                }
                catch { /* leave as-is */ }
            }

            return modules.OrderBy(m => m.DeviceLocator, StringComparer.OrdinalIgnoreCase).ToList();
        }

        private static List<DiskDriveInfo> ReadDisks(HardwareInfo info)
        {
            var disks = new List<DiskDriveInfo>();
            try
            {
                using var searcher = new ManagementObjectSearcher(
                    "SELECT Model, InterfaceType, MediaType, Size, SerialNumber, FirmwareRevision FROM Win32_DiskDrive");
                foreach (ManagementObject mo in searcher.Get())
                {
                    disks.Add(new DiskDriveInfo
                    {
                        Model = Clean(mo["Model"]),
                        InterfaceType = Clean(mo["InterfaceType"]),
                        MediaType = Clean(mo["MediaType"]),
                        SizeGB = Math.Round(SafeToLong(mo["Size"]) / 1024.0 / 1024.0 / 1024.0, 1),
                        SerialNumber = Clean(mo["SerialNumber"]),
                        FirmwareRevision = Clean(mo["FirmwareRevision"]),
                    });
                }
            }
            catch { /* leave empty */ }

            info.DiskCount = disks.Count;
            info.TotalDiskGB = Math.Round(disks.Sum(d => d.SizeGB), 1);

            return disks.OrderBy(d => d.Model, StringComparer.OrdinalIgnoreCase).ToList();
        }

        // ----- small helpers -----

        private static string Clean(object? value)
        {
            string s = value?.ToString()?.Trim() ?? "";
            // WMI reports a literal "To be filled by O.E.M." placeholder on a lot of
            // white-box/DIY boards - show it as blank/Unknown rather than that noise.
            if (s.Length == 0 || s.Equals("To be filled by O.E.M.", StringComparison.OrdinalIgnoreCase) ||
                s.Equals("System Serial Number", StringComparison.OrdinalIgnoreCase) ||
                s.Equals("Default string", StringComparison.OrdinalIgnoreCase) ||
                s == "0")
                return "";
            return s;
        }

        private static int SafeToInt(object? value)
        {
            if (value == null) return 0;
            try { return Convert.ToInt32(value); } catch { return 0; }
        }

        private static long SafeToLong(object? value)
        {
            if (value == null) return 0;
            try { return Convert.ToInt64(value); } catch { return 0; }
        }

        // WMI dates arrive as "yyyyMMddHHmmss.ffffff+zzz" (SMBIOS/CIM format).
        private static string TryConvertWmiDate(string? wmiDate)
        {
            if (string.IsNullOrWhiteSpace(wmiDate) || wmiDate.Length < 8) return "";
            try
            {
                string datePart = wmiDate.Substring(0, 8);
                var dt = DateTime.ParseExact(datePart, "yyyyMMdd", System.Globalization.CultureInfo.InvariantCulture);
                return dt.ToString("yyyy-MM-dd");
            }
            catch { return ""; }
        }

        private static string ChassisTypeToText(int code) => code switch
        {
            3 => "Desktop",
            4 => "Low Profile Desktop",
            6 => "Mini Tower",
            7 => "Tower",
            8 => "Portable",
            9 or 10 => "Laptop",
            11 => "Notebook",
            14 => "Sub Notebook",
            23 => "Rack Mount Server",
            30 => "Tablet",
            31 => "Convertible",
            32 => "Detachable",
            _ => "Unknown",
        };

        private static string FormFactorToText(int code) => code switch
        {
            8 => "DIMM",
            12 => "SO-DIMM",
            13 => "Micro-DIMM",
            _ => "Unknown",
        };

        private static string MemoryTypeToText(int code) => code switch
        {
            20 => "DDR",
            21 => "DDR2",
            24 => "DDR3",
            26 => "DDR4",
            34 => "DDR5",
            _ => "Unknown",
        };
    }
}
