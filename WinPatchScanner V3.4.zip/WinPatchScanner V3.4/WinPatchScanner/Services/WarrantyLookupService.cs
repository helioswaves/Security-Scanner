using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Threading.Tasks;

namespace WinPatchScanner.Services
{
    public class WarrantyResult
    {
        public string Status { get; set; } = "Not checked";
        public string EndDate { get; set; } = "";
        public string Provider { get; set; } = "";
        public string CheckUrl { get; set; } = "";
        public string Note { get; set; } = "";
    }

    /// <summary>
    /// Looks up warranty status for the detected OEM.
    ///
    /// Honesty note: Dell is, as far as this app's author could confirm, the only major
    /// PC OEM with a public, self-service-registerable warranty API (Dell TechDirect's
    /// "Asset Entitlements" API) - so it's the only vendor this app calls automatically,
    /// and only once you've registered for free at
    /// https://www.dell.com/support/retail/tdregistration and entered the resulting
    /// API Client ID/Secret in this tab. HP, Lenovo, ASUS, Acer and the rest either have
    /// no public API, or one that's restricted to business/partner accounts under NDA -
    /// for those (and for Dell before credentials are configured), this app gives you a
    /// direct link to that OEM's own public warranty-check web page instead of guessing
    /// or fabricating a status.
    /// </summary>
    public class WarrantyLookupService
    {
        public event Action<string>? StatusChanged;

        private static readonly string CredentialsPath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "WinPatch", "dell-api-credentials.json");

        private const string DellTokenUrl = "https://apigtwb2c.us.dell.com/auth/oauth/v2/token";
        private const string DellEntitlementsUrl = "https://apigtwb2c.us.dell.com/PROD/sbil/eapi/v5/asset-entitlements";

        public static bool DellCredentialsConfigured
        {
            get
            {
                var (id, secret) = LoadDellCredentials();
                return !string.IsNullOrWhiteSpace(id) && !string.IsNullOrWhiteSpace(secret);
            }
        }

        public static (string ClientId, string ClientSecret) LoadDellCredentials()
        {
            try
            {
                if (!File.Exists(CredentialsPath)) return ("", "");
                using var doc = JsonDocument.Parse(File.ReadAllText(CredentialsPath));
                string id = doc.RootElement.TryGetProperty("ClientId", out var idEl) ? idEl.GetString() ?? "" : "";
                string secret = doc.RootElement.TryGetProperty("ClientSecret", out var secretEl) ? secretEl.GetString() ?? "" : "";
                return (id, secret);
            }
            catch { return ("", ""); }
        }

        public static void SaveDellCredentials(string clientId, string clientSecret)
        {
            var dir = Path.GetDirectoryName(CredentialsPath)!;
            Directory.CreateDirectory(dir);
            string json = JsonSerializer.Serialize(new { ClientId = clientId, ClientSecret = clientSecret });
            File.WriteAllText(CredentialsPath, json);
        }

        public static void ClearDellCredentials()
        {
            try { if (File.Exists(CredentialsPath)) File.Delete(CredentialsPath); } catch { /* best effort */ }
        }

        public WarrantyResult Lookup(string manufacturer, string serialNumber)
        {
            string oem = DetectOem(manufacturer);

            if (string.IsNullOrWhiteSpace(serialNumber))
            {
                return new WarrantyResult
                {
                    Status = "Unavailable",
                    Provider = oem,
                    Note = "No system serial number / service tag was detected on this machine, so a warranty lookup can't be attempted.",
                };
            }

            if (oem == "Dell")
            {
                var (clientId, clientSecret) = LoadDellCredentials();
                if (!string.IsNullOrWhiteSpace(clientId) && !string.IsNullOrWhiteSpace(clientSecret))
                {
                    try
                    {
                        return LookupDellAsync(clientId, clientSecret, serialNumber).GetAwaiter().GetResult();
                    }
                    catch (Exception ex)
                    {
                        return new WarrantyResult
                        {
                            Status = "Lookup failed",
                            Provider = "Dell",
                            CheckUrl = FallbackUrl("Dell"),
                            Note = $"Dell API lookup failed: {FirstLine(ex.Message)}. Use the link to check manually.",
                        };
                    }
                }
            }

            return FallbackResult(oem);
        }

        private async Task<WarrantyResult> LookupDellAsync(string clientId, string clientSecret, string serviceTag)
        {
            StatusChanged?.Invoke("Requesting Dell API access token...");

            using var http = new HttpClient();
            http.Timeout = TimeSpan.FromSeconds(20);

            var tokenRequest = new HttpRequestMessage(HttpMethod.Post, DellTokenUrl)
            {
                Content = new FormUrlEncodedContent(new Dictionary<string, string>
                {
                    ["client_id"] = clientId,
                    ["client_secret"] = clientSecret,
                    ["grant_type"] = "client_credentials",
                })
            };

            var tokenResponse = await http.SendAsync(tokenRequest);
            string tokenBody = await tokenResponse.Content.ReadAsStringAsync();
            if (!tokenResponse.IsSuccessStatusCode)
                throw new InvalidOperationException($"Token request returned {(int)tokenResponse.StatusCode} - check the Client ID/Secret.");

            using var tokenDoc = JsonDocument.Parse(tokenBody);
            string? accessToken = tokenDoc.RootElement.TryGetProperty("access_token", out var atEl) ? atEl.GetString() : null;
            if (string.IsNullOrWhiteSpace(accessToken))
                throw new InvalidOperationException("Token response did not contain an access_token.");

            StatusChanged?.Invoke("Querying Dell asset entitlements...");

            var entRequest = new HttpRequestMessage(HttpMethod.Get, $"{DellEntitlementsUrl}?servicetags={Uri.EscapeDataString(serviceTag)}");
            entRequest.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

            var entResponse = await http.SendAsync(entRequest);
            string entBody = await entResponse.Content.ReadAsStringAsync();
            if (!entResponse.IsSuccessStatusCode)
                throw new InvalidOperationException($"Entitlements request returned {(int)entResponse.StatusCode}.");

            return ParseDellEntitlements(entBody, serviceTag);
        }

        // Parsed defensively (TryGetProperty everywhere, never throws on an unexpected
        // shape) against Dell's documented Asset Entitlements response - an array of
        // assets, each with an "entitlements" array carrying a serviceLevelDescription
        // and startDate/endDate per coverage line. The overall warranty end date is the
        // latest endDate across all entitlement lines for this service tag.
        private static WarrantyResult ParseDellEntitlements(string json, string serviceTag)
        {
            using var doc = JsonDocument.Parse(json);
            var root = doc.RootElement;

            JsonElement assets = root.ValueKind == JsonValueKind.Array ? root : default;
            if (root.ValueKind == JsonValueKind.Object && root.TryGetProperty("value", out var valueEl) && valueEl.ValueKind == JsonValueKind.Array)
                assets = valueEl;

            if (assets.ValueKind != JsonValueKind.Array || assets.GetArrayLength() == 0)
            {
                return new WarrantyResult
                {
                    Status = "Unavailable",
                    Provider = "Dell",
                    CheckUrl = FallbackUrl("Dell"),
                    Note = $"Dell returned no entitlement records for service tag {serviceTag}. It may not be Dell-branded, or may be too new/old for this API.",
                };
            }

            DateTime? latestEnd = null;
            string latestDescription = "";

            foreach (var asset in assets.EnumerateArray())
            {
                if (!asset.TryGetProperty("entitlements", out var entitlements) || entitlements.ValueKind != JsonValueKind.Array)
                    continue;

                foreach (var ent in entitlements.EnumerateArray())
                {
                    string? endStr = ent.TryGetProperty("endDate", out var endEl) ? endEl.GetString() : null;
                    string desc = ent.TryGetProperty("serviceLevelDescription", out var descEl) ? descEl.GetString() ?? "" : "";

                    if (DateTime.TryParse(endStr, out var end))
                    {
                        if (latestEnd == null || end > latestEnd)
                        {
                            latestEnd = end;
                            latestDescription = desc;
                        }
                    }
                }
            }

            if (latestEnd == null)
            {
                return new WarrantyResult
                {
                    Status = "Unavailable",
                    Provider = "Dell",
                    CheckUrl = FallbackUrl("Dell"),
                    Note = "Dell returned entitlement data but no readable end date - open the link to check manually.",
                };
            }

            bool inWarranty = latestEnd.Value.Date >= DateTime.Today;
            return new WarrantyResult
            {
                Status = inWarranty ? "In Warranty" : "Expired",
                EndDate = latestEnd.Value.ToString("yyyy-MM-dd"),
                Provider = "Dell" + (string.IsNullOrWhiteSpace(latestDescription) ? "" : $" ({latestDescription})"),
                CheckUrl = FallbackUrl("Dell"),
                Note = "Source: Dell TechDirect Asset Entitlements API.",
            };
        }

        private static WarrantyResult FallbackResult(string oem) => new()
        {
            Status = "Not checked",
            Provider = oem,
            CheckUrl = FallbackUrl(oem),
            Note = oem == "Dell"
                ? "Automated lookup is available for Dell, but no API Client ID/Secret is configured yet - register free at the Dell TechDirect link below, then enter the credentials in this tab."
                : $"No public, self-service warranty API is available for {(oem == "Unknown" ? "this manufacturer" : oem)} - use the link to check manually on the manufacturer's own site.",
        };

        private static string FallbackUrl(string oem) => oem switch
        {
            "Dell" => "https://www.dell.com/support/home/en-in/product-support/servicetag/",
            "HP" => "https://support.hp.com/us-en/checkwarranty",
            "Lenovo" => "https://pcsupport.lenovo.com/warrantylookup",
            "ASUS" => "https://www.asus.com/support/warranty-status-inquiry/",
            "Acer" => "https://www.acer.com/us-en/support/warranty/",
            "Apple" => "https://checkcoverage.apple.com/",
            "Microsoft" => "https://support.microsoft.com/",
            _ => "",
        };

        private static string DetectOem(string manufacturer)
        {
            string m = (manufacturer ?? "").ToLowerInvariant();
            if (m.Contains("dell")) return "Dell";
            if (m.Contains("hewlett") || m.Contains("hp")) return "HP";
            if (m.Contains("lenovo")) return "Lenovo";
            if (m.Contains("asus")) return "ASUS";
            if (m.Contains("acer")) return "Acer";
            if (m.Contains("apple")) return "Apple";
            if (m.Contains("microsoft")) return "Microsoft";
            if (m.Contains("samsung")) return "Samsung";
            if (m.Contains("toshiba") || m.Contains("dynabook")) return "Toshiba/Dynabook";
            if (m.Contains("msi")) return "MSI";
            if (m.Contains("gigabyte")) return "Gigabyte";
            return string.IsNullOrWhiteSpace(manufacturer) ? "Unknown" : manufacturer.Trim();
        }

        private static string FirstLine(string s)
        {
            int idx = s.IndexOfAny(new[] { '\r', '\n' });
            return idx > 0 ? s.Substring(0, idx) : s;
        }
    }
}
