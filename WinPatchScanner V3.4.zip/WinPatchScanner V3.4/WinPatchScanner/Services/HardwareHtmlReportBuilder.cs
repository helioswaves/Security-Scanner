using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using WinPatchScanner.Models;

namespace WinPatchScanner.Services
{
    /// <summary>Builds a standalone, dark-HUD styled HTML report for the Hardware tab -
    /// system/BIOS/board/CPU overview, warranty status, and every memory module and
    /// disk drive.</summary>
    public static class HardwareHtmlReportBuilder
    {
        public static string Build(string hostname, HardwareInfo info, List<MemoryModuleInfo> memory,
            List<DiskDriveInfo> disks, DateTime scanTime)
        {
            var sb = new StringBuilder();
            sb.Append($@"<!DOCTYPE html>
<html lang=""en"">
<head>
<meta charset=""UTF-8"">
<title>Hardware Configuration Report - {Enc(hostname)}</title>
<style>
  :root {{
    --bg:#0A0E14; --panel:#10161F; --panel-alt:#151C27; --border:#243040;
    --cyan:#38E1FF; --green:#3DFFA0; --amber:#FFB03B; --red:#FF4D5E;
    --text:#C9D6E3; --muted:#7A8896;
  }}
  * {{ box-sizing:border-box; }}
  body {{
    background:var(--bg); color:var(--text); margin:0; padding:32px;
    font-family:Consolas,'Courier New',monospace;
  }}
  .header {{
    display:flex; justify-content:space-between; align-items:flex-start;
    border-bottom:1px solid var(--border); padding-bottom:16px; margin-bottom:24px;
  }}
  h1 {{ color:var(--cyan); font-size:20px; letter-spacing:2px; margin:0 0 6px 0; text-transform:uppercase; }}
  h2 {{ color:var(--cyan); font-size:14px; letter-spacing:1px; text-transform:uppercase; margin:28px 0 12px 0; }}
  .meta {{ color:var(--muted); font-size:12px; line-height:1.7; }}
  .meta b {{ color:var(--text); }}
  .top-row {{ display:flex; gap:16px; margin-bottom:24px; align-items:stretch; flex-wrap:wrap; }}
  .risk-panel {{
    background:var(--panel); border:1px solid var(--border); border-radius:4px;
    padding:16px 24px; display:flex; align-items:center; gap:20px; min-width:280px;
  }}
  .risk-number {{ font-size:22px; font-weight:bold; line-height:1; }}
  .risk-meta .label {{ color:var(--muted); font-size:10px; letter-spacing:1px; text-transform:uppercase; margin-bottom:4px; }}
  .risk-meta .desc {{ font-size:13px; font-weight:bold; }}
  .risk-meta .sub {{ font-size:11px; color:var(--muted); margin-top:4px; }}
  .r-warranty {{ color:var(--green); }}
  .r-expired {{ color:var(--red); }}
  .r-unknown {{ color:var(--muted); }}
  .cards {{ display:flex; gap:12px; flex-wrap:wrap; flex:1; }}
  .card {{
    background:var(--panel); border:1px solid var(--border); border-radius:4px;
    padding:14px 18px; min-width:130px;
  }}
  .card .label {{ color:var(--muted); font-size:10px; letter-spacing:1px; text-transform:uppercase; }}
  .card .value {{ font-size:20px; font-weight:bold; margin-top:6px; color:var(--text); }}
  table {{ width:100%; border-collapse:collapse; background:var(--panel); border:1px solid var(--border); border-radius:4px; overflow:hidden; }}
  th {{
    background:var(--panel-alt); color:var(--muted); text-align:left; font-size:10px;
    letter-spacing:1px; text-transform:uppercase; padding:10px 12px; border-bottom:1px solid var(--border);
  }}
  td {{ padding:9px 12px; font-size:12px; border-bottom:1px solid var(--border); vertical-align:top; }}
  tr:last-child td {{ border-bottom:none; }}
  tr:hover td {{ background:#1C2733; }}
  .kv {{ display:grid; grid-template-columns:200px 1fr; gap:6px 16px; }}
  .kv .k {{ color:var(--muted); font-size:11px; letter-spacing:0.5px; text-transform:uppercase; }}
  .kv .v {{ font-size:13px; }}
  .empty {{ text-align:center; color:var(--muted); padding:32px; }}
  footer {{ margin-top:24px; color:var(--muted); font-size:10px; text-align:center; letter-spacing:1px; }}
  .disclaimer {{ margin-top:8px; color:var(--muted); font-size:10px; text-align:center; }}
  .copyright {{ margin-top:4px; color:var(--muted); font-size:10px; text-align:center; letter-spacing:0.5px; }}
  a {{ color:var(--cyan); }}
</style>
</head>
<body>

<div class=""header"">
  <div>
    <h1>&#9679; Hardware Configuration Report</h1>
    <div class=""meta"">
      <div>Host: <b>{Enc(hostname)}</b></div>
      <div>OEM / Model: <b>{Enc(info.Manufacturer)} {Enc(info.Model)}</b></div>
    </div>
  </div>
  <div style=""text-align:right"">
    {ReportBranding.LogoImgHtml(28)}
    <div class=""meta"" style=""text-align:right"">
      <div>Scan time</div>
      <div><b>{scanTime:yyyy-MM-dd HH:mm:ss}</b></div>
    </div>
  </div>
</div>

<div class=""top-row"">
  <div class=""risk-panel"">
    <div class=""risk-number {WarrantyClass(info.WarrantyStatus)}"">{Enc(info.WarrantyStatus)}</div>
    <div class=""risk-meta"">
      <div class=""label"">Warranty Status</div>
      <div class=""desc {WarrantyClass(info.WarrantyStatus)}"">{Enc(string.IsNullOrEmpty(info.WarrantyProvider) ? "—" : info.WarrantyProvider)}</div>
      <div class=""sub"">{(string.IsNullOrEmpty(info.WarrantyEndDate) ? "" : $"End date: {Enc(info.WarrantyEndDate)}")}</div>
    </div>
  </div>

  <div class=""cards"">
    <div class=""card""><div class=""label"">CPU</div><div class=""value"" style=""font-size:13px"">{Enc(info.CpuName)}</div></div>
    <div class=""card""><div class=""label"">Total RAM</div><div class=""value"">{info.TotalRamGB:0.#} GB</div></div>
    <div class=""card""><div class=""label"">Disks</div><div class=""value"">{info.DiskCount} ({info.TotalDiskGB:0.#} GB)</div></div>
    <div class=""card""><div class=""label"">System Serial</div><div class=""value"" style=""font-size:14px"">{Enc(string.IsNullOrEmpty(info.SystemSerialNumber) ? "—" : info.SystemSerialNumber)}</div></div>
  </div>
</div>

<h2>System &amp; BIOS</h2>
<div class=""kv"" style=""background:var(--panel);border:1px solid var(--border);border-radius:4px;padding:16px 20px;"">
  <div class=""k"">Manufacturer (OEM)</div><div class=""v"">{Enc(Val(info.Manufacturer))}</div>
  <div class=""k"">Model</div><div class=""v"">{Enc(Val(info.Model))}</div>
  <div class=""k"">Chassis Type</div><div class=""v"">{Enc(Val(info.ChassisType))}</div>
  <div class=""k"">System Serial Number</div><div class=""v"">{Enc(Val(info.SystemSerialNumber))}</div>
  <div class=""k"">BIOS Manufacturer</div><div class=""v"">{Enc(Val(info.BiosManufacturer))}</div>
  <div class=""k"">BIOS Version</div><div class=""v"">{Enc(Val(info.BiosVersion))}</div>
  <div class=""k"">BIOS Release Date</div><div class=""v"">{Enc(Val(info.BiosReleaseDate))}</div>
  <div class=""k"">BIOS Serial Number</div><div class=""v"">{Enc(Val(info.BiosSerialNumber))}</div>
</div>

<h2>Motherboard &amp; CPU</h2>
<div class=""kv"" style=""background:var(--panel);border:1px solid var(--border);border-radius:4px;padding:16px 20px;"">
  <div class=""k"">Motherboard Manufacturer</div><div class=""v"">{Enc(Val(info.MotherboardManufacturer))}</div>
  <div class=""k"">Motherboard Product</div><div class=""v"">{Enc(Val(info.MotherboardProduct))}</div>
  <div class=""k"">Motherboard Serial Number</div><div class=""v"">{Enc(Val(info.MotherboardSerialNumber))}</div>
  <div class=""k"">CPU</div><div class=""v"">{Enc(Val(info.CpuName))}</div>
  <div class=""k"">CPU Manufacturer</div><div class=""v"">{Enc(Val(info.CpuManufacturer))}</div>
  <div class=""k"">Cores / Logical Processors</div><div class=""v"">{info.CpuCores} / {info.CpuLogicalProcessors}</div>
  <div class=""k"">Max Clock Speed</div><div class=""v"">{(info.CpuMaxClockMHz > 0 ? $"{info.CpuMaxClockMHz:0} MHz" : "—")}</div>
</div>

<h2>Warranty</h2>
<div class=""kv"" style=""background:var(--panel);border:1px solid var(--border);border-radius:4px;padding:16px 20px;"">
  <div class=""k"">Status</div><div class=""v"">{Enc(info.WarrantyStatus)}</div>
  <div class=""k"">End Date</div><div class=""v"">{Enc(Val(info.WarrantyEndDate))}</div>
  <div class=""k"">Provider</div><div class=""v"">{Enc(Val(info.WarrantyProvider))}</div>
  <div class=""k"">Check URL</div><div class=""v"">{(string.IsNullOrEmpty(info.WarrantyCheckUrl) ? "—" : $@"<a href=""{Enc(info.WarrantyCheckUrl)}"">{Enc(info.WarrantyCheckUrl)}</a>")}</div>
  <div class=""k"">Note</div><div class=""v"" style=""color:var(--muted)"">{Enc(Val(info.WarrantyNote))}</div>
</div>

<h2>Memory Modules <span style=""font-size:10px;color:var(--muted);text-transform:none;letter-spacing:0"">({memory.Count} module(s), {info.TotalRamGB:0.#} GB total)</span></h2>
<table>
  <thead><tr><th>Locator</th><th>Manufacturer</th><th>Part Number</th><th>Capacity</th><th>Speed</th><th>Type</th><th>Form Factor</th></tr></thead>
  <tbody>
");
            if (memory.Count == 0)
            {
                sb.Append(@"<tr><td colspan=""7"" class=""empty"">No memory module detail available (Win32_PhysicalMemory returned nothing on this machine).</td></tr>");
            }
            else
            {
                foreach (var m in memory)
                {
                    sb.Append($@"
    <tr>
      <td>{Enc(Val(m.DeviceLocator))}</td>
      <td>{Enc(Val(m.Manufacturer))}</td>
      <td>{Enc(Val(m.PartNumber))}</td>
      <td>{m.CapacityGB:0.#} GB</td>
      <td>{(m.SpeedMHz > 0 ? $"{m.SpeedMHz:0} MHz" : "—")}</td>
      <td>{Enc(Val(m.MemoryType))}</td>
      <td>{Enc(Val(m.FormFactor))}</td>
    </tr>");
                }
            }

            sb.Append($@"
  </tbody>
</table>

<h2>Disk Drives <span style=""font-size:10px;color:var(--muted);text-transform:none;letter-spacing:0"">({disks.Count} drive(s), {info.TotalDiskGB:0.#} GB total)</span></h2>
<table>
  <thead><tr><th>Model</th><th>Interface</th><th>Media Type</th><th>Size</th><th>Serial Number</th><th>Firmware</th></tr></thead>
  <tbody>
");
            if (disks.Count == 0)
            {
                sb.Append(@"<tr><td colspan=""6"" class=""empty"">No disk drive detail available.</td></tr>");
            }
            else
            {
                foreach (var d in disks)
                {
                    sb.Append($@"
    <tr>
      <td>{Enc(Val(d.Model))}</td>
      <td>{Enc(Val(d.InterfaceType))}</td>
      <td>{Enc(Val(d.MediaType))}</td>
      <td>{d.SizeGB:0.#} GB</td>
      <td>{Enc(Val(d.SerialNumber))}</td>
      <td>{Enc(Val(d.FirmwareRevision))}</td>
    </tr>");
                }
            }

            sb.Append($@"
  </tbody>
</table>

<div class=""disclaimer"">Hardware detail comes entirely from WMI (Win32_ComputerSystem, Win32_BIOS, Win32_BaseBoard, Win32_Processor, Win32_PhysicalMemory, Win32_DiskDrive). Warranty status is only looked up automatically for Dell, and only once a Dell TechDirect API Client ID/Secret is configured - every other manufacturer, and Dell without credentials, shows a direct link to that OEM's own public warranty-check page instead of a guessed status.</div>
<footer>GENERATED BY WIN PATCH SCANNER &middot; {scanTime:yyyy-MM-dd HH:mm:ss}</footer>
<div class=""copyright"">{Enc(ReportBranding.CopyrightText)}</div>

</body>
</html>");

            return sb.ToString();
        }

        private static string WarrantyClass(string status) => status switch
        {
            "In Warranty" => "r-warranty",
            "Expired" => "r-expired",
            _ => "r-unknown",
        };

        private static string Val(string? s) => string.IsNullOrWhiteSpace(s) ? "—" : s;

        private static string Enc(string? s) => WebUtility.HtmlEncode(s ?? "");
    }
}
