using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Management;
using System.Security.Principal;
using System.Threading;
using System.Windows;
using System.Windows.Media;
using Microsoft.Win32;
using WinPatchScanner.Converters;
using WinPatchScanner.Models;
using WinPatchScanner.Services;

namespace WinPatchScanner
{
    public partial class MainWindow : Window
    {
        private readonly ObservableCollection<PatchInfo> _updates = new();
        private readonly PatchScanner _scanner = new();
        private ICollectionView UpdatesView => System.Windows.Data.CollectionViewSource.GetDefaultView(_updates);

        private readonly ObservableCollection<ApplicationInfo> _apps = new();
        private readonly ObservableCollection<ServiceInfo> _services = new();
        private readonly InventoryScanner _inventoryScanner = new();
        private ICollectionView AppsView => System.Windows.Data.CollectionViewSource.GetDefaultView(_apps);
        private ICollectionView ServicesView => System.Windows.Data.CollectionViewSource.GetDefaultView(_services);
        private DateTime _lastInventoryScanTime;

        private readonly ObservableCollection<AppUpdateInfo> _appUpdates = new();
        private readonly WingetUpdateScanner _wingetScanner = new();
        private ICollectionView AppUpdatesView => System.Windows.Data.CollectionViewSource.GetDefaultView(_appUpdates);
        private DateTime _lastUpdatesScanTime;

        private readonly ObservableCollection<ThreatDetectionInfo> _threats = new();
        private readonly ObservableCollection<ProtectionEventInfo> _protectionHistory = new();
        private readonly ObservableCollection<SecurityIssueInfo> _securityIssues = new();
        private readonly SecurityScanner _securityScanner = new();
        private DefenderStatusInfo _securityStatus = new();
        private ICollectionView ThreatsView => System.Windows.Data.CollectionViewSource.GetDefaultView(_threats);
        private ICollectionView HistoryView => System.Windows.Data.CollectionViewSource.GetDefaultView(_protectionHistory);
        private DateTime _lastSecurityScanTime;

        private readonly ObservableCollection<SecurityEventInfo> _securityEvents = new();
        private readonly ObservableCollection<SecurityFindingInfo> _securityFindings = new();
        private readonly SecurityEventScanner _securityEventScanner = new();
        private ICollectionView SecurityEventsView => System.Windows.Data.CollectionViewSource.GetDefaultView(_securityEvents);
        private DateTime _lastSecurityEventsScanTime;
        private int _lastSecurityEventsLookbackDays = 7;

        private readonly ObservableCollection<MemoryModuleInfo> _memoryModules = new();
        private readonly ObservableCollection<DiskDriveInfo> _disks = new();
        private readonly HardwareScanner _hardwareScanner = new();
        private readonly WarrantyLookupService _warrantyService = new();
        private HardwareInfo _hardwareInfo = new();
        private DateTime _lastHardwareScanTime;

        private string _hostname = Environment.MachineName;
        private string _osCaption = "Unknown";
        private string _osBuild = "Unknown";
        private DateTime _lastScanTime;

        public MainWindow()
        {
            InitializeComponent();
            UpdatesGrid.ItemsSource = _updates;
            AppsGrid.ItemsSource = _apps;
            ServicesGrid.ItemsSource = _services;
            UpdatesGrid2.ItemsSource = _appUpdates;
            IssuesGrid.ItemsSource = _securityIssues;
            ThreatsGrid.ItemsSource = _threats;
            HistoryGrid.ItemsSource = _protectionHistory;
            FindingsGrid.ItemsSource = _securityFindings;
            SecurityEventsGrid.ItemsSource = _securityEvents;
            MemoryGrid.ItemsSource = _memoryModules;
            DisksGrid.ItemsSource = _disks;
            LoadOsInfo();
            RefreshElevationState();
            LoadDellCredentialsIntoBoxes();
        }

        private void LoadDellCredentialsIntoBoxes()
        {
            var (clientId, _) = WarrantyLookupService.LoadDellCredentials();
            DellClientIdBox.Text = clientId;
        }

        private void LoadOsInfo()
        {
            try
            {
                using var searcher = new ManagementObjectSearcher("SELECT Caption, BuildNumber FROM Win32_OperatingSystem");
                foreach (ManagementObject mo in searcher.Get())
                {
                    _osCaption = mo["Caption"]?.ToString()?.Trim() ?? "Unknown";
                    _osBuild = mo["BuildNumber"]?.ToString() ?? "Unknown";
                    break;
                }
            }
            catch
            {
                _osCaption = Environment.OSVersion.VersionString;
                _osBuild = "N/A";
            }

            HostInfoText.Text = $"HOST: {_hostname}   |   OS: {_osCaption}  (Build {_osBuild})";
        }

        private static bool IsRunningAsAdministrator()
        {
            using var identity = WindowsIdentity.GetCurrent();
            var principal = new WindowsPrincipal(identity);
            return principal.IsInRole(WindowsBuiltInRole.Administrator);
        }

        private void RefreshElevationState()
        {
            bool isAdmin = IsRunningAsAdministrator();
            ElevationBanner.Visibility = isAdmin ? Visibility.Collapsed : Visibility.Visible;
            InstallSelectedButton.IsEnabled = isAdmin && _updates.Count > 0;
            InstallAllButton.IsEnabled = isAdmin && _updates.Count > 0;
        }

        private void RestartAsAdminButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var exePath = Process.GetCurrentProcess().MainModule!.FileName!;
                var psi = new ProcessStartInfo(exePath) { UseShellExecute = true, Verb = "runas" };
                Process.Start(psi);
                Application.Current.Shutdown();
            }
            catch (System.ComponentModel.Win32Exception)
            {
                // User declined the UAC prompt - stay in the current (non-elevated) session.
            }
        }

        private void ScanButton_Click(object sender, RoutedEventArgs e)
        {
            ScanButton.IsEnabled = false;
            DetectInventoryButton.IsEnabled = false;
            CheckForUpdatesButton.IsEnabled = false;
            CheckSecurityButton.IsEnabled = false;
            SecurityEventsButton.IsEnabled = false;
            DetectHardwareButton.IsEnabled = false;
            ExportHtmlButton.IsEnabled = false;
            ExportCsvButton.IsEnabled = false;
            InstallSelectedButton.IsEnabled = false;
            InstallAllButton.IsEnabled = false;
            ScanProgressBar.Visibility = Visibility.Visible;
            SearchBox.Text = "";
            _updates.Clear();
            UpdateSummary();
            StatusText.Text = "Starting scan...";

            var thread = new Thread(() =>
            {
                try
                {
                    _scanner.StatusChanged -= OnScanStatus;
                    _scanner.StatusChanged += OnScanStatus;
                    var results = _scanner.ScanForMissingUpdates();

                    Dispatcher.Invoke(() =>
                    {
                        foreach (var r in results)
                            _updates.Add(r);

                        _lastScanTime = DateTime.Now;
                        UpdateSummary();
                        LastScanText.Text = $"Last scan: {_lastScanTime:yyyy-MM-dd HH:mm:ss}";
                        string baseStatus = results.Count == 0
                            ? "Scan complete. No missing updates found."
                            : $"Scan complete. {results.Count} missing update(s) found.";
                        StatusText.Text = string.IsNullOrEmpty(_scanner.LastUpdateSourceInfo)
                            ? baseStatus
                            : $"{baseStatus} {_scanner.LastUpdateSourceInfo}";
                        ScanButton.IsEnabled = true;
                        DetectInventoryButton.IsEnabled = true;
                        CheckForUpdatesButton.IsEnabled = true;
                        CheckSecurityButton.IsEnabled = true;
                        SecurityEventsButton.IsEnabled = true;
                        DetectHardwareButton.IsEnabled = true;
                        ExportHtmlButton.IsEnabled = true;
                        ExportCsvButton.IsEnabled = true;
                        RefreshElevationState();
                        ScanProgressBar.Visibility = Visibility.Collapsed;
                    });
                }
                catch (Exception ex)
                {
                    Dispatcher.Invoke(() =>
                    {
                        StatusText.Text = "Scan failed: " + ex.Message;
                        MessageBox.Show(ex.Message, "Scan Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        ScanButton.IsEnabled = true;
                        DetectInventoryButton.IsEnabled = true;
                        CheckForUpdatesButton.IsEnabled = true;
                        CheckSecurityButton.IsEnabled = true;
                        SecurityEventsButton.IsEnabled = true;
                        DetectHardwareButton.IsEnabled = true;
                        ScanProgressBar.Visibility = Visibility.Collapsed;
                    });
                }
            });
            thread.SetApartmentState(ApartmentState.STA);
            thread.IsBackground = true;
            thread.Start();
        }

        private void OnScanStatus(string msg) => Dispatcher.Invoke(() => StatusText.Text = msg);

        private void UpdateSummary()
        {
            int total = _updates.Count;
            int critical = _updates.Count(u => u.Severity == "Critical");
            int important = _updates.Count(u => u.Severity == "Important");
            int moderate = _updates.Count(u => u.Severity == "Moderate");
            int low = _updates.Count(u => u.Severity == "Low" || u.Severity == "Unspecified");
            double sizeMb = Math.Round(_updates.Sum(u => u.SizeMB), 1);

            TotalValue.Text = total.ToString();
            CriticalValue.Text = critical.ToString();
            ImportantValue.Text = important.ToString();
            ModerateValue.Text = moderate.ToString();
            LowValue.Text = low.ToString();
            SizeValue.Text = $"{sizeMb} MB";

            if (total > 0)
            {
                double peak = _updates.Max(u => u.ImpactScore);
                double avg = Math.Round(_updates.Average(u => u.ImpactScore), 1);
                RiskScoreValue.Text = peak.ToString("0.#", CultureInfo.InvariantCulture);
                RiskLabelText.Text = $"Avg {avg} · {total} finding(s)";
                var conv = new ImpactScoreToBrushConverter();
                RiskScoreValue.Foreground = (Brush)conv.Convert(peak, typeof(Brush), null!, CultureInfo.InvariantCulture)!;
            }
            else
            {
                RiskScoreValue.Text = "—";
                RiskLabelText.Text = "No scan yet";
                RiskScoreValue.Foreground = (Brush)FindResource("TextMutedBrush");
            }

            ResultCountText.Text = total > 0 ? $"{UpdatesView.Cast<object>().Count()} of {total} shown" : "";
        }

        private void SearchBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            string filter = SearchBox.Text?.Trim() ?? "";

            if (string.IsNullOrEmpty(filter))
            {
                UpdatesView.Filter = null;
            }
            else
            {
                UpdatesView.Filter = obj =>
                {
                    if (obj is not PatchInfo p) return false;
                    return p.Title.Contains(filter, StringComparison.OrdinalIgnoreCase)
                        || p.KB.Contains(filter, StringComparison.OrdinalIgnoreCase)
                        || p.Categories.Contains(filter, StringComparison.OrdinalIgnoreCase)
                        || p.Severity.Contains(filter, StringComparison.OrdinalIgnoreCase);
                };
            }

            ResultCountText.Text = _updates.Count > 0
                ? $"{UpdatesView.Cast<object>().Count()} of {_updates.Count} shown"
                : "";
        }

        private void SelectAllCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            // Only the rows currently visible under the active search filter - selecting
            // "all" shouldn't silently reach into rows the user has filtered out of view.
            foreach (var u in UpdatesView.Cast<PatchInfo>()) u.IsSelected = true;
        }

        private void SelectAllCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            foreach (var u in UpdatesView.Cast<PatchInfo>()) u.IsSelected = false;
        }

        private void Hyperlink_RequestNavigate(object sender, System.Windows.Navigation.RequestNavigateEventArgs e)
        {
            try
            {
                Process.Start(new ProcessStartInfo(e.Uri.AbsoluteUri) { UseShellExecute = true });
            }
            catch { /* ignore - no browser association etc. */ }
            e.Handled = true;
        }

        private void ExportHtmlButton_Click(object sender, RoutedEventArgs e)
        {
            ExportReport(
                extensionFilter: "HTML report (*.html)|*.html",
                fileExtension: "html",
                buildContent: () => HtmlReportBuilder.Build(_hostname, _osCaption, _osBuild, _updates.ToList(), _lastScanTime));
        }

        private void ExportCsvButton_Click(object sender, RoutedEventArgs e)
        {
            ExportReport(
                extensionFilter: "CSV file (*.csv)|*.csv",
                fileExtension: "csv",
                buildContent: () => CsvReportBuilder.Build(_hostname, _osCaption, _osBuild, _updates.ToList(), _lastScanTime));
        }

        private void ExportReport(string extensionFilter, string fileExtension, Func<string> buildContent)
        {
            if (_updates.Count == 0 && _lastScanTime == default)
            {
                MessageBox.Show("Run a scan first.", "Nothing to export", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var dialog = new SaveFileDialog
            {
                Filter = extensionFilter,
                FileName = $"PatchReport_{_hostname}_{DateTime.Now:yyyyMMdd_HHmmss}.{fileExtension}"
            };

            if (dialog.ShowDialog() != true) return;

            try
            {
                string content = buildContent();
                File.WriteAllText(dialog.FileName, content, System.Text.Encoding.UTF8);

                var result = MessageBox.Show("Report saved. Open it now?", "Export complete",
                    MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (result == MessageBoxResult.Yes)
                {
                    Process.Start(new ProcessStartInfo(dialog.FileName) { UseShellExecute = true });
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to save report: " + ex.Message, "Export Error",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void InstallSelectedButton_Click(object sender, RoutedEventArgs e)
        {
            StartInstall(_updates.Where(u => u.IsSelected).ToList());
        }

        private void InstallAllButton_Click(object sender, RoutedEventArgs e)
        {
            StartInstall(_updates.ToList());
        }

        private void StartInstall(System.Collections.Generic.List<PatchInfo> targets)
        {
            if (targets.Count == 0)
            {
                MessageBox.Show("No updates selected. Tick the checkbox next to the updates you want to install, " +
                    "or use INSTALL ALL.", "Nothing to install", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            if (!IsRunningAsAdministrator())
            {
                MessageBox.Show("Installing updates requires administrator rights. Use \"Restart as Administrator\" first.",
                    "Administrator required", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var confirm = MessageBox.Show(
                $"This will download and install {targets.Count} update(s) on THIS machine right now.\n\n" +
                "Some updates may require a restart to finish applying. Make sure you have saved your work " +
                "and, if this is a production machine, that this is an approved maintenance window.\n\n" +
                "Continue?",
                "Confirm installation", MessageBoxButton.YesNo, MessageBoxImage.Warning);

            if (confirm != MessageBoxResult.Yes) return;

            ScanButton.IsEnabled = false;
            DetectInventoryButton.IsEnabled = false;
            CheckForUpdatesButton.IsEnabled = false;
            CheckSecurityButton.IsEnabled = false;
            SecurityEventsButton.IsEnabled = false;
            DetectHardwareButton.IsEnabled = false;
            ExportHtmlButton.IsEnabled = false;
            ExportCsvButton.IsEnabled = false;
            InstallSelectedButton.IsEnabled = false;
            InstallAllButton.IsEnabled = false;
            ScanProgressBar.Visibility = Visibility.Visible;
            StatusText.Text = "Preparing install...";

            foreach (var t in targets) t.InstallStatus = "Queued";

            var thread = new Thread(() =>
            {
                try
                {
                    var summary = _scanner.InstallUpdates(targets, msg => Dispatcher.Invoke(() => StatusText.Text = msg));

                    Dispatcher.Invoke(() =>
                    {
                        foreach (var result in summary.Results)
                        {
                            var match = _updates.FirstOrDefault(u => u.UpdateId == result.UpdateId);
                            if (match != null) match.InstallStatus = result.Status;
                        }

                        StatusText.Text = summary.OverallMessage;
                        ScanButton.IsEnabled = true;
                        DetectInventoryButton.IsEnabled = true;
                        CheckForUpdatesButton.IsEnabled = true;
                        CheckSecurityButton.IsEnabled = true;
                        SecurityEventsButton.IsEnabled = true;
                        DetectHardwareButton.IsEnabled = true;
                        ExportHtmlButton.IsEnabled = true;
                        ExportCsvButton.IsEnabled = true;
                        ScanProgressBar.Visibility = Visibility.Collapsed;
                        RefreshElevationState();

                        if (summary.RebootRequired)
                        {
                            MessageBox.Show("One or more updates require a restart to finish installing.",
                                "Restart required", MessageBoxButton.OK, MessageBoxImage.Information);
                        }
                    });
                }
                catch (Exception ex)
                {
                    Dispatcher.Invoke(() =>
                    {
                        foreach (var t in targets)
                        {
                            if (t.InstallStatus == "Queued") t.InstallStatus = "Failed";
                        }
                        StatusText.Text = "Install failed: " + ex.Message;
                        MessageBox.Show(ex.Message, "Install Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        ScanButton.IsEnabled = true;
                        DetectInventoryButton.IsEnabled = true;
                        CheckForUpdatesButton.IsEnabled = true;
                        CheckSecurityButton.IsEnabled = true;
                        SecurityEventsButton.IsEnabled = true;
                        DetectHardwareButton.IsEnabled = true;
                        ExportHtmlButton.IsEnabled = true;
                        ExportCsvButton.IsEnabled = true;
                        ScanProgressBar.Visibility = Visibility.Collapsed;
                        RefreshElevationState();
                    });
                }
            });
            thread.SetApartmentState(ApartmentState.STA);
            thread.IsBackground = true;
            thread.Start();
        }

        // ================= Installed Applications & Services =================

        private void DetectInventoryButton_Click(object sender, RoutedEventArgs e)
        {
            ScanButton.IsEnabled = false;
            DetectInventoryButton.IsEnabled = false;
            CheckForUpdatesButton.IsEnabled = false;
            CheckSecurityButton.IsEnabled = false;
            SecurityEventsButton.IsEnabled = false;
            DetectHardwareButton.IsEnabled = false;
            ExportAppsCsvButton.IsEnabled = false;
            ExportServicesCsvButton.IsEnabled = false;
            ExportAppsHtmlButton.IsEnabled = false;
            ExportServicesHtmlButton.IsEnabled = false;
            ExportUpdatesHtmlButton.IsEnabled = _appUpdates.Count > 0;
            ScanProgressBar.Visibility = Visibility.Visible;
            AppsSearchBox.Text = "";
            ServicesSearchBox.Text = "";
            _apps.Clear();
            _services.Clear();
            UpdateAppsSummary();
            UpdateServicesSummary();
            StatusText.Text = "Starting application & service detection...";

            var thread = new Thread(() =>
            {
                try
                {
                    _inventoryScanner.StatusChanged -= OnScanStatus;
                    _inventoryScanner.StatusChanged += OnScanStatus;

                    var apps = _inventoryScanner.ScanInstalledApplications();
                    var services = _inventoryScanner.ScanServices();

                    Dispatcher.Invoke(() =>
                    {
                        foreach (var a in apps) _apps.Add(a);
                        foreach (var s in services) _services.Add(s);

                        _lastInventoryScanTime = DateTime.Now;
                        UpdateAppsSummary();
                        UpdateServicesSummary();

                        StatusText.Text = $"Detection complete. {apps.Count} application(s), {services.Count} service(s) found.";
                        ScanButton.IsEnabled = true;
                        DetectInventoryButton.IsEnabled = true;
                        CheckForUpdatesButton.IsEnabled = true;
                        CheckSecurityButton.IsEnabled = true;
                        SecurityEventsButton.IsEnabled = true;
                        DetectHardwareButton.IsEnabled = true;
                        ExportAppsCsvButton.IsEnabled = apps.Count > 0;
                        ExportServicesCsvButton.IsEnabled = services.Count > 0;
                        RefreshInventoryHtmlExportButtons();
                        ScanProgressBar.Visibility = Visibility.Collapsed;
                    });
                }
                catch (Exception ex)
                {
                    Dispatcher.Invoke(() =>
                    {
                        StatusText.Text = "Detection failed: " + ex.Message;
                        MessageBox.Show(ex.Message, "Detection Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        ScanButton.IsEnabled = true;
                        DetectInventoryButton.IsEnabled = true;
                        CheckForUpdatesButton.IsEnabled = true;
                        CheckSecurityButton.IsEnabled = true;
                        SecurityEventsButton.IsEnabled = true;
                        DetectHardwareButton.IsEnabled = true;
                        ScanProgressBar.Visibility = Visibility.Collapsed;
                    });
                }
            });
            thread.SetApartmentState(ApartmentState.STA);
            thread.IsBackground = true;
            thread.Start();
        }

        private void UpdateAppsSummary()
        {
            int total = _apps.Count;
            int microsoft = _apps.Count(a => a.IsMicrosoft);
            int nonMicrosoft = total - microsoft;
            double sizeMb = Math.Round(_apps.Sum(a => a.SizeMB), 1);

            AppsTotalValue.Text = total.ToString();
            AppsMicrosoftValue.Text = microsoft.ToString();
            AppsNonMicrosoftValue.Text = nonMicrosoft.ToString();
            AppsSizeValue.Text = $"{sizeMb} MB";

            AppsResultCountText.Text = total > 0 ? $"{AppsView.Cast<object>().Count()} of {total} shown" : "";
        }

        private void UpdateServicesSummary()
        {
            int total = _services.Count;
            int running = _services.Count(s => s.State == "Running");
            int stopped = total - running;
            int microsoft = _services.Count(s => s.IsMicrosoft);
            int nonMicrosoft = total - microsoft;

            ServicesTotalValue.Text = total.ToString();
            ServicesRunningValue.Text = running.ToString();
            ServicesStoppedValue.Text = stopped.ToString();
            ServicesMicrosoftValue.Text = microsoft.ToString();
            ServicesNonMicrosoftValue.Text = nonMicrosoft.ToString();

            ServicesResultCountText.Text = total > 0 ? $"{ServicesView.Cast<object>().Count()} of {total} shown" : "";
        }

        /// <summary>Keeps the three EXPORT HTML buttons (Apps / Services / Updates tabs) in sync - they all
        /// produce the same combined report, so they should all be enabled exactly when there's anything to show.</summary>
        private void RefreshInventoryHtmlExportButtons()
        {
            bool hasAnything = _apps.Count > 0 || _services.Count > 0 || _appUpdates.Count > 0;
            ExportAppsHtmlButton.IsEnabled = hasAnything;
            ExportServicesHtmlButton.IsEnabled = hasAnything;
            ExportUpdatesHtmlButton.IsEnabled = hasAnything;
        }

        private void AppsSearchBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            string filter = AppsSearchBox.Text?.Trim() ?? "";

            AppsView.Filter = string.IsNullOrEmpty(filter)
                ? null
                : obj =>
                {
                    if (obj is not ApplicationInfo a) return false;
                    return a.Name.Contains(filter, StringComparison.OrdinalIgnoreCase)
                        || a.Publisher.Contains(filter, StringComparison.OrdinalIgnoreCase)
                        || a.VendorGroup.Contains(filter, StringComparison.OrdinalIgnoreCase);
                };

            AppsResultCountText.Text = _apps.Count > 0
                ? $"{AppsView.Cast<object>().Count()} of {_apps.Count} shown"
                : "";
        }

        private void ServicesSearchBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            string filter = ServicesSearchBox.Text?.Trim() ?? "";

            ServicesView.Filter = string.IsNullOrEmpty(filter)
                ? null
                : obj =>
                {
                    if (obj is not ServiceInfo s) return false;
                    return s.DisplayName.Contains(filter, StringComparison.OrdinalIgnoreCase)
                        || s.Name.Contains(filter, StringComparison.OrdinalIgnoreCase)
                        || s.Publisher.Contains(filter, StringComparison.OrdinalIgnoreCase)
                        || s.PathName.Contains(filter, StringComparison.OrdinalIgnoreCase)
                        || s.VendorGroup.Contains(filter, StringComparison.OrdinalIgnoreCase);
                };

            ServicesResultCountText.Text = _services.Count > 0
                ? $"{ServicesView.Cast<object>().Count()} of {_services.Count} shown"
                : "";
        }

        private void ExportInventoryHtmlButton_Click(object sender, RoutedEventArgs e)
        {
            if (_apps.Count == 0 && _services.Count == 0 && _appUpdates.Count == 0)
            {
                MessageBox.Show("Run DETECT APPS & SERVICES or CHECK FOR UPDATES first.", "Nothing to export",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var dialog = new SaveFileDialog
            {
                Filter = "HTML report (*.html)|*.html",
                FileName = $"AppsServicesUpdatesReport_{_hostname}_{DateTime.Now:yyyyMMdd_HHmmss}.html"
            };
            if (dialog.ShowDialog() != true) return;

            try
            {
                var reportTime = _lastUpdatesScanTime > _lastInventoryScanTime ? _lastUpdatesScanTime : _lastInventoryScanTime;
                if (reportTime == default) reportTime = DateTime.Now;

                string html = InventoryHtmlReportBuilder.Build(_hostname, _osCaption, _osBuild,
                    _apps.ToList(), _services.ToList(), reportTime, _appUpdates.ToList());
                File.WriteAllText(dialog.FileName, html, System.Text.Encoding.UTF8);

                var result = MessageBox.Show("Report saved. Open it now?", "Export complete",
                    MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (result == MessageBoxResult.Yes)
                    Process.Start(new ProcessStartInfo(dialog.FileName) { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to save report: " + ex.Message, "Export Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ExportAppsCsvButton_Click(object sender, RoutedEventArgs e)
        {
            if (_apps.Count == 0)
            {
                MessageBox.Show("Run DETECT APPS & SERVICES first.", "Nothing to export",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var dialog = new SaveFileDialog
            {
                Filter = "CSV file (*.csv)|*.csv",
                FileName = $"InstalledApplications_{_hostname}_{DateTime.Now:yyyyMMdd_HHmmss}.csv"
            };
            if (dialog.ShowDialog() != true) return;

            try
            {
                string csv = InventoryCsvBuilder.BuildApplications(_hostname, _apps.ToList(), _lastInventoryScanTime);
                File.WriteAllText(dialog.FileName, csv, System.Text.Encoding.UTF8);

                var result = MessageBox.Show("CSV saved. Open it now?", "Export complete",
                    MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (result == MessageBoxResult.Yes)
                    Process.Start(new ProcessStartInfo(dialog.FileName) { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to save CSV: " + ex.Message, "Export Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ExportServicesCsvButton_Click(object sender, RoutedEventArgs e)
        {
            if (_services.Count == 0)
            {
                MessageBox.Show("Run DETECT APPS & SERVICES first.", "Nothing to export",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var dialog = new SaveFileDialog
            {
                Filter = "CSV file (*.csv)|*.csv",
                FileName = $"WindowsServices_{_hostname}_{DateTime.Now:yyyyMMdd_HHmmss}.csv"
            };
            if (dialog.ShowDialog() != true) return;

            try
            {
                string csv = InventoryCsvBuilder.BuildServices(_hostname, _services.ToList(), _lastInventoryScanTime);
                File.WriteAllText(dialog.FileName, csv, System.Text.Encoding.UTF8);

                var result = MessageBox.Show("CSV saved. Open it now?", "Export complete",
                    MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (result == MessageBoxResult.Yes)
                    Process.Start(new ProcessStartInfo(dialog.FileName) { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to save CSV: " + ex.Message, "Export Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // ================= Application Updates (winget) =================

        private void CheckForUpdatesButton_Click(object sender, RoutedEventArgs e)
        {
            ScanButton.IsEnabled = false;
            DetectInventoryButton.IsEnabled = false;
            CheckForUpdatesButton.IsEnabled = false;
            CheckSecurityButton.IsEnabled = false;
            SecurityEventsButton.IsEnabled = false;
            DetectHardwareButton.IsEnabled = false;
            UpgradeSelectedButton.IsEnabled = false;
            UpgradeAllButton.IsEnabled = false;
            ExportUpdatesCsvButton.IsEnabled = false;
            ScanProgressBar.Visibility = Visibility.Visible;
            UpdatesSearchBox.Text = "";
            _appUpdates.Clear();
            UpdateUpdatesSummary();
            StatusText.Text = "Starting application update check...";

            var thread = new Thread(() =>
            {
                try
                {
                    _wingetScanner.StatusChanged -= OnScanStatus;
                    _wingetScanner.StatusChanged += OnScanStatus;

                    var updates = _wingetScanner.ScanForUpdates();

                    Dispatcher.Invoke(() =>
                    {
                        foreach (var u in updates) _appUpdates.Add(u);

                        _lastUpdatesScanTime = DateTime.Now;
                        UpdateUpdatesSummary();

                        StatusText.Text = updates.Count == 0
                            ? "Update check complete. Everything winget tracks is up to date."
                            : $"Update check complete. {updates.Count} application update(s) available.";
                        ScanButton.IsEnabled = true;
                        DetectInventoryButton.IsEnabled = true;
                        CheckForUpdatesButton.IsEnabled = true;
                        CheckSecurityButton.IsEnabled = true;
                        SecurityEventsButton.IsEnabled = true;
                        DetectHardwareButton.IsEnabled = true;
                        UpgradeSelectedButton.IsEnabled = updates.Count > 0;
                        UpgradeAllButton.IsEnabled = updates.Count > 0;
                        ExportUpdatesCsvButton.IsEnabled = updates.Count > 0;
                        RefreshInventoryHtmlExportButtons();
                        ScanProgressBar.Visibility = Visibility.Collapsed;
                    });
                }
                catch (Exception ex)
                {
                    Dispatcher.Invoke(() =>
                    {
                        StatusText.Text = "Update check failed: " + ex.Message;
                        MessageBox.Show(ex.Message, "Update Check Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        ScanButton.IsEnabled = true;
                        DetectInventoryButton.IsEnabled = true;
                        CheckForUpdatesButton.IsEnabled = true;
                        CheckSecurityButton.IsEnabled = true;
                        SecurityEventsButton.IsEnabled = true;
                        DetectHardwareButton.IsEnabled = true;
                        ScanProgressBar.Visibility = Visibility.Collapsed;
                    });
                }
            });
            thread.SetApartmentState(ApartmentState.STA);
            thread.IsBackground = true;
            thread.Start();
        }

        private void UpdateUpdatesSummary()
        {
            int total = _appUpdates.Count;
            UpdatesTotalValue.Text = total.ToString();
            UpdatesResultCountText.Text = total > 0 ? $"{AppUpdatesView.Cast<object>().Count()} of {total} shown" : "";
        }

        private void UpdatesSearchBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            string filter = UpdatesSearchBox.Text?.Trim() ?? "";

            AppUpdatesView.Filter = string.IsNullOrEmpty(filter)
                ? null
                : obj =>
                {
                    if (obj is not AppUpdateInfo u) return false;
                    return u.Name.Contains(filter, StringComparison.OrdinalIgnoreCase)
                        || u.PackageId.Contains(filter, StringComparison.OrdinalIgnoreCase)
                        || u.Source.Contains(filter, StringComparison.OrdinalIgnoreCase);
                };

            UpdatesResultCountText.Text = _appUpdates.Count > 0
                ? $"{AppUpdatesView.Cast<object>().Count()} of {_appUpdates.Count} shown"
                : "";
        }

        private void SelectAllUpdatesCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            // Only the rows currently visible under the active search filter.
            foreach (var u in AppUpdatesView.Cast<AppUpdateInfo>()) u.IsSelected = true;
        }

        private void SelectAllUpdatesCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            foreach (var u in AppUpdatesView.Cast<AppUpdateInfo>()) u.IsSelected = false;
        }

        private void UpgradeSelectedButton_Click(object sender, RoutedEventArgs e)
        {
            StartUpgrade(_appUpdates.Where(u => u.IsSelected).ToList());
        }

        private void UpgradeAllButton_Click(object sender, RoutedEventArgs e)
        {
            StartUpgrade(_appUpdates.ToList());
        }

        private void StartUpgrade(System.Collections.Generic.List<AppUpdateInfo> targets)
        {
            if (targets.Count == 0)
            {
                MessageBox.Show("No updates selected. Tick the checkbox next to the applications you want to " +
                    "upgrade, or use UPGRADE ALL.", "Nothing to upgrade", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var confirm = MessageBox.Show(
                $"This will use winget to silently download and upgrade {targets.Count} application(s) on THIS " +
                "machine right now.\n\nSome installers may still show a UAC prompt or a brief window even in " +
                "silent mode, and a few apps don't support unattended upgrades at all (they'll be reported as " +
                "failed). Make sure you have saved your work first.\n\nContinue?",
                "Confirm upgrade", MessageBoxButton.YesNo, MessageBoxImage.Warning);

            if (confirm != MessageBoxResult.Yes) return;

            ScanButton.IsEnabled = false;
            DetectInventoryButton.IsEnabled = false;
            CheckForUpdatesButton.IsEnabled = false;
            CheckSecurityButton.IsEnabled = false;
            SecurityEventsButton.IsEnabled = false;
            DetectHardwareButton.IsEnabled = false;
            UpgradeSelectedButton.IsEnabled = false;
            UpgradeAllButton.IsEnabled = false;
            ScanProgressBar.Visibility = Visibility.Visible;
            StatusText.Text = "Preparing upgrade...";

            foreach (var t in targets) t.UpgradeStatus = "Queued";

            var thread = new Thread(() =>
            {
                try
                {
                    var summary = _wingetScanner.UpgradePackages(targets, msg => Dispatcher.Invoke(() => StatusText.Text = msg));

                    Dispatcher.Invoke(() =>
                    {
                        foreach (var result in summary.Results)
                        {
                            var match = _appUpdates.FirstOrDefault(u => u.PackageId == result.PackageId);
                            if (match != null) match.UpgradeStatus = result.Status;
                        }

                        StatusText.Text = summary.OverallMessage;
                        ScanButton.IsEnabled = true;
                        DetectInventoryButton.IsEnabled = true;
                        CheckForUpdatesButton.IsEnabled = true;
                        CheckSecurityButton.IsEnabled = true;
                        SecurityEventsButton.IsEnabled = true;
                        DetectHardwareButton.IsEnabled = true;
                        UpgradeSelectedButton.IsEnabled = _appUpdates.Count > 0;
                        UpgradeAllButton.IsEnabled = _appUpdates.Count > 0;
                        ScanProgressBar.Visibility = Visibility.Collapsed;
                    });
                }
                catch (Exception ex)
                {
                    Dispatcher.Invoke(() =>
                    {
                        foreach (var t in targets)
                        {
                            if (t.UpgradeStatus == "Queued") t.UpgradeStatus = "Failed";
                        }
                        StatusText.Text = "Upgrade failed: " + ex.Message;
                        MessageBox.Show(ex.Message, "Upgrade Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        ScanButton.IsEnabled = true;
                        DetectInventoryButton.IsEnabled = true;
                        CheckForUpdatesButton.IsEnabled = true;
                        CheckSecurityButton.IsEnabled = true;
                        SecurityEventsButton.IsEnabled = true;
                        DetectHardwareButton.IsEnabled = true;
                        UpgradeSelectedButton.IsEnabled = _appUpdates.Count > 0;
                        UpgradeAllButton.IsEnabled = _appUpdates.Count > 0;
                        ScanProgressBar.Visibility = Visibility.Collapsed;
                    });
                }
            });
            thread.SetApartmentState(ApartmentState.STA);
            thread.IsBackground = true;
            thread.Start();
        }

        private void ExportUpdatesCsvButton_Click(object sender, RoutedEventArgs e)
        {
            if (_appUpdates.Count == 0)
            {
                MessageBox.Show("Run CHECK FOR UPDATES first.", "Nothing to export",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var dialog = new SaveFileDialog
            {
                Filter = "CSV file (*.csv)|*.csv",
                FileName = $"ApplicationUpdates_{_hostname}_{DateTime.Now:yyyyMMdd_HHmmss}.csv"
            };
            if (dialog.ShowDialog() != true) return;

            try
            {
                string csv = InventoryCsvBuilder.BuildAppUpdates(_hostname, _appUpdates.ToList(), _lastUpdatesScanTime);
                File.WriteAllText(dialog.FileName, csv, System.Text.Encoding.UTF8);

                var result = MessageBox.Show("CSV saved. Open it now?", "Export complete",
                    MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (result == MessageBoxResult.Yes)
                    Process.Start(new ProcessStartInfo(dialog.FileName) { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to save CSV: " + ex.Message, "Export Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // ================= Security Center (Microsoft Defender / Windows Security) =================

        private void CheckSecurityButton_Click(object sender, RoutedEventArgs e)
        {
            ScanButton.IsEnabled = false;
            DetectInventoryButton.IsEnabled = false;
            CheckForUpdatesButton.IsEnabled = false;
            CheckSecurityButton.IsEnabled = false;
            SecurityEventsButton.IsEnabled = false;
            DetectHardwareButton.IsEnabled = false;
            ExportSecurityHtmlButton.IsEnabled = false;
            ExportSecurityCsvButton.IsEnabled = false;
            ScanProgressBar.Visibility = Visibility.Visible;
            ThreatsSearchBox.Text = "";
            HistorySearchBox.Text = "";
            _threats.Clear();
            _protectionHistory.Clear();
            _securityIssues.Clear();
            _securityStatus = new DefenderStatusInfo();
            UpdateSecuritySummary();
            StatusText.Text = "Starting security status check...";

            var thread = new Thread(() =>
            {
                try
                {
                    _securityScanner.StatusChanged -= OnScanStatus;
                    _securityScanner.StatusChanged += OnScanStatus;

                    var result = _securityScanner.Scan();

                    Dispatcher.Invoke(() =>
                    {
                        _securityStatus = result.Status;
                        foreach (var t in result.Threats) _threats.Add(t);
                        foreach (var h in result.ProtectionHistory) _protectionHistory.Add(h);
                        foreach (var i in result.Issues) _securityIssues.Add(i);

                        _lastSecurityScanTime = DateTime.Now;
                        UpdateSecuritySummary();

                        StatusText.Text = result.Issues.Count == 0
                            ? "Security status check complete. No issues flagged."
                            : $"Security status check complete. {result.Issues.Count} issue(s) flagged.";
                        ScanButton.IsEnabled = true;
                        DetectInventoryButton.IsEnabled = true;
                        CheckForUpdatesButton.IsEnabled = true;
                        CheckSecurityButton.IsEnabled = true;
                        SecurityEventsButton.IsEnabled = true;
                        DetectHardwareButton.IsEnabled = true;
                        ExportSecurityHtmlButton.IsEnabled = true;
                        ExportSecurityCsvButton.IsEnabled = true;
                        ScanProgressBar.Visibility = Visibility.Collapsed;
                    });
                }
                catch (Exception ex)
                {
                    Dispatcher.Invoke(() =>
                    {
                        StatusText.Text = "Security status check failed: " + ex.Message;
                        MessageBox.Show(ex.Message, "Security Check Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        ScanButton.IsEnabled = true;
                        DetectInventoryButton.IsEnabled = true;
                        CheckForUpdatesButton.IsEnabled = true;
                        CheckSecurityButton.IsEnabled = true;
                        SecurityEventsButton.IsEnabled = true;
                        DetectHardwareButton.IsEnabled = true;
                        ScanProgressBar.Visibility = Visibility.Collapsed;
                    });
                }
            });
            thread.SetApartmentState(ApartmentState.STA);
            thread.IsBackground = true;
            thread.Start();
        }

        private void UpdateSecuritySummary()
        {
            var s = _securityStatus;

            SecurityOverallValue.Text = _lastSecurityScanTime == default
                ? "No scan yet"
                : (_securityIssues.Count == 0 ? "No issues flagged" : $"{_securityIssues[0].Severity} ({_securityIssues.Count} flagged)");

            DefenderRunStatusValue.Text = YesNo(s.AntivirusEnabled);
            RealTimeProtectionValue.Text = YesNo(s.RealTimeProtectionEnabled);
            LastSignatureValue.Text = DateText(s.AntivirusSignatureLastUpdated);
            LastFullScanValue.Text = DateText(s.FullScanEndTime);
            LastQuickScanValue.Text = DateText(s.QuickScanEndTime);

            SmartScreenAppsValue.Text = string.IsNullOrEmpty(s.SmartScreenAppsFilesStatus) ? "—" : s.SmartScreenAppsFilesStatus;
            SmartScreenEdgeValue.Text = string.IsNullOrEmpty(s.SmartScreenEdgeStatus) ? "—" : s.SmartScreenEdgeStatus;
            ExploitProtectionValue.Text = string.IsNullOrEmpty(s.ExploitProtectionSummary) ? "—" : s.ExploitProtectionSummary;

            MemoryIntegrityValue.Text = YesNo(s.MemoryIntegrityEnabled);
            SecureBootValue.Text = YesNo(s.SecureBootEnabled);
            TpmValue.Text = s.TpmPresent == true
                ? (s.TpmEnabled == true ? $"Present, Enabled (v{s.TpmSpecVersion})" : "Present, Not Enabled")
                : YesNo(s.TpmPresent);

            DriveFreeValue.Text = s.SystemDriveTotalGB > 0
                ? $"{s.SystemDriveFreeGB:0.#} GB ({s.SystemDriveFreePercent:0.#}%)"
                : "—";
            LastBootValue.Text = DateText(s.LastBootUpTime);
        }

        private static string YesNo(bool? b) => b.HasValue ? (b.Value ? "Yes" : "No") : "N/A";
        private static string DateText(DateTime? d) => d.HasValue ? d.Value.ToString("yyyy-MM-dd HH:mm") : "N/A";

        private void ThreatsSearchBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            string filter = ThreatsSearchBox.Text?.Trim() ?? "";

            ThreatsView.Filter = string.IsNullOrEmpty(filter)
                ? null
                : obj =>
                {
                    if (obj is not ThreatDetectionInfo t) return false;
                    return t.ThreatName.Contains(filter, StringComparison.OrdinalIgnoreCase)
                        || t.Category.Contains(filter, StringComparison.OrdinalIgnoreCase)
                        || t.ProcessName.Contains(filter, StringComparison.OrdinalIgnoreCase);
                };
        }

        private void HistorySearchBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            string filter = HistorySearchBox.Text?.Trim() ?? "";

            HistoryView.Filter = string.IsNullOrEmpty(filter)
                ? null
                : obj =>
                {
                    if (obj is not ProtectionEventInfo ev) return false;
                    return ev.Category.Contains(filter, StringComparison.OrdinalIgnoreCase)
                        || ev.Message.Contains(filter, StringComparison.OrdinalIgnoreCase);
                };
        }

        private void ExportSecurityHtmlButton_Click(object sender, RoutedEventArgs e)
        {
            if (_lastSecurityScanTime == default)
            {
                MessageBox.Show("Run CHECK SECURITY STATUS first.", "Nothing to export",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var dialog = new SaveFileDialog
            {
                Filter = "HTML report (*.html)|*.html",
                FileName = $"SecurityStatusReport_{_hostname}_{DateTime.Now:yyyyMMdd_HHmmss}.html"
            };
            if (dialog.ShowDialog() != true) return;

            try
            {
                string html = SecurityHtmlReportBuilder.Build(_hostname, _osCaption, _osBuild, _securityStatus,
                    _threats.ToList(), _protectionHistory.ToList(), _securityIssues.ToList(), _lastSecurityScanTime);
                File.WriteAllText(dialog.FileName, html, System.Text.Encoding.UTF8);

                var result = MessageBox.Show("Report saved. Open it now?", "Export complete",
                    MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (result == MessageBoxResult.Yes)
                    Process.Start(new ProcessStartInfo(dialog.FileName) { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to save report: " + ex.Message, "Export Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ExportSecurityCsvButton_Click(object sender, RoutedEventArgs e)
        {
            if (_lastSecurityScanTime == default)
            {
                MessageBox.Show("Run CHECK SECURITY STATUS first.", "Nothing to export",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var dialog = new SaveFileDialog
            {
                Filter = "CSV file (*.csv)|*.csv",
                FileName = $"SecurityStatusReport_{_hostname}_{DateTime.Now:yyyyMMdd_HHmmss}.csv"
            };
            if (dialog.ShowDialog() != true) return;

            try
            {
                string csv = SecurityCsvBuilder.Build(_hostname, _securityStatus, _threats.ToList(),
                    _protectionHistory.ToList(), _securityIssues.ToList(), _lastSecurityScanTime);
                File.WriteAllText(dialog.FileName, csv, System.Text.Encoding.UTF8);

                var result = MessageBox.Show("CSV saved. Open it now?", "Export complete",
                    MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (result == MessageBoxResult.Yes)
                    Process.Start(new ProcessStartInfo(dialog.FileName) { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to save CSV: " + ex.Message, "Export Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // ================= Security Events (log capture & investigation) =================

        private void SecurityEventsButton_Click(object sender, RoutedEventArgs e)
        {
            ScanButton.IsEnabled = false;
            DetectInventoryButton.IsEnabled = false;
            CheckForUpdatesButton.IsEnabled = false;
            CheckSecurityButton.IsEnabled = false;
            SecurityEventsButton.IsEnabled = false;
            DetectHardwareButton.IsEnabled = false;
            ExportSecurityEventsHtmlButton.IsEnabled = false;
            ExportSecurityEventsCsvButton.IsEnabled = false;
            ScanProgressBar.Visibility = Visibility.Visible;
            EventsSearchBox.Text = "";
            _securityEvents.Clear();
            _securityFindings.Clear();
            UpdateSecurityEventsSummary();
            StatusText.Text = "Starting security event capture...";

            var thread = new Thread(() =>
            {
                try
                {
                    _securityEventScanner.StatusChanged -= OnScanStatus;
                    _securityEventScanner.StatusChanged += OnScanStatus;

                    var result = _securityEventScanner.Scan();

                    Dispatcher.Invoke(() =>
                    {
                        foreach (var ev in result.Events) _securityEvents.Add(ev);
                        foreach (var f in result.Findings) _securityFindings.Add(f);

                        _lastSecurityEventsScanTime = DateTime.Now;
                        _lastSecurityEventsLookbackDays = result.LookbackDays;
                        UpdateSecurityEventsSummary();

                        StatusText.Text = result.Findings.Count == 0
                            ? $"Security event capture complete. {result.Events.Count} event(s) captured, nothing correlated stands out."
                            : $"Security event capture complete. {result.Events.Count} event(s) captured, {result.Findings.Count} finding(s) flagged.";
                        ScanButton.IsEnabled = true;
                        DetectInventoryButton.IsEnabled = true;
                        CheckForUpdatesButton.IsEnabled = true;
                        CheckSecurityButton.IsEnabled = true;
                        SecurityEventsButton.IsEnabled = true;
                        DetectHardwareButton.IsEnabled = true;
                        ExportSecurityEventsHtmlButton.IsEnabled = true;
                        ExportSecurityEventsCsvButton.IsEnabled = true;
                        ScanProgressBar.Visibility = Visibility.Collapsed;
                    });
                }
                catch (Exception ex)
                {
                    Dispatcher.Invoke(() =>
                    {
                        StatusText.Text = "Security event capture failed: " + ex.Message;
                        MessageBox.Show(ex.Message, "Security Events Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        ScanButton.IsEnabled = true;
                        DetectInventoryButton.IsEnabled = true;
                        CheckForUpdatesButton.IsEnabled = true;
                        CheckSecurityButton.IsEnabled = true;
                        SecurityEventsButton.IsEnabled = true;
                        DetectHardwareButton.IsEnabled = true;
                        ScanProgressBar.Visibility = Visibility.Collapsed;
                    });
                }
            });
            thread.SetApartmentState(ApartmentState.STA);
            thread.IsBackground = true;
            thread.Start();
        }

        private void UpdateSecurityEventsSummary()
        {
            int total = _securityEvents.Count;
            int critical = _securityEvents.Count(ev => ev.Severity == "Critical");
            int high = _securityEvents.Count(ev => ev.Severity == "High");
            int medium = _securityEvents.Count(ev => ev.Severity == "Medium");

            EventsTotalValue.Text = total.ToString();
            EventsCriticalValue.Text = critical.ToString();
            EventsHighValue.Text = high.ToString();
            EventsMediumValue.Text = medium.ToString();
            FindingsTotalValue.Text = _securityFindings.Count.ToString();

            SecurityEventsOverallValue.Text = _lastSecurityEventsScanTime == default
                ? "No scan yet"
                : (_securityFindings.Count == 0 ? "No findings flagged" : $"{_securityFindings[0].Severity} ({_securityFindings.Count} finding(s))");
        }

        private void EventsSearchBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            string filter = EventsSearchBox.Text?.Trim() ?? "";

            SecurityEventsView.Filter = string.IsNullOrEmpty(filter)
                ? null
                : obj =>
                {
                    if (obj is not SecurityEventInfo ev) return false;
                    return ev.Channel.Contains(filter, StringComparison.OrdinalIgnoreCase)
                        || ev.Category.Contains(filter, StringComparison.OrdinalIgnoreCase)
                        || ev.Account.Contains(filter, StringComparison.OrdinalIgnoreCase)
                        || ev.Source.Contains(filter, StringComparison.OrdinalIgnoreCase)
                        || ev.Message.Contains(filter, StringComparison.OrdinalIgnoreCase);
                };
        }

        private void ExportSecurityEventsHtmlButton_Click(object sender, RoutedEventArgs e)
        {
            if (_lastSecurityEventsScanTime == default)
            {
                MessageBox.Show("Run SCAN SECURITY EVENTS first.", "Nothing to export",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var dialog = new SaveFileDialog
            {
                Filter = "HTML report (*.html)|*.html",
                FileName = $"SecurityEventsReport_{_hostname}_{DateTime.Now:yyyyMMdd_HHmmss}.html"
            };
            if (dialog.ShowDialog() != true) return;

            try
            {
                string html = SecurityEventHtmlReportBuilder.Build(_hostname, _osCaption, _osBuild,
                    _securityEvents.ToList(), _securityFindings.ToList(), _lastSecurityEventsLookbackDays, _lastSecurityEventsScanTime);
                File.WriteAllText(dialog.FileName, html, System.Text.Encoding.UTF8);

                var result = MessageBox.Show("Report saved. Open it now?", "Export complete",
                    MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (result == MessageBoxResult.Yes)
                    Process.Start(new ProcessStartInfo(dialog.FileName) { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to save report: " + ex.Message, "Export Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ExportSecurityEventsCsvButton_Click(object sender, RoutedEventArgs e)
        {
            if (_lastSecurityEventsScanTime == default)
            {
                MessageBox.Show("Run SCAN SECURITY EVENTS first.", "Nothing to export",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var dialog = new SaveFileDialog
            {
                Filter = "CSV file (*.csv)|*.csv",
                FileName = $"SecurityEventsReport_{_hostname}_{DateTime.Now:yyyyMMdd_HHmmss}.csv"
            };
            if (dialog.ShowDialog() != true) return;

            try
            {
                string csv = SecurityEventCsvBuilder.Build(_hostname, _securityEvents.ToList(),
                    _securityFindings.ToList(), _lastSecurityEventsLookbackDays, _lastSecurityEventsScanTime);
                File.WriteAllText(dialog.FileName, csv, System.Text.Encoding.UTF8);

                var result = MessageBox.Show("CSV saved. Open it now?", "Export complete",
                    MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (result == MessageBoxResult.Yes)
                    Process.Start(new ProcessStartInfo(dialog.FileName) { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to save CSV: " + ex.Message, "Export Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // ================= Hardware Info (CPU / RAM / Disk / Board / Warranty) =================

        private void DetectHardwareButton_Click(object sender, RoutedEventArgs e)
        {
            ScanButton.IsEnabled = false;
            DetectInventoryButton.IsEnabled = false;
            CheckForUpdatesButton.IsEnabled = false;
            CheckSecurityButton.IsEnabled = false;
            SecurityEventsButton.IsEnabled = false;
            DetectHardwareButton.IsEnabled = false;
            CheckWarrantyButton.IsEnabled = false;
            ExportHardwareHtmlButton.IsEnabled = false;
            ExportHardwareCsvButton.IsEnabled = false;
            ScanProgressBar.Visibility = Visibility.Visible;
            _memoryModules.Clear();
            _disks.Clear();
            StatusText.Text = "Starting hardware detection...";

            var thread = new Thread(() =>
            {
                try
                {
                    _hardwareScanner.StatusChanged -= OnScanStatus;
                    _hardwareScanner.StatusChanged += OnScanStatus;

                    var result = _hardwareScanner.Scan();

                    Dispatcher.Invoke(() =>
                    {
                        _hardwareInfo = result.Info;
                        foreach (var m in result.MemoryModules) _memoryModules.Add(m);
                        foreach (var d in result.Disks) _disks.Add(d);

                        _lastHardwareScanTime = DateTime.Now;
                        UpdateHardwareSummary();

                        StatusText.Text = "Hardware detection complete. Checking warranty status...";
                        ScanButton.IsEnabled = true;
                        DetectInventoryButton.IsEnabled = true;
                        CheckForUpdatesButton.IsEnabled = true;
                        CheckSecurityButton.IsEnabled = true;
                        SecurityEventsButton.IsEnabled = true;
                        DetectHardwareButton.IsEnabled = true;
                        CheckWarrantyButton.IsEnabled = true;
                        ExportHardwareHtmlButton.IsEnabled = true;
                        ExportHardwareCsvButton.IsEnabled = true;
                        ScanProgressBar.Visibility = Visibility.Collapsed;
                    });

                    RunWarrantyLookup();
                }
                catch (Exception ex)
                {
                    Dispatcher.Invoke(() =>
                    {
                        StatusText.Text = "Hardware detection failed: " + ex.Message;
                        MessageBox.Show(ex.Message, "Hardware Detection Error", MessageBoxButton.OK, MessageBoxImage.Error);
                        ScanButton.IsEnabled = true;
                        DetectInventoryButton.IsEnabled = true;
                        CheckForUpdatesButton.IsEnabled = true;
                        CheckSecurityButton.IsEnabled = true;
                        SecurityEventsButton.IsEnabled = true;
                        DetectHardwareButton.IsEnabled = true;
                        ScanProgressBar.Visibility = Visibility.Collapsed;
                    });
                }
            });
            thread.SetApartmentState(ApartmentState.STA);
            thread.IsBackground = true;
            thread.Start();
        }

        private void CheckWarrantyButton_Click(object sender, RoutedEventArgs e)
        {
            if (_lastHardwareScanTime == default)
            {
                MessageBox.Show("Run DETECT HARDWARE first - the warranty lookup needs the detected manufacturer and serial number.",
                    "Nothing to check", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            CheckWarrantyButton.IsEnabled = false;
            StatusText.Text = "Checking warranty status...";

            var thread = new Thread(() =>
            {
                RunWarrantyLookup();
                Dispatcher.Invoke(() => CheckWarrantyButton.IsEnabled = true);
            });
            thread.SetApartmentState(ApartmentState.STA);
            thread.IsBackground = true;
            thread.Start();
        }

        /// <summary>Runs the (network-bound) warranty lookup on whatever thread calls it and
        /// marshals the result back to the UI thread. Called both right after a hardware scan
        /// and from the standalone RECHECK WARRANTY button.</summary>
        private void RunWarrantyLookup()
        {
            try
            {
                _warrantyService.StatusChanged -= OnScanStatus;
                _warrantyService.StatusChanged += OnScanStatus;

                var result = _warrantyService.Lookup(_hardwareInfo.Manufacturer, _hardwareInfo.WarrantySerialNumber);

                Dispatcher.Invoke(() =>
                {
                    _hardwareInfo.WarrantyStatus = result.Status;
                    _hardwareInfo.WarrantyEndDate = result.EndDate;
                    _hardwareInfo.WarrantyProvider = result.Provider;
                    _hardwareInfo.WarrantyCheckUrl = result.CheckUrl;
                    _hardwareInfo.WarrantyNote = result.Note;
                    UpdateHardwareSummary();
                    StatusText.Text = $"Warranty check complete: {result.Status}.";
                });
            }
            catch (Exception ex)
            {
                Dispatcher.Invoke(() => StatusText.Text = "Warranty check failed: " + ex.Message);
            }
        }

        private void UpdateHardwareSummary()
        {
            var h = _hardwareInfo;

            HardwareOverallValue.Text = _lastHardwareScanTime == default
                ? "No scan yet"
                : $"{Dash(h.Manufacturer)} {Dash(h.Model)}".Trim();

            HwCpuValue.Text = Dash(h.CpuName);
            HwRamValue.Text = h.TotalRamGB > 0 ? $"{h.TotalRamGB:0.#} GB" : "—";
            HwDisksValue.Text = h.DiskCount > 0 ? $"{h.DiskCount} ({h.TotalDiskGB:0.#} GB)" : "—";
            HwWarrantyValue.Text = h.WarrantyStatus;

            HwManufacturerValue.Text = Dash(h.Manufacturer);
            HwModelValue.Text = Dash(h.Model);
            HwSystemSerialValue.Text = Dash(h.SystemSerialNumber);
            HwChassisValue.Text = Dash(h.ChassisType);

            HwBiosManufacturerValue.Text = Dash(h.BiosManufacturer);
            HwBiosVersionValue.Text = Dash(h.BiosVersion);
            HwBiosDateValue.Text = Dash(h.BiosReleaseDate);
            HwBiosSerialValue.Text = Dash(h.BiosSerialNumber);

            HwBoardManufacturerValue.Text = Dash(h.MotherboardManufacturer);
            HwBoardProductValue.Text = Dash(h.MotherboardProduct);
            HwBoardSerialValue.Text = Dash(h.MotherboardSerialNumber);
            HwCpuNameValue.Text = Dash(h.CpuName);
            HwCpuCoresValue.Text = h.CpuCores > 0 ? $"{h.CpuCores} / {h.CpuLogicalProcessors}" : "—";
            HwCpuClockValue.Text = h.CpuMaxClockMHz > 0 ? $"{h.CpuMaxClockMHz:0} MHz" : "—";

            WarrantyStatusValue.Text = h.WarrantyStatus;
            WarrantyEndDateValue.Text = Dash(h.WarrantyEndDate);
            WarrantyProviderValue.Text = Dash(h.WarrantyProvider);
            WarrantyNoteValue.Text = string.IsNullOrWhiteSpace(h.WarrantyNote)
                ? "Run DETECT HARDWARE to see warranty status."
                : h.WarrantyNote;

            if (!string.IsNullOrWhiteSpace(h.WarrantyCheckUrl) && Uri.TryCreate(h.WarrantyCheckUrl, UriKind.Absolute, out var uri))
            {
                WarrantyCheckLink.NavigateUri = uri;
                WarrantyCheckLinkText.Text = $"Open {(string.IsNullOrWhiteSpace(h.WarrantyProvider) ? "manufacturer" : h.WarrantyProvider)} warranty check page";
                WarrantyCheckLink.IsEnabled = true;
            }
            else
            {
                WarrantyCheckLinkText.Text = "No known public warranty check page for this manufacturer.";
                WarrantyCheckLink.IsEnabled = false;
            }
        }

        private static string Dash(string? s) => string.IsNullOrWhiteSpace(s) ? "—" : s;

        private void SaveDellCredentialsButton_Click(object sender, RoutedEventArgs e)
        {
            string clientId = DellClientIdBox.Text?.Trim() ?? "";
            string clientSecret = DellClientSecretBox.Password?.Trim() ?? "";

            if (string.IsNullOrWhiteSpace(clientId) || string.IsNullOrWhiteSpace(clientSecret))
            {
                MessageBox.Show("Enter both the Client ID and Client Secret from your Dell TechDirect API registration.",
                    "Missing credentials", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            WarrantyLookupService.SaveDellCredentials(clientId, clientSecret);
            DellClientSecretBox.Password = "";
            CheckWarrantyButton.IsEnabled = _lastHardwareScanTime != default;
            MessageBox.Show("Dell API credentials saved locally on this PC. Click RECHECK WARRANTY to use them.",
                "Saved", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ClearDellCredentialsButton_Click(object sender, RoutedEventArgs e)
        {
            WarrantyLookupService.ClearDellCredentials();
            DellClientIdBox.Text = "";
            DellClientSecretBox.Password = "";
            MessageBox.Show("Dell API credentials removed from this PC.", "Cleared",
                MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void ExportHardwareHtmlButton_Click(object sender, RoutedEventArgs e)
        {
            if (_lastHardwareScanTime == default)
            {
                MessageBox.Show("Run DETECT HARDWARE first.", "Nothing to export",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var dialog = new SaveFileDialog
            {
                Filter = "HTML report (*.html)|*.html",
                FileName = $"HardwareReport_{_hostname}_{DateTime.Now:yyyyMMdd_HHmmss}.html"
            };
            if (dialog.ShowDialog() != true) return;

            try
            {
                string html = HardwareHtmlReportBuilder.Build(_hostname, _hardwareInfo, _memoryModules.ToList(),
                    _disks.ToList(), _lastHardwareScanTime);
                File.WriteAllText(dialog.FileName, html, System.Text.Encoding.UTF8);

                var result = MessageBox.Show("Report saved. Open it now?", "Export complete",
                    MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (result == MessageBoxResult.Yes)
                    Process.Start(new ProcessStartInfo(dialog.FileName) { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to save report: " + ex.Message, "Export Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ExportHardwareCsvButton_Click(object sender, RoutedEventArgs e)
        {
            if (_lastHardwareScanTime == default)
            {
                MessageBox.Show("Run DETECT HARDWARE first.", "Nothing to export",
                    MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var dialog = new SaveFileDialog
            {
                Filter = "CSV file (*.csv)|*.csv",
                FileName = $"HardwareReport_{_hostname}_{DateTime.Now:yyyyMMdd_HHmmss}.csv"
            };
            if (dialog.ShowDialog() != true) return;

            try
            {
                string csv = HardwareCsvBuilder.Build(_hostname, _hardwareInfo, _memoryModules.ToList(),
                    _disks.ToList(), _lastHardwareScanTime);
                File.WriteAllText(dialog.FileName, csv, System.Text.Encoding.UTF8);

                var result = MessageBox.Show("CSV saved. Open it now?", "Export complete",
                    MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (result == MessageBoxResult.Yes)
                    Process.Start(new ProcessStartInfo(dialog.FileName) { UseShellExecute = true });
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to save CSV: " + ex.Message, "Export Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
