# Win Patch Scanner

A native Windows desktop app (WPF, .NET 6) that scans the local machine for missing
Windows OS updates, detects installed applications and Windows services (Microsoft vs.
non-Microsoft), checks those applications for available upgrades via winget, shows all
of it on a live tabbed dashboard, and exports reports as either a self-contained
dark-HUD styled HTML file or a CSV.

## How it works

- Scanning uses the built-in **Windows Update Agent COM API**
  (`Microsoft.Update.Session`) — the same engine Windows Update itself uses.
  No PowerShell modules, no third-party libraries, no admin rights needed to scan.
- The scan runs on a background STA thread so the UI stays responsive.
- The dashboard shows: total missing patches, counts by severity (Critical /
  Important / Moderate / Low), total download size, a **peak impact/risk score**,
  and a searchable/filterable grid of every missing update (risk score, KB,
  title, category, size, release date, catalog link, install status).
- **Impact / risk score (1–10)** is computed per patch from severity + whether
  it's in a Security/Critical category + how long it's been missing (older
  missing patches score higher). 9–10 = critical/immediate, 7–8 = high,
  5–6 = medium, 3–4 = low, 1–2 = informational. The dashboard and report both
  surface the **peak score** across all findings as the headline risk number.
- **Install pipeline**: tick individual updates (or use INSTALL ALL), confirm
  the prompt, and the app downloads + installs them via the same Windows
  Update Agent API, showing per-update status (Installed / Failed / Cancelled)
  and flagging if a restart is needed.
- **Export — HTML or CSV**, both on the dashboard toolbar:
  - **HTML** writes a standalone `.html` file (no external assets, works
    offline) styled to match your other dark HUD tools, including the risk
    panel and a "Get patch" link per row to the Microsoft Update Catalog — you
    can open it in a browser, print it, or attach it to a client report.
  - **CSV** writes a plain `.csv` (host/OS/scan-time header rows, then one row
    per finding — impact score, label, severity, KB, title, category, size,
    release date, install status, catalog link — sorted by risk score) for
    Excel, a ticketing system, or feeding into another pipeline.
  - Both use the same `SaveFileDialog` flow and offer to open the file once saved.
- **Installed Applications & Windows Services** — a second dashboard action,
  **DETECT APPS & SERVICES**, independent of the patch scan:
  - **Installed Applications** reads the same registry `Uninstall` keys
    Windows' own "Programs and Features" reads from (`HKLM`/`HKCU`, both the
    64-bit and WOW6432Node 32-bit views), giving name, publisher, version,
    install date, estimated size, install scope (machine vs. user) and
    architecture for every entry, tagged **Microsoft** or **Non-Microsoft**
    by publisher.
  - **Windows Services** enumerates every service via WMI (`Win32_Service`) —
    display name, service name, state, start mode, account, and path — and
    classifies each as **Microsoft** or **Non-Microsoft** by resolving the
    binary's file version info (`CompanyName`) or, if that's unreadable,
    whether it lives under `System32`/`SysWOW64`.
  - Each tab has its own summary cards (totals split Microsoft /
    non-Microsoft, running/stopped for services, total disk use for apps), a
    live search box, and its own **EXPORT HTML** / **EXPORT CSV** buttons.
  - **EXPORT HTML** (either tab) writes one combined, standalone
    `Applications & Services Report`, styled to match the patch report —
    summary cards and a Microsoft/Non-Microsoft vendor-split bar for each
    section, followed by the full applications table and the full services
    table. **EXPORT CSV** (per tab) writes just that tab's data as a
    plain `.csv`.
  - Entirely read-only — no elevation needed, nothing is installed, changed
    or stopped.
- **Application Updates** — a third dashboard tab, powered by **winget**
  (Windows Package Manager, the same tool behind the Microsoft Store's
  "App Updates" and bundled with modern Windows 10/11 as "App Installer"):
  - **CHECK FOR UPDATES** runs `winget upgrade` and lists every installed
    application winget recognizes as having a newer version — app name,
    package id, installed vs. available version, source, and a best-effort
    link to the package's page on winget.run to sanity-check before
    upgrading.
  - Tick individual updates (or **UPGRADE ALL**), confirm the prompt, and
    the app runs `winget upgrade --id <id> --silent` per selected package,
    reporting per-app status (Upgraded / Failed / Timed out — some
    installers don't support silent/unattended mode and will report
    Failed, which is normal, not a bug).
  - Its own **EXPORT CSV**, and its **EXPORT HTML** feeds into the same
    combined report as the Applications/Services tabs (now titled
    *Applications, Services & Updates Report*), with an "Available
    Application Updates" section at the top.
  - Requires winget to be present (it ships with "App Installer" from the
    Microsoft Store, present by default on most current Windows 10/11
    machines) and internet access. If winget isn't found, CHECK FOR
    UPDATES fails with a clear message telling you to install it, rather
    than silently doing nothing.
- **Security Center** — a fourth dashboard tab covering Microsoft Defender
  and Windows Security status, gathered in one PowerShell call (via the
  built-in Defender module and a handful of documented registry keys) so
  CHECK SECURITY STATUS stays fast and entirely read-only:
  - **Defender status** — run/antivirus status, real-time protection, tamper
    protection, engine/signature version, last signature update, and last
    quick/full scan date and time.
  - **Threat detections** — every entry in Defender's threat history (name,
    severity, best-effort status, detecting process/resource) plus a clear
    "Action Needed" flag built from Defender's own `AdditionalActionsBitMask`
    signal, so a pending item is never mistaken for a resolved one.
  - **App & browser control** — SmartScreen status for apps/files and for
    Microsoft Edge (policy-managed values take priority over local
    settings, matching how Windows itself resolves them), plus a best-effort
    Exploit Protection summary (DEP/CFG/ASLR/SEHOP) via
    `Get-ProcessMitigation`.
  - **Device security** — Memory integrity (Core isolation), Secure Boot,
    and TPM presence/state.
  - **Device performance & health** — a best-effort snapshot (system drive
    free space, last boot time) rather than a full mirror of Windows
    Security's own telemetry-backed page.
  - **Protection history** — the most recent events from the
    `Microsoft-Windows-Windows Defender/Operational` event log, the same
    feed behind Windows Security's own Protection history list, with a
    friendly category label for well-known event IDs.
  - **Highlights** — every check above rolled up into one severity-ranked
    list (Critical/High/Medium/Low), each with a plain-English recommendation
    - this is what the OVERALL SEVERITY HIGHLIGHT card and the report's
    headline number are built from.
  - Its own **EXPORT HTML** / **EXPORT CSV**, styled to match the other
    reports, with the same logo/copyright branding.
  - No admin rights needed for any of this on a normal Windows 10/11
    install; if a section can't be read (module missing, unsupported
    hardware, access denied), it shows "Unavailable"/"N/A" rather than
    failing the whole check - see `Services/SecurityScanner.cs`.
- **Security Events** — a sixth dashboard tab that captures the Windows
  Security event log plus other investigation-relevant channels and
  correlates them into a findings dashboard, all in one read-only
  PowerShell call:
  - **Captured channels** — `Security` (logon/logoff, account and group
    membership changes, privilege use, audit-log clears), `System`
    (service installation, event 7045), `Microsoft-Windows-PowerShell/
    Operational` (script block and module logging, 4104/4103),
    `Microsoft-Windows-TerminalServices-RemoteConnectionManager/
    Operational` (RDP connections, 1149), `Microsoft-Windows-
    TaskScheduler/Operational` (new scheduled tasks, 106), plus recent
    `Application` log errors/warnings — a 7-day lookback, capped at 300
    events per channel, so SCAN SECURITY EVENTS stays fast.
  - **Severity and urgency** — every captured event, and every rolled-up
    finding, carries two independent ratings: **Severity** (how bad it is
    if real — Critical/High/Medium/Low/Info) and **Urgency** (how soon it
    deserves attention — Immediate/High/Normal/Low), shown as separate
    colour-coded badges.
  - **Investigation Findings dashboard** — raw events are correlated into
    higher-value findings, not just listed: repeated failed-logon bursts
    from one account/source (possible brute-force / password-spray),
    audit log clears (always Critical/Immediate), privileged group
    membership changes, and PowerShell script blocks matching known
    suspicious-technique keywords (`-EncodedCommand`, `Invoke-Expression`,
    `DownloadString`, `Invoke-Mimikatz`, Base64 decoding, etc.) — each
    finding comes with a plain-English recommendation.
  - Its own **EXPORT HTML** / **EXPORT CSV**, styled to match the other
    reports, covering both the findings dashboard and every captured event.
  - No admin rights needed on a normal Windows 10/11 install; a channel
    that can't be read (not present, access denied) is skipped for that
    channel only rather than failing the whole capture - see
    `Services/SecurityEventScanner.cs`.
- **Hardware Info** — a seventh dashboard tab that detects the machine's
  hardware configuration entirely via WMI, with an optional warranty lookup:
  - **System & BIOS** — manufacturer (OEM), model, chassis type, system
    serial number, BIOS manufacturer/version/release date/serial number.
  - **Motherboard & CPU** — motherboard manufacturer/product/serial number,
    CPU name/manufacturer, core and logical-processor counts, max clock speed.
  - **Memory & disks** — every installed RAM module (locator, manufacturer,
    part/serial number, capacity, speed, type, form factor) and every
    physical disk (model, interface, media type, size, serial number,
    firmware revision), each in its own grid.
  - **Warranty status via API** — DETECT HARDWARE automatically attempts a
    warranty lookup afterwards. For **Dell** machines, once you've entered a
    free Dell TechDirect API Client ID/Secret in the tab (stored locally,
    never transmitted anywhere except Dell's own API), it calls Dell's own
    Asset Entitlements API and shows **In Warranty** / **Expired** with an
    end date, sourced live from Dell. For every other manufacturer - or for
    a Dell machine before credentials are entered - it shows "Not checked"
    with a direct link to that manufacturer's own public warranty-check
    page, rather than guessing or fabricating a status.
  - A standalone **RECHECK WARRANTY** button re-runs just the warranty
    lookup (useful right after saving Dell credentials, without re-scanning
    hardware).
  - Its own **EXPORT HTML** / **EXPORT CSV**, styled to match the other
    reports.
  - No admin rights needed; each WMI class is queried independently so one
    missing/inaccessible class only blanks that one section - see
    `Services/HardwareScanner.cs`.

## ⚠️ Installing patches — read this first

- **Installing requires the app to be running elevated.** If it isn't, the
  amber banner at the top offers "Restart as Administrator" (a UAC prompt).
  Scanning never needs elevation — only install does.
- Installing modifies the system immediately. There's a confirmation dialog
  before anything downloads, but there's no dry-run/simulation mode — treat
  INSTALL ALL on a production or client machine the way you'd treat running
  Windows Update manually: during an approved maintenance window, with a
  restore point / backup in place.
- Some updates require a restart to finish applying; the app tells you when
  that's the case but does not reboot the machine for you.
- The "Get patch" catalog link is built from the KB number
  (`https://www.catalog.update.microsoft.com/Search.aspx?q=KB####`) so it
  works even for updates you choose not to install through the app.

## ⚠️ Upgrading applications — read this first

- Upgrading also modifies the system immediately, via `winget upgrade
  --silent`. There's a confirmation dialog first, but as with patches,
  there's no dry-run mode — same advice: an approved window, a restore
  point, for anything client-facing.
- Unlike patch install, the app itself doesn't need to run elevated —
  winget prompts for UAC per package when an installer requires it. A
  handful of apps still don't support silent/unattended install at all;
  those show up as **Failed** rather than hanging, which is expected.
- winget's own catalog decides what counts as "installed" and "available" —
  a portable app, an app installed outside winget's awareness, or one from
  a source winget doesn't index won't show up here even if a newer version
  exists elsewhere.

## Branding

- The dashboard shows a small logo top-left of the header.
- Every exported HTML report shows the same logo top-right (embedded as a
  base64 data URI, so reports stay fully self-contained / offline-viewable)
  and a footer copyright line: `AMITAVA GUPTA VU3IBL Copy Right @2026`.
- Logo source: `WinPatchScanner/Assets/logo.png`. Branding lives in
  `Services/ReportBranding.cs` (shared by both HTML report builders) and in
  `MainWindow.xaml`'s header `Image` — swap the PNG and re-run the app/reports
  to change it.

## Requirements

- Windows 10 or 11
- [.NET 6 SDK](https://dotnet.microsoft.com/download/dotnet/6.0) or later installed
  on the machine you build/run on
- Internet access at scan time (the scan queries the Windows Update servers for
  what's missing — same as Windows Update itself)
- Windows PowerShell (`powershell.exe`, present by default on every Windows
  10/11 install) for the Security Center and Security Events tabs, and
  Microsoft Defender Antivirus active on the machine for the Security
  Center tab's Defender-specific sections (a machine running a
  third-party antivirus with Defender fully disabled will show those
  fields as "Unavailable" rather than failing the scan)
- For the Security Events tab, the account running WinPatch needs read
  access to the Security event log, which on most Windows 10/11 machines
  means being a member of the local Administrators or "Event Log
  Readers" group — a standard user with neither will see that channel
  skipped rather than the scan failing outright
- Internet access for the Hardware Info tab's warranty lookup — only
  needed if you've configured Dell API credentials; everything else on
  that tab (CPU/RAM/disk/board/BIOS detection) is fully offline

## Build & run

```powershell
cd WinPatchScanner
dotnet restore
dotnet build -c Release
dotnet run
```

## Publish a single portable .exe

```powershell
dotnet publish WinPatchScanner\WinPatchScanner.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true
```

The .exe will land in:
`WinPatchScanner\bin\Release\net6.0-windows\win-x64\publish\WinPatchScanner.exe`

Copy that single file anywhere and run it — no install required.

For a noticeably faster first launch on either Windows 10 or 11 (pre-JITting
the app's own code at publish time instead of at first run), add
`-p:PublishReadyToRun=true` to the command above. It produces a larger file
in exchange for that faster cold start - worth it for a tool that's copied
to a client PC and run once or twice, less useful if you'll `dotnet run`
from source repeatedly during development.

`TargetFramework` is deliberately the unversioned `net6.0-windows` rather
than a Windows-10-SDK-pinned target (e.g. `net6.0-windows10.0.19041.0`) -
that keeps the app on the plain Win32/.NET API surface common to both
Windows 10 and 11 rather than opting into version-gated WinRT projections,
which is the safer choice for a tool meant to run unmodified on either OS.

## Project layout

```
WinPatchScanner/
  WinPatchScanner.sln
  WinPatchScanner/
    WinPatchScanner.csproj
    app.manifest              — runs as standard user (asInvoker)
    App.xaml / App.xaml.cs
    Assets/logo.png           — header logo, also embedded into HTML reports
    MainWindow.xaml / .cs     — dashboard UI + scan/install/export orchestration
    Models/PatchInfo.cs
    Models/ApplicationInfo.cs
    Models/ServiceInfo.cs
    Models/AppUpdateInfo.cs
    Models/DefenderStatusInfo.cs
    Models/ThreatDetectionInfo.cs
    Models/ProtectionEventInfo.cs
    Models/SecurityIssueInfo.cs
    Models/SecurityEventInfo.cs
    Models/SecurityFindingInfo.cs
    Models/HardwareInfo.cs
    Models/MemoryModuleInfo.cs
    Models/DiskDriveInfo.cs
    Services/PatchScanner.cs      — Windows Update Agent COM wrapper (scan + install)
    Services/ImpactAnalyzer.cs    — 1-10 risk scoring
    Services/HtmlReportBuilder.cs — self-contained HTML report generator
    Services/CsvReportBuilder.cs  — CSV report generator (patches)
    Services/InventoryScanner.cs           — registry (apps) + WMI (services) detection
    Services/InventoryCsvBuilder.cs        — CSV export for apps/services/updates
    Services/InventoryHtmlReportBuilder.cs — combined apps + services + updates HTML report
    Services/ReportBranding.cs             — shared logo/copyright branding for HTML reports
    Services/WingetUpdateScanner.cs        — winget wrapper (check + silent upgrade)
    Services/SecurityScanner.cs            — Defender/Windows Security status (single PowerShell call)
    Services/SecurityCsvBuilder.cs         — CSV export for the Security Center tab
    Services/SecurityHtmlReportBuilder.cs  — Security Center HTML report generator
    Services/SecurityEventScanner.cs        — event log capture + severity/urgency classification + finding correlation
    Services/SecurityEventCsvBuilder.cs     — CSV export for the Security Events tab
    Services/SecurityEventHtmlReportBuilder.cs — Security Events HTML report generator
    Services/HardwareScanner.cs            — CPU/RAM/disk/motherboard/BIOS/OEM detection via WMI
    Services/WarrantyLookupService.cs      — Dell TechDirect API warranty lookup + manufacturer fallback links
    Services/HardwareCsvBuilder.cs         — CSV export for the Hardware Info tab
    Services/HardwareHtmlReportBuilder.cs  — Hardware Info HTML report generator
    Converters/SeverityToBrushConverter.cs
    Converters/ImpactScoreToBrushConverter.cs
    Converters/VendorToBrushConverter.cs
    Themes/DarkHud.xaml       — dark HUD color palette + control/tab styles
```

## Notes / troubleshooting

- **Windows 10 & 11 compatibility**: `app.manifest` declares the shared
  Windows 10/11 `supportedOS` GUID (there is no separate Windows 11 GUID -
  Microsoft reuses the Windows 10 one) so the app gets real current-OS
  behavior on both rather than a compatibility shim, and declares
  Per-Monitor-V2 DPI awareness so the dashboard stays crisp on today's
  common high-DPI and multi-monitor-at-different-scales setups on either
  OS. Every scanner (patches, inventory, winget, Defender/Security Center)
  uses only APIs present on both Windows 10 and 11, and degrades a single
  unavailable check to "Unavailable"/"N/A" rather than failing outright -
  so an older Windows 10 build or a locked-down machine still gets a
  usable scan, just with fewer fields populated.
- If the scan fails immediately, confirm the **Windows Update** service
  (`wuauserv`) is set to Manual/Automatic and running (`services.msc`).
- Corporate machines with WSUS/Intune policies may restrict or redirect what
  the Update Agent reports — that's expected and matches what Windows Update
  itself would show on that machine.
- **A scan that finds 0 missing updates, or a different count, on another
  PC is very often correct, not a bug** — the status bar after every scan now
  appends which update source that machine is actually using: public Windows
  Update, or "managed by your organization's WSUS server (\<server\>)" (read
  from the same Group Policy keys Windows itself honors,
  `HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate[\AU]`). A
  WSUS-managed PC only ever sees what that internal server has synced and
  approved, which can be far behind the public catalog. If the scan instead
  fails outright, the error message now decodes common Windows Update Agent
  HRESULTs (service disabled, DNS/proxy failure, WU server unavailable,
  timeout, TLS/clock issues) into a plain-English cause instead of a bare
  `0x8024402C`-style code — see `DescribeSearchFailure` /
  `DescribeUpdateSource` in `Services/PatchScanner.cs`.
- To extend this to remote/multi-machine scanning later, `PatchScanner` can be
  swapped to call `Invoke-Command -ComputerName ...` running an equivalent
  script block, or point `UpdateSession` at a remote WSUS server — the
  dashboard and report layers don't need to change.
- The Microsoft/Non-Microsoft classification for services is a best-effort
  heuristic (binary's `CompanyName` first, then install path). A small
  number of Microsoft-owned services on unusual paths, or third-party
  services that stamp "Microsoft" somewhere in their metadata, may be
  misclassified — treat it as a strong starting split, not a guarantee.
- If **CHECK FOR UPDATES** reports it can't find winget, install "App
  Installer" from the Microsoft Store (search for it, or run
  `winget --version` in a terminal to confirm it's on PATH) and try again.
- `WingetUpdateScanner` parses winget's plain-text table output (there's no
  stable JSON output for `winget upgrade` as of this build), using the
  header row to find column boundaries. It's the same approach most
  community winget automation tools use, but a very long app name or
  package id can still get column-truncated by winget itself before it
  even reaches this app — the "Details" link and `winget upgrade` run
  directly in a terminal are the fallback if a row looks off.
- The winget.run "Details" link is inferred from the package id's
  `Publisher.Package` convention and isn't guaranteed to resolve for every
  package — it's a convenience for double-checking before upgrading, not
  an authoritative source.
- **Security Center honesty notes** (worth knowing before relying on this
  in front of a client):
  - Threat **Severity** uses Microsoft's documented `SeverityID` scale
    (Low/Moderate/High/Severe). Threat **Status**, however, is shown as a
    best-effort label with the raw Defender status code alongside it,
    because that code's full meaning isn't officially published — the
    "Action Needed" badge is the one that's backed by a real, documented
    signal (Defender's own `AdditionalActionsBitMask`), so treat that as
    the reliable pending-action indicator.
  - **Protection history** severity is derived from the event's native
    Windows Event Log level plus a small lookup table for well-known
    Defender event IDs (1116/1117 detections, 2000/2001 signature
    updates, 5001/5010/5012 protection-disabled/tamper events, etc.) — an
    ID outside that table still shows correctly, just under a generic
    "Defender event &lt;id&gt;" label.
  - **Device performance & health** is a best-effort snapshot (system
    drive free space + last boot time only) — it does not attempt to
    replicate Windows Security's own telemetry-backed driver/battery/app
    health checks, which aren't exposed through a documented API.
  - If Exploit Protection, TPM, Memory Integrity or Secure Boot show
    "Unavailable"/"N/A", that's usually the hardware/edition genuinely not
    supporting the feature (common on VMs and older PCs), not a scan
    failure — each is read independently and fails gracefully on its own.
- **Security Events honesty notes** (worth knowing before relying on this
  in front of a client):
  - Only a curated set of well-documented event IDs (logon/logoff,
    account/group changes, privilege use, audit-log clears, service
    installs, PowerShell script blocks, RDP connections, new scheduled
    tasks) get a specific category label and a baseline severity/urgency.
    Anything else that shows up (e.g. an uncurated Application error)
    still appears, just under a generic "&lt;channel&gt; event &lt;id&gt;"
    label with severity/urgency derived from the event's own native
    Windows level.
  - **Account** and **Source** columns are extracted with a best-effort
    regex against the event's rendered message text (matching lines like
    "Account Name:" or "Source Network Address:"), not by reading
    Get-WinEvent's positional `Properties[]` array, which is more
    fragile and version-dependent — treat these as a convenience for
    triage, not a guaranteed-accurate parse, and open the full message
    text for anything you're about to act on.
  - The 7-day lookback and 300-events-per-channel cap keep the scan fast
    but mean older or very high-volume activity won't appear — for a
    deeper investigation window, use `Get-WinEvent` directly or pull the
    full .evtx files.
  - **Findings are correlation heuristics, not verdicts.** A brute-force
    finding is just "5+ failed logons from the same account/source in 7
    days" and a suspicious-PowerShell finding is just "this script block
    contains a keyword commonly seen in attacks" — both can be entirely
    legitimate activity (a misconfigured service account, a legitimate
    admin script) and both deserve a human look before any action is
    taken.
- **Hardware Info / warranty honesty notes** (worth knowing before relying
  on this in front of a client):
  - All detection fields (CPU, RAM, disks, motherboard, BIOS, system
    serial) come straight from WMI with no interpretation - if a field
    shows "—", that WMI class genuinely returned nothing for that
    property on this machine (common on white-box/DIY boards, which
    often report a literal "To be filled by O.E.M." placeholder that
    this app blanks out rather than displaying as noise).
  - **Dell is the only manufacturer this app queries automatically**, and
    only once you've entered your own free Dell TechDirect API Client
    ID/Secret (register at dell.com/support/retail/tdregistration) - as
    far as could be confirmed, no other major OEM (HP, Lenovo, ASUS,
    Acer, etc.) offers a public, self-service-registerable warranty API;
    their official APIs are restricted to partner/business accounts
    under NDA. For every manufacturer other than Dell (and for Dell
    before credentials are entered), the tab gives you a direct link to
    that OEM's own public warranty-check web page instead of guessing a
    status - you enter the serial number yourself on that page.
  - The Dell warranty status shown is the **latest end date across all
    entitlement lines** Dell returns for that service tag (e.g. the base
    warranty plus any extended coverage) - "In Warranty" means at least
    one coverage line is still active, not that every line is.
  - Dell API credentials are stored in a plain JSON file under your
    Windows user profile (`%AppData%\WinPatch\dell-api-credentials.json`)
    - readable by anyone with access to that Windows account, and never
      sent anywhere except directly to Dell's own API endpoints.
