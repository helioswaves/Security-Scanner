# WinPatch — User Guide

**Secure. Connect. Patch.**

A step-by-step guide to installing, running, and getting reports out of WinPatch —
the Windows patch, application & service scanner.

---

## 1. About WinPatch

WinPatch is a Windows desktop tool that gives you a single dashboard to see —
and act on — everything that's out of date or unaccounted for on a Windows PC:

- **Missing Windows OS patches**, each scored 1–10 for impact/risk so you know
  what needs attention first, with one-click install straight from the app.
- **Installed applications and Windows services**, split into Microsoft vs.
  Non-Microsoft, with publisher, version, install date, size, and state.
- **Available application updates** (via winget), so third-party software can
  be checked and upgraded from the same dashboard.
- **A Security Center** — Microsoft Defender status, threat detections,
  App & browser control, Device security, Device performance & health, and
  Protection history, all in one place with severity-ranked highlights.
- **Security Events** — captures the Windows Security log and key
  application/investigation channels, marks every event with a severity
  *and* an urgency rating, and rolls patterns (failed-logon bursts, audit
  log clears, privileged group changes, suspicious PowerShell) up into an
  Investigation Findings dashboard.
- **Exportable reports** — a polished HTML report for sharing/printing, or a
  CSV for Excel and other tools — for every scan.

WinPatch is built and maintained by **Amitava Gupta (VU3IBL)**, Logarhythm
Consultancy Pvt. Ltd.

---

## 2. Applications Required

Install these before running WinPatch:

| Requirement | Notes |
|---|---|
| **Windows 10 or 11 (64-bit)** | WinPatch is a native Windows desktop app. |
| **.NET 6 Desktop Runtime** | Needed to run the app. [Download here](https://dotnet.microsoft.com/download/dotnet/6.0) if not already installed. (Not needed if you use the single-file published .exe, which bundles the runtime.) |
| **App Installer (winget)** | Only required for the **Application Updates** tab. Comes pre-installed on most current Windows 10/11 PCs; otherwise install "App Installer" from the Microsoft Store. |
| **Windows PowerShell** | Only required for the **Security Center** and **Security Events** tabs. Pre-installed on every Windows 10/11 PC — nothing to install. |
| **A web browser** (Edge, Chrome, Firefox, etc.) | To open the exported HTML reports. |
| **Excel or another spreadsheet app** (optional) | To open the exported CSV reports. |

No separate installation of WinPatch itself is required beyond copying the
application files (or the single portable .exe) to the PC.

---

## 3. Services Required

WinPatch relies on a few standard Windows services and connections already
built into Windows:

| Service / Access | Needed for | Notes |
|---|---|---|
| **Windows Update service** (`wuauserv`) | Scanning & installing patches | Must be set to Manual or Automatic and running. Check via `services.msc`. |
| **Windows Management Instrumentation (WMI)** | Detecting installed services | Runs by default on all Windows PCs. |
| **Internet access** | Patch scanning, and Application Updates | The app talks to the Windows Update servers to check for missing patches, and to winget's configured sources to check for app updates. |
| **Microsoft Defender Antivirus** | The Defender-specific parts of Security Center | If a third-party antivirus has fully disabled Defender, those fields show "Unavailable" rather than failing the whole check — the other Security Center sections (device security, performance, App & browser control) still work. |
| **Read access to the Security event log** | The Security Events tab | Membership in the local Administrators or "Event Log Readers" group. Without it, the Security channel is skipped for that scan rather than failing it outright. |
| **Administrator privileges** | **Installing** patches only | Scanning, detecting apps/services, checking for app updates, and checking security status/events do **not** need admin rights. Only clicking INSTALL SELECTED / INSTALL ALL does. |

---

## 4. Step-by-Step Guide to Run WinPatch

### Step 1 — Launch the app
Double-click `WinPatchScanner.exe` (or run `dotnet run` if you're working from
source). The dashboard opens, showing the WinPatch logo top-left, the header
toolbar, and six tabs: **Missing Patches**, **Installed Applications**,
**Windows Services**, **Application Updates**, **Security Center**, and
**Security Events**.

If the app isn't running as Administrator, an amber banner appears at the top.
You can ignore it unless you plan to install patches — click
**RESTART AS ADMINISTRATOR** when you do.

### Step 2 — Scan for missing patches
1. Click **▶ SCAN PATCHES** in the header.
2. A progress bar appears while WinPatch queries Windows Update — this can
   take anywhere from a few seconds to a couple of minutes.
3. When finished, the **Missing Patches** tab fills in:
   - Summary cards (Missing Total, Critical, Important, Moderate, Low/Other,
     Download Size).
   - The **Peak Risk Score** card in the header (1–10; 9–10 = critical,
     needs immediate attention).
   - A searchable grid of every missing update, with its risk score,
     severity, KB number, title, category, size, release date, and a
     **Catalog** link to download it manually if you prefer.

### Step 3 — Install patches (optional)
1. If not already elevated, click **RESTART AS ADMINISTRATOR** in the amber
   banner and approve the UAC prompt.
2. Tick the checkboxes next to the updates you want, or click
   **INSTALL ALL**.
3. Click **INSTALL SELECTED** (or **INSTALL ALL**) and confirm the prompt.
4. Watch the **Install Status** column update per patch (Installed / Installed
   with errors / Failed / Cancelled). If any patch needs a restart to finish
   applying, WinPatch tells you — it will not reboot the PC for you.

> ⚠️ Installing changes the system immediately. Do this during an approved
> maintenance window, ideally with a restore point / backup in place.

### Step 4 — Detect installed applications & services
1. Click **▶ DETECT APPS & SERVICES** in the header.
2. Switch to the **Installed Applications** tab to see every installed
   program — name, publisher, version, install date, size, scope, and
   architecture — tagged Microsoft or Non-Microsoft, with summary cards for
   Total Installed, Microsoft, Non-Microsoft, and Total Disk Use.
3. Switch to the **Windows Services** tab for the same view of every Windows
   service — display name, service name, state (Running/Stopped), start
   mode, account, and vendor.
4. Use the search box on either tab to filter by name, publisher, or path.

This step is entirely read-only — nothing is installed, changed, or stopped.

### Step 5 — Check for application updates (optional)
1. Go to the **Application Updates** tab.
2. Click **▶ CHECK FOR UPDATES**. WinPatch uses winget to compare installed
   applications against their latest available versions.
3. Tick the ones you want (or click **UPGRADE ALL**), then click
   **UPGRADE SELECTED** / **UPGRADE ALL** and confirm.
4. Watch the **Upgrade Status** column — some installers don't support silent
   upgrade and will show *Failed*, which is expected, not a bug.

### Step 6 — Check Microsoft Defender & Windows Security status (optional)
1. Go to the **Security Center** tab.
2. Click **▶ CHECK SECURITY STATUS**. WinPatch gathers Defender status,
   threat history, App & browser control, device security, device
   performance, and Protection history in one check.
3. Read the **OVERALL SEVERITY HIGHLIGHT** card first — it shows the
   highest-severity issue found (or "No issues flagged" if everything's
   clean), backed by the **Highlights** table further down, ranked
   Critical → High → Medium → Low with a plain-English recommendation for
   each.
4. Scroll down for the detail sections: Defender Status, App & Browser
   Control, Device Security, Device Performance & Health, a searchable
   **Threat Detections** grid (with an **Action** column flagging anything
   still needing attention), and a searchable **Protection History** grid
   of recent Defender events.
5. This tab is entirely read-only — nothing is changed, and no admin
   rights are needed.

### Step 7 — Investigate security events (optional)
1. Go to the **Security Events** tab.
2. Click **▶ SCAN SECURITY EVENTS**. WinPatch captures the last 7 days of
   the Windows Security log plus System, PowerShell, RDP connection, Task
   Scheduler, and Application channels in one check.
3. Read the **INVESTIGATION SUMMARY** card first — it shows the
   highest-severity finding (or "No findings flagged" if nothing
   correlated stands out).
4. Review the **Investigation Findings** grid — patterns WinPatch spotted
   (failed-logon bursts, audit log clears, privileged group changes,
   suspicious PowerShell activity), each with a **Severity** badge (how
   bad it is), an **Urgency** badge (how soon it deserves attention), and
   a plain-English recommendation.
5. Scroll down to the **Captured Events** grid for every individual event
   behind those findings — searchable by channel, category, account, or
   message text — each also marked with its own Severity and Urgency.
6. This tab is entirely read-only — nothing is changed. Findings are a
   starting point for investigation, not a verdict — always review the
   underlying events before acting.

---

## 5. How to Download Reports

Every tab has its own **EXPORT HTML** and **EXPORT CSV** buttons:

| Tab | Export buttons found | Report produced |
|---|---|---|
| **Missing Patches** | Top-right of the header toolbar | Patch scan report — risk panel, severity breakdown, full findings table with Catalog links. |
| **Installed Applications** | Above the applications grid | Combined *Applications, Services & Updates* report. |
| **Windows Services** | Above the services grid | Same combined report as above. |
| **Application Updates** | Above the updates grid | Same combined report, with an added "Available Application Updates" section. |
| **Security Center** | Top-right of the tab toolbar | Its own Security Status report — Defender status, App & browser control, device security, device performance, threat detections, protection history, and severity-ranked highlights. |
| **Security Events** | Top-right of the tab toolbar | Its own Security Events report — Investigation Findings dashboard plus every captured event, each with Severity and Urgency ratings. |

**To export:**
1. Run the relevant scan first (a tab's export buttons stay disabled until
   there's data to export).
2. Click **EXPORT HTML** for a shareable, print-ready report, or
   **EXPORT CSV** for raw data you can open in Excel or feed into another
   tool.
3. A save dialog opens — choose where to save the file and click **Save**.
4. WinPatch asks if you'd like to open the file now — click **Yes** to view
   it immediately.

Every HTML report is a single, self-contained file (no internet connection
needed to view it later) with the WinPatch logo top-right and a footer
reading *AMITAVA GUPTA VU3IBL Copy Right @2026*.

---

## Troubleshooting

- **Scan fails immediately** — confirm the Windows Update service
  (`wuauserv`) is running (`services.msc`).
- **Install buttons stay greyed out** — you need to run as Administrator;
  use the amber banner's **RESTART AS ADMINISTRATOR** button.
- **CHECK FOR UPDATES can't find winget** — install "App Installer" from the
  Microsoft Store, or confirm it's on PATH by running `winget --version` in
  a terminal.
- **Corporate/managed PC shows fewer or different patches** — WSUS/Intune
  policies can restrict or redirect what's reported; this matches what
  Windows Update itself would show on that machine.
- **Security Center shows "Unavailable" or "N/A" for some fields** — usually
  means that feature genuinely isn't present on this PC (no TPM, a VM
  without Secure Boot/Memory Integrity, or a third-party antivirus with
  Defender turned off) rather than a scan failure — every check is read
  independently, so one missing feature never blocks the rest of the tab.
- **CHECK SECURITY STATUS fails outright** — confirm `powershell.exe` runs
  from a Command Prompt on that PC; some locked-down/kiosk machines
  restrict PowerShell execution entirely.
- **Security Events tab shows few or no Security-channel events** — the
  account running WinPatch likely lacks read access to the Security log;
  add it to the local Administrators or "Event Log Readers" group. Other
  channels (System, PowerShell, etc.) are unaffected and still populate.
- **A Security Events finding looks like a false positive** — findings are
  pattern-matching heuristics (event counts, keyword matches), not
  verdicts; check the underlying events in the Captured Events grid
  before treating anything as confirmed.
