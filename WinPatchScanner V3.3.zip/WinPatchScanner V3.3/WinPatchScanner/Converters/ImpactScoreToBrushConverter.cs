using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace WinPatchScanner.Converters
{
    public class ImpactScoreToBrushConverter : IValueConverter
    {
        public object Convert(object? value, Type targetType, object parameter, CultureInfo culture)
        {
            double score = value switch
            {
                double d => d,
                int i => i,
                _ => 0
            };

            if (score >= 9) return new SolidColorBrush(Color.FromRgb(0xFF, 0x4D, 0x5E));
            if (score >= 7) return new SolidColorBrush(Color.FromRgb(0xFF, 0xB0, 0x3B));
            if (score >= 5) return new SolidColorBrush(Color.FromRgb(0x38, 0xE1, 0xFF));
            if (score >= 3) return new SolidColorBrush(Color.FromRgb(0x3D, 0xFF, 0xA0));
            return new SolidColorBrush(Color.FromRgb(0x7A, 0x88, 0x96));
        }

        public object ConvertBack(object? value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
