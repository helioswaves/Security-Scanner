using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace WinPatchScanner.Converters
{
    public class SeverityToBrushConverter : IValueConverter
    {
        public object Convert(object? value, Type targetType, object parameter, CultureInfo culture)
        {
            string severity = value as string ?? "Unspecified";
            return severity switch
            {
                "Critical" or "Immediate" => new SolidColorBrush(Color.FromRgb(0xFF, 0x4D, 0x5E)),
                "Important" or "High" => new SolidColorBrush(Color.FromRgb(0xFF, 0xB0, 0x3B)),
                "Moderate" or "Medium" or "Normal" => new SolidColorBrush(Color.FromRgb(0x38, 0xE1, 0xFF)),
                "Low" => new SolidColorBrush(Color.FromRgb(0x3D, 0xFF, 0xA0)),
                _ => new SolidColorBrush(Color.FromRgb(0x7A, 0x88, 0x96)),
            };
        }

        public object ConvertBack(object? value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
