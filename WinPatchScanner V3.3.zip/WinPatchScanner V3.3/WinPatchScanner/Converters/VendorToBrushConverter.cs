using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

namespace WinPatchScanner.Converters
{
    /// <summary>Colors a "Microsoft" / "Non-Microsoft" vendor badge.</summary>
    public class VendorToBrushConverter : IValueConverter
    {
        public object Convert(object? value, Type targetType, object parameter, CultureInfo culture)
        {
            bool isMicrosoft = value is bool b && b;
            return isMicrosoft
                ? new SolidColorBrush(Color.FromRgb(0x38, 0xE1, 0xFF))   // cyan - Microsoft
                : new SolidColorBrush(Color.FromRgb(0xFF, 0xB0, 0x3B));  // amber - non-Microsoft
        }

        public object ConvertBack(object? value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }
    }
}
