using System.Windows;

namespace WinPatchScanner
{
    public partial class App : Application
    {
    }
}
