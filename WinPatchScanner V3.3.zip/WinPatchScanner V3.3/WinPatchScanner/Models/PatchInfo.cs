using System.ComponentModel;

namespace WinPatchScanner.Models
{
    public class PatchInfo : INotifyPropertyChanged
    {
        public string Title { get; set; } = "";
        public string KB { get; set; } = "";
        public string Severity { get; set; } = "Unspecified";
        public string Categories { get; set; } = "";
        public double SizeMB { get; set; }
        public string ReleaseDate { get; set; } = "";
        public string Description { get; set; } = "";
        public string SupportUrl { get; set; } = "";
        public bool IsDownloaded { get; set; }

        /// <summary>Unique Windows Update identity, used internally to map back to the COM update object for install.</summary>
        public string UpdateId { get; set; } = "";

        /// <summary>1 (informational) - 10 (critical, immediate action) computed by ImpactAnalyzer.</summary>
        public double ImpactScore { get; set; }
        public string ImpactLabel { get; set; } = "";

        /// <summary>Link to the Microsoft Update Catalog page for this KB (or the vendor support URL as fallback).</summary>
        public string CatalogUrl { get; set; } = "";

        private bool _isSelected;
        public bool IsSelected
        {
            get => _isSelected;
            set { _isSelected = value; OnPropertyChanged(nameof(IsSelected)); }
        }

        private string _installStatus = "Not installed";
        public string InstallStatus
        {
            get => _installStatus;
            set { _installStatus = value; OnPropertyChanged(nameof(InstallStatus)); }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged(string name) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
