using System;

namespace WinPatchScanner.Models
{
    /// <summary>One entry from the Microsoft-Windows-Windows Defender/Operational event
    /// log - the same feed Windows Security's "Protection history" page is built from.</summary>
    public class ProtectionEventInfo
    {
        public DateTime? TimeCreated { get; set; }
        public int EventId { get; set; }

        /// <summary>Friendly label for well-known Defender event IDs; falls back to
        /// "Defender event &lt;id&gt;" for anything not in the lookup table.</summary>
        public string Category { get; set; } = "";

        /// <summary>The event's native Windows Event Log level (Critical/Error/Warning/Information/Verbose).</summary>
        public string Level { get; set; } = "";

        /// <summary>Critical / High / Medium / Low / Info - drives the severity badge color.</summary>
        public string Severity { get; set; } = "";

        public string Message { get; set; } = "";
    }
}
