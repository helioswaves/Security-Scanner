using System;

namespace WinPatchScanner.Models
{
    /// <summary>A single Microsoft Defender threat detection, from Get-MpThreatDetection
    /// joined with Get-MpThreat for the name/severity/category.</summary>
    public class ThreatDetectionInfo
    {
        public string ThreatName { get; set; } = "Unknown threat";
        public string Category { get; set; } = "";

        /// <summary>Critical / High / Medium / Low / Unknown - drives the severity badge color.</summary>
        public string Severity { get; set; } = "Unknown";

        /// <summary>Best-effort status label; the raw Defender status code is shown alongside it
        /// since the full code table isn't officially published.</summary>
        public string Status { get; set; } = "";

        /// <summary>True when Defender's own AdditionalActionsBitMask flags this detection as
        /// still needing action (e.g. a restart to finish removal) - the reliable "pending
        /// action" signal, independent of the best-effort Status label above.</summary>
        public bool ActionNeeded { get; set; }

        public DateTime? DetectionTime { get; set; }
        public DateTime? LastStatusChangeTime { get; set; }
        public string ProcessName { get; set; } = "";
        public string Resources { get; set; } = "";
    }
}
