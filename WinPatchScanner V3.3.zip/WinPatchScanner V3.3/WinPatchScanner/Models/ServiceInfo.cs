namespace WinPatchScanner.Models
{
    public class ServiceInfo
    {
        public string Name { get; set; } = "";
        public string DisplayName { get; set; } = "";
        public string State { get; set; } = "";       // Running / Stopped / ...
        public string StartMode { get; set; } = "";    // Auto / Manual / Disabled
        public string PathName { get; set; } = "";
        public string Account { get; set; } = "";
        public string Publisher { get; set; } = "";     // resolved from file version info where possible

        /// <summary>True when the service's binary/publisher identifies Microsoft as the vendor.</summary>
        public bool IsMicrosoft { get; set; }

        public string VendorGroup => IsMicrosoft ? "Microsoft" : "Non-Microsoft";
    }
}
