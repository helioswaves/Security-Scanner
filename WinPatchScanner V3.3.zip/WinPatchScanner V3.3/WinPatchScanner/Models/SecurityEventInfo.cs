using System;

namespace WinPatchScanner.Models
{
    /// <summary>One captured event from the Windows Security log or one of the other
    /// investigation-relevant channels (System, PowerShell/Operational, RDP connection
    /// manager, Task Scheduler, Application) - the raw material the Security Events tab's
    /// findings are correlated from.</summary>
    public class SecurityEventInfo
    {
        public DateTime? TimeCreated { get; set; }

        /// <summary>The event log channel this came from, e.g. "Security", "System".</summary>
        public string Channel { get; set; } = "";

        public int EventId { get; set; }

        /// <summary>Friendly label for well-known event IDs, e.g. "Failed logon".</summary>
        public string Category { get; set; } = "";

        /// <summary>The event's native Windows Event Log level.</summary>
        public string Level { get; set; } = "";

        /// <summary>Critical / High / Medium / Low / Info - how bad this is if it's real.</summary>
        public string Severity { get; set; } = "Info";

        /// <summary>Immediate / High / Normal / Low - how soon it deserves a look.</summary>
        public string Urgency { get; set; } = "Normal";

        /// <summary>Best-effort account name, extracted from the rendered event message.</summary>
        public string Account { get; set; } = "";

        /// <summary>Best-effort source (workstation name / network address), extracted from
        /// the rendered event message where the event template includes one.</summary>
        public string Source { get; set; } = "";

        public string Message { get; set; } = "";
    }
}
