using System.ComponentModel;

namespace WinPatchScanner.Models
{
    /// <summary>An available upgrade for an installed third-party/Microsoft application, as reported by winget.</summary>
    public class AppUpdateInfo : INotifyPropertyChanged
    {
        public string Name { get; set; } = "";
        public string PackageId { get; set; } = "";
        public string InstalledVersion { get; set; } = "";
        public string AvailableVersion { get; set; } = "";
        public string Source { get; set; } = "";

        /// <summary>Best-effort link to the package's page on winget.run for a human to verify before upgrading.</summary>
        public string CatalogUrl { get; set; } = "";

        private bool _isSelected;
        public bool IsSelected
        {
            get => _isSelected;
            set { _isSelected = value; OnPropertyChanged(nameof(IsSelected)); }
        }

        private string _upgradeStatus = "Not upgraded";
        public string UpgradeStatus
        {
            get => _upgradeStatus;
            set { _upgradeStatus = value; OnPropertyChanged(nameof(UpgradeStatus)); }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        private void OnPropertyChanged(string name) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
