using System;

namespace WinPatchScanner.Models
{
    /// <summary>
    /// A point-in-time snapshot of Microsoft Defender / Windows Security status on this
    /// machine - the same data behind Windows Security's Virus &amp; threat protection,
    /// App &amp; browser control, Device security, and Device performance &amp; health pages.
    /// Every field is nullable/defaulted because it's gathered from several independent
    /// checks, each wrapped in its own try/catch on the PowerShell side: a field that
    /// couldn't be read (module not present, feature unsupported on this edition or
    /// hardware, access denied) shows as "Unavailable" in the UI rather than failing the
    /// whole scan.
    /// </summary>
    public class DefenderStatusInfo
    {
        // --- Defender run status / antivirus status ---
        public bool? AMServiceEnabled { get; set; }
        public bool? AntivirusEnabled { get; set; }
        public bool? AntispywareEnabled { get; set; }
        public bool? RealTimeProtectionEnabled { get; set; }
        public bool? OnAccessProtectionEnabled { get; set; }
        public bool? BehaviorMonitorEnabled { get; set; }
        public bool? IoavProtectionEnabled { get; set; }
        public bool? NISEnabled { get; set; }
        public bool? IsTamperProtected { get; set; }
        public string AMEngineVersion { get; set; } = "";
        public string AntivirusSignatureVersion { get; set; } = "";
        public DateTime? AntivirusSignatureLastUpdated { get; set; }
        public DateTime? QuickScanEndTime { get; set; }
        public DateTime? FullScanEndTime { get; set; }
        public string ComputerState { get; set; } = "";

        // --- App & browser control ---
        public string SmartScreenAppsFilesStatus { get; set; } = "Unavailable";
        public string SmartScreenEdgeStatus { get; set; } = "Unavailable";
        public string ExploitProtectionSummary { get; set; } = "Unavailable";

        // --- Device security ---
        public bool? MemoryIntegrityEnabled { get; set; }
        public bool? SecureBootEnabled { get; set; }
        public bool? TpmPresent { get; set; }
        public bool? TpmReady { get; set; }
        public bool? TpmEnabled { get; set; }
        public string TpmSpecVersion { get; set; } = "";

        // --- Device performance & health (best-effort) ---
        public double SystemDriveFreeGB { get; set; }
        public double SystemDriveTotalGB { get; set; }
        public double SystemDriveFreePercent { get; set; }
        public DateTime? LastBootUpTime { get; set; }

        public double SignatureAgeDays => AntivirusSignatureLastUpdated.HasValue
            ? Math.Max(0, (DateTime.Now - AntivirusSignatureLastUpdated.Value).TotalDays)
            : -1;

        public double FullScanAgeDays => FullScanEndTime.HasValue
            ? Math.Max(0, (DateTime.Now - FullScanEndTime.Value).TotalDays)
            : -1;

        public double QuickScanAgeDays => QuickScanEndTime.HasValue
            ? Math.Max(0, (DateTime.Now - QuickScanEndTime.Value).TotalDays)
            : -1;

        public double UptimeHours => LastBootUpTime.HasValue
            ? Math.Max(0, (DateTime.Now - LastBootUpTime.Value).TotalHours)
            : -1;
    }
}
