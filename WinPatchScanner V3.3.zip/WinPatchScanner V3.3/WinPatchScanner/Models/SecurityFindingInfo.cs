using System;

namespace WinPatchScanner.Models
{
    /// <summary>One correlated investigation finding on the Security Events tab - the
    /// analyst-relevant rollup built from patterns across the raw captured events (a
    /// burst of failed logons, an audit log clear, a privilege escalation, a suspicious
    /// PowerShell script block), rather than a single raw log line.</summary>
    public class SecurityFindingInfo
    {
        public string Title { get; set; } = "";

        /// <summary>Critical / High / Medium / Low.</summary>
        public string Severity { get; set; } = "";

        /// <summary>Immediate / High / Normal / Low.</summary>
        public string Urgency { get; set; } = "";

        public string Description { get; set; } = "";
        public string Recommendation { get; set; } = "";
        public int EventCount { get; set; }
        public DateTime? FirstSeen { get; set; }
        public DateTime? LastSeen { get; set; }
    }
}
