namespace WinPatchScanner.Models
{
    /// <summary>One flagged item in the severity-ranked "Highlights" panel of the Security
    /// Center tab - the human-readable rollup of everything else gathered on that tab.</summary>
    public class SecurityIssueInfo
    {
        public string Area { get; set; } = "";

        /// <summary>Critical / High / Medium / Low - drives the severity badge color.</summary>
        public string Severity { get; set; } = "";

        public string Description { get; set; } = "";
        public string Recommendation { get; set; } = "";
    }
}
