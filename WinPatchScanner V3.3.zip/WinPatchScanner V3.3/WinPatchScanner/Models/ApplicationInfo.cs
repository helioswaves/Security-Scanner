namespace WinPatchScanner.Models
{
    public class ApplicationInfo
    {
        public string Name { get; set; } = "";
        public string Publisher { get; set; } = "";
        public string Version { get; set; } = "";
        public string InstallDate { get; set; } = "";
        public double SizeMB { get; set; }
        public string InstallScope { get; set; } = ""; // Machine (all users) / User (current user)
        public string Architecture { get; set; } = "";  // 64-bit / 32-bit

        /// <summary>True when the publisher string identifies Microsoft as the vendor.</summary>
        public bool IsMicrosoft { get; set; }

        public string VendorGroup => IsMicrosoft ? "Microsoft" : "Non-Microsoft";
    }
}
