using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using WinPatchScanner.Models;

namespace WinPatchScanner.Services
{
    /// <summary>CSV export for the Security Events tab: investigation findings first,
    /// then every raw captured event, as one file.</summary>
    public static class SecurityEventCsvBuilder
    {
        public static string Build(string hostname, List<SecurityEventInfo> events,
            List<SecurityFindingInfo> findings, int lookbackDays, DateTime scanTime)
        {
            var sb = new StringBuilder();
            sb.AppendLine(Csv("Report", "Security Events - Investigation"));
            sb.AppendLine(Csv("Host", hostname));
            sb.AppendLine(Csv("Scan Time", scanTime.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture)));
            sb.AppendLine(Csv("Lookback Window", $"{lookbackDays} day(s)"));
            sb.AppendLine(Csv("Events Captured", events.Count.ToString(CultureInfo.InvariantCulture)));
            sb.AppendLine(Csv("Findings", findings.Count.ToString(CultureInfo.InvariantCulture)));
            sb.AppendLine();

            sb.AppendLine(Csv("Investigation Findings", ""));
            sb.AppendLine(Csv("Severity", "Urgency", "Title", "Event Count", "First Seen", "Last Seen", "Description", "Recommendation"));
            foreach (var f in findings)
                sb.AppendLine(Csv(f.Severity, f.Urgency, f.Title, f.EventCount.ToString(CultureInfo.InvariantCulture),
                    D(f.FirstSeen), D(f.LastSeen), f.Description, f.Recommendation));
            sb.AppendLine();

            sb.AppendLine(Csv("Captured Events", ""));
            sb.AppendLine(Csv("Severity", "Urgency", "Time", "Channel", "Event Id", "Category", "Level", "Account", "Source", "Message"));
            foreach (var e in events)
                sb.AppendLine(Csv(e.Severity, e.Urgency, D(e.TimeCreated), e.Channel,
                    e.EventId.ToString(CultureInfo.InvariantCulture), e.Category, e.Level, e.Account, e.Source, e.Message));

            return sb.ToString();
        }

        private static string D(DateTime? d) => d.HasValue ? d.Value.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture) : "";

        private static string Csv(params string?[] fields) => string.Join(",", fields.Select(Escape));

        private static string Escape(string? field)
        {
            field ??= "";
            bool needsQuoting = field.Contains(',') || field.Contains('"') || field.Contains('\n') || field.Contains('\r');
            if (!needsQuoting) return field;
            return "\"" + field.Replace("\"", "\"\"") + "\"";
        }
    }
}
