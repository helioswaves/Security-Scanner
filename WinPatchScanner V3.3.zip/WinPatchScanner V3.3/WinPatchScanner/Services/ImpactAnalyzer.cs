using System;
using WinPatchScanner.Models;

namespace WinPatchScanner.Services
{
    /// <summary>
    /// Produces a 1-10 impact/risk score for a missing patch:
    ///   9-10  Critical  - immediate attention
    ///   7-8   High      - patch soon
    ///   5-6   Medium    - schedule patch
    ///   3-4   Low       - monitor
    ///   1-2   Informational
    ///
    /// Score = severity base + category boost + age boost (capped at 10, floored at 1).
    /// </summary>
    public static class ImpactAnalyzer
    {
        public static (double Score, string Label) Analyze(PatchInfo patch, DateTime referenceTime)
        {
            double score = patch.Severity switch
            {
                "Critical" => 9,
                "Important" => 7,
                "Moderate" => 5,
                "Low" => 3,
                _ => 2,
            };

            if (patch.Categories.Contains("Security", StringComparison.OrdinalIgnoreCase) ||
                patch.Categories.Contains("Critical Updates", StringComparison.OrdinalIgnoreCase))
            {
                score += 1;
            }

            if (DateTime.TryParse(patch.ReleaseDate, out var released))
            {
                double daysMissing = (referenceTime - released).TotalDays;
                if (daysMissing > 180) score += 2;
                else if (daysMissing > 90) score += 1;
            }

            score = Math.Clamp(score, 1, 10);

            string label = score switch
            {
                >= 9 => "Critical - Immediate Action",
                >= 7 => "High - Patch Soon",
                >= 5 => "Medium - Schedule Patch",
                >= 3 => "Low - Monitor",
                _ => "Informational",
            };

            return (score, label);
        }
    }
}
