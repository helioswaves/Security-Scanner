using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using WinPatchScanner.Models;

namespace WinPatchScanner.Services
{
    public class AppUpgradeResultItem
    {
        public string PackageId { get; set; } = "";
        public string Status { get; set; } = "";
    }

    public class AppUpgradeSummary
    {
        public List<AppUpgradeResultItem> Results { get; set; } = new();
        public string OverallMessage { get; set; } = "";
    }

    /// <summary>
    /// Finds and applies upgrades for installed applications using winget (Windows
    /// Package Manager), the built-in Windows 10/11 package manager - the only
    /// realistic way to know whether a third-party app has a newer version without
    /// hand-maintaining a per-vendor version database. Falls back gracefully with a
    /// clear message if winget isn't present on this machine.
    /// </summary>
    public class WingetUpdateScanner
    {
        public event Action<string>? StatusChanged;

        private const int PerPackageUpgradeTimeoutMs = 10 * 60 * 1000; // 10 minutes

        public bool IsWingetAvailable(out string versionOrError)
        {
            try
            {
                var (exitCode, stdout, stderr) = RunCapture("winget", "--version", 10_000);
                if (exitCode == 0 && !string.IsNullOrWhiteSpace(stdout))
                {
                    versionOrError = stdout.Trim();
                    return true;
                }
                versionOrError = string.IsNullOrWhiteSpace(stderr) ? "winget returned no version." : stderr.Trim();
                return false;
            }
            catch (Exception ex)
            {
                versionOrError = ex.Message;
                return false;
            }
        }

        public List<AppUpdateInfo> ScanForUpdates()
        {
            if (!IsWingetAvailable(out string versionOrError))
            {
                throw new InvalidOperationException(
                    "Windows Package Manager (winget) was not found or did not respond (" + versionOrError + "). " +
                    "Install \"App Installer\" from the Microsoft Store, then try again.");
            }

            StatusChanged?.Invoke("Checking winget for available application updates (this can take a minute)...");

            var (exitCode, stdout, stderr) = RunCapture(
                "winget",
                "upgrade --include-unknown --accept-source-agreements",
                5 * 60 * 1000);

            // winget returns a non-zero code when zero upgrades are found on some versions -
            // only treat it as a hard failure if we got no usable output at all.
            if (string.IsNullOrWhiteSpace(stdout) && exitCode != 0)
            {
                throw new InvalidOperationException(
                    "winget upgrade failed: " + (string.IsNullOrWhiteSpace(stderr) ? $"exit code {exitCode}" : stderr.Trim()));
            }

            var results = ParseUpgradeTable(stdout);
            StatusChanged?.Invoke($"Found {results.Count} application update(s) via winget.");
            return results;
        }

        private static List<AppUpdateInfo> ParseUpgradeTable(string output)
        {
            var results = new List<AppUpdateInfo>();
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            string[] lines = output.Replace("\r\n", "\n").Split('\n');
            int i = 0;

            while (i < lines.Length)
            {
                string line = lines[i];

                if (IsHeaderLine(line, out var columns))
                {
                    i++;
                    // Skip the dashed separator line, if present.
                    if (i < lines.Length && lines[i].TrimStart().StartsWith("---")) i++;

                    while (i < lines.Length)
                    {
                        string dataLine = lines[i];
                        if (string.IsNullOrWhiteSpace(dataLine)) break;
                        if (IsHeaderLine(dataLine, out _)) break; // start of another block
                        if (dataLine.TrimStart().StartsWith("---")) { i++; continue; }

                        var fields = SliceColumns(dataLine, columns);
                        string name = fields.GetValueOrDefault("Name", "").Trim();
                        string id = fields.GetValueOrDefault("Id", "").Trim();
                        string installedVer = fields.GetValueOrDefault("Version", "").Trim();
                        string availableVer = fields.GetValueOrDefault("Available", "").Trim();
                        string source = fields.GetValueOrDefault("Source", "").Trim();

                        if (!string.IsNullOrWhiteSpace(name) && !string.IsNullOrWhiteSpace(id))
                        {
                            string dedupeKey = id + "|" + availableVer;
                            if (seen.Add(dedupeKey))
                            {
                                results.Add(new AppUpdateInfo
                                {
                                    Name = name,
                                    PackageId = id,
                                    InstalledVersion = installedVer,
                                    AvailableVersion = availableVer,
                                    Source = string.IsNullOrWhiteSpace(source) ? "winget" : source,
                                    CatalogUrl = BuildCatalogUrl(id),
                                });
                            }
                        }
                        i++;
                    }
                }
                else
                {
                    i++;
                }
            }

            return results.OrderBy(r => r.Name, StringComparer.OrdinalIgnoreCase).ToList();
        }

        private static bool IsHeaderLine(string line, out List<(string Name, int Start)> columns)
        {
            columns = new List<(string, int)>();
            string[] expected = { "Name", "Id", "Version", "Available", "Source" };
            int cursor = 0;
            var found = new List<(string, int)>();

            foreach (var col in expected)
            {
                if (cursor >= line.Length) return false;

                var m = Regex.Match(line.Substring(cursor), $@"\b{col}\b");
                if (!m.Success) return false;
                int absolute = cursor + m.Index;
                found.Add((col, absolute));
                cursor = absolute + col.Length;
            }

            columns = found;
            return true;
        }

        private static Dictionary<string, string> SliceColumns(string line, List<(string Name, int Start)> columns)
        {
            var result = new Dictionary<string, string>();
            for (int c = 0; c < columns.Count; c++)
            {
                int start = columns[c].Start;
                if (start >= line.Length) { result[columns[c].Name] = ""; continue; }

                int end = c + 1 < columns.Count ? columns[c + 1].Start : line.Length;
                end = Math.Min(end, line.Length);
                if (end <= start) { result[columns[c].Name] = ""; continue; }

                result[columns[c].Name] = line.Substring(start, end - start);
            }
            return result;
        }

        private static string BuildCatalogUrl(string packageId)
        {
            if (string.IsNullOrWhiteSpace(packageId)) return "";
            int dot = packageId.IndexOf('.');
            if (dot <= 0 || dot >= packageId.Length - 1)
                return $"https://winstall.app/apps/{Uri.EscapeDataString(packageId)}";

            string publisher = packageId.Substring(0, dot);
            string package = packageId.Substring(dot + 1);
            return $"https://winget.run/pkg/{Uri.EscapeDataString(publisher)}/{Uri.EscapeDataString(package)}";
        }

        public AppUpgradeSummary UpgradePackages(List<AppUpdateInfo> selected, Action<string>? onStatus = null)
        {
            var summary = new AppUpgradeSummary();
            int ok = 0, failed = 0;

            foreach (var pkg in selected)
            {
                onStatus?.Invoke($"Upgrading {pkg.Name} ({pkg.InstalledVersion} -> {pkg.AvailableVersion})...");

                try
                {
                    var (exitCode, _, stderr) = RunCapture(
                        "winget",
                        $"upgrade --id \"{pkg.PackageId}\" --silent --accept-package-agreements --accept-source-agreements --disable-interactivity",
                        PerPackageUpgradeTimeoutMs);

                    string status = exitCode == 0
                        ? "Upgraded"
                        : $"Failed (exit {exitCode}{(string.IsNullOrWhiteSpace(stderr) ? "" : ": " + FirstLine(stderr))})";

                    if (exitCode == 0) ok++; else failed++;
                    summary.Results.Add(new AppUpgradeResultItem { PackageId = pkg.PackageId, Status = status });
                }
                catch (TimeoutException)
                {
                    failed++;
                    summary.Results.Add(new AppUpgradeResultItem { PackageId = pkg.PackageId, Status = "Timed out" });
                }
                catch (Exception ex)
                {
                    failed++;
                    summary.Results.Add(new AppUpgradeResultItem { PackageId = pkg.PackageId, Status = "Failed: " + FirstLine(ex.Message) });
                }
            }

            summary.OverallMessage = $"{ok} upgraded, {failed} failed.";
            onStatus?.Invoke("Upgrade run complete.");
            return summary;
        }

        private static string FirstLine(string s)
        {
            int idx = s.IndexOfAny(new[] { '\r', '\n' });
            return idx > 0 ? s.Substring(0, idx) : s;
        }

        private static (int ExitCode, string StdOut, string StdErr) RunCapture(string fileName, string arguments, int timeoutMs)
        {
            var psi = new ProcessStartInfo
            {
                FileName = fileName,
                Arguments = arguments,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding = Encoding.UTF8,
            };

            using var process = new Process { StartInfo = psi };
            var stdout = new StringBuilder();
            var stderr = new StringBuilder();

            process.OutputDataReceived += (_, e) => { if (e.Data != null) stdout.AppendLine(e.Data); };
            process.ErrorDataReceived += (_, e) => { if (e.Data != null) stderr.AppendLine(e.Data); };

            process.Start();
            process.BeginOutputReadLine();
            process.BeginErrorReadLine();

            if (!process.WaitForExit(timeoutMs))
            {
                try { process.Kill(entireProcessTree: true); } catch { /* best effort */ }
                throw new TimeoutException($"'{fileName} {arguments}' did not complete within {timeoutMs / 1000}s.");
            }

            return (process.ExitCode, stdout.ToString(), stderr.ToString());
        }
    }
}
