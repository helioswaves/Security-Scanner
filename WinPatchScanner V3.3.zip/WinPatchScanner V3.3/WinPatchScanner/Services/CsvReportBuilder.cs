using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using WinPatchScanner.Models;

namespace WinPatchScanner.Services
{
    /// <summary>
    /// Builds a CSV export of the scan results, sorted by impact score (highest risk first),
    /// suitable for Excel, ticketing systems, or feeding into another report pipeline.
    /// </summary>
    public static class CsvReportBuilder
    {
        public static string Build(string hostname, string osCaption, string osBuild, List<PatchInfo> updates, DateTime scanTime)
        {
            var sb = new StringBuilder();

            // Header/meta rows first, then a blank line, then the tabular data -
            // keeps the file useful both as a quick read and as a clean import.
            sb.AppendLine(Csv("Report", "Win Patch Scanner"));
            sb.AppendLine(Csv("Host", hostname));
            sb.AppendLine(Csv("OS", osCaption));
            sb.AppendLine(Csv("Build", osBuild));
            sb.AppendLine(Csv("Scan Time", scanTime.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture)));
            sb.AppendLine(Csv("Missing Total", updates.Count.ToString(CultureInfo.InvariantCulture)));
            sb.AppendLine();

            sb.AppendLine(Csv("Impact Score", "Impact Label", "Severity", "KB", "Title", "Category",
                "Size (MB)", "Released", "Install Status", "Catalog / Install Link"));

            foreach (var u in updates.OrderByDescending(u => u.ImpactScore))
            {
                sb.AppendLine(Csv(
                    u.ImpactScore.ToString("0.#", CultureInfo.InvariantCulture),
                    u.ImpactLabel,
                    u.Severity,
                    u.KB,
                    u.Title,
                    u.Categories,
                    u.SizeMB.ToString(CultureInfo.InvariantCulture),
                    u.ReleaseDate,
                    u.InstallStatus,
                    u.CatalogUrl));
            }

            return sb.ToString();
        }

        private static string Csv(params string?[] fields) => string.Join(",", fields.Select(Escape));

        private static string Escape(string? field)
        {
            field ??= "";
            bool needsQuoting = field.Contains(',') || field.Contains('"') || field.Contains('\n') || field.Contains('\r');
            if (!needsQuoting) return field;
            return "\"" + field.Replace("\"", "\"\"") + "\"";
        }
    }
}
