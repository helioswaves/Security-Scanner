using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using WinPatchScanner.Models;

namespace WinPatchScanner.Services
{
    public class SecurityScanResult
    {
        public DefenderStatusInfo Status { get; set; } = new();
        public List<ThreatDetectionInfo> Threats { get; set; } = new();
        public List<ProtectionEventInfo> ProtectionHistory { get; set; } = new();
        public List<SecurityIssueInfo> Issues { get; set; } = new();
    }

    /// <summary>
    /// Collects Microsoft Defender / Windows Security status via the built-in Defender
    /// PowerShell module and a handful of well-documented registry keys - the same data
    /// behind Windows Security's own "Virus &amp; threat protection", "App &amp; browser
    /// control", "Device security", "Device performance &amp; health" and "Protection
    /// history" pages.
    ///
    /// Everything is gathered in ONE PowerShell invocation, with each section wrapped in
    /// its own try/catch inside the script, so one missing/unsupported feature (no TPM on
    /// a VM, Get-ProcessMitigation unavailable, no Defender operational log access) never
    /// blocks the rest of the scan - it just shows as "Unavailable" for that item. No
    /// section here requires administrator rights on a normal Windows 10/11 install.
    /// </summary>
    public class SecurityScanner
    {
        public event Action<string>? StatusChanged;

        public SecurityScanResult Scan()
        {
            StatusChanged?.Invoke("Checking Microsoft Defender and Windows Security status...");

            string encoded = Convert.ToBase64String(Encoding.Unicode.GetBytes(Script));

            var (exitCode, stdout, stderr) = RunCapture(
                "powershell.exe",
                $"-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand {encoded}",
                90_000);

            if (string.IsNullOrWhiteSpace(stdout))
            {
                throw new InvalidOperationException(
                    "Could not read Windows Security status (no output from PowerShell)." +
                    (string.IsNullOrWhiteSpace(stderr) ? $" Exit code {exitCode}." : " " + FirstLine(stderr)));
            }

            StatusChanged?.Invoke("Parsing results...");

            using var doc = JsonDocument.Parse(stdout);
            JsonElement root = doc.RootElement;

            var result = new SecurityScanResult
            {
                Status = ParseStatus(root),
                Threats = ParseThreats(root),
                ProtectionHistory = ParseProtectionHistory(root),
            };
            result.Issues = ComputeIssues(result.Status, result.Threats);

            StatusChanged?.Invoke("Security status check complete.");
            return result;
        }

        // Runs once, gathering every section into one hashtable so it's a single JSON blob
        // (one process launch instead of six+). Each cmdlet's own possible failure - module
        // missing, feature unsupported, access denied - is caught locally so the rest of the
        // script still runs and still produces valid JSON.
        private const string Script = @"
$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch { }
$result = @{}

try {
    $cs = Get-MpComputerStatus
    $result.ComputerStatus = $cs | Select-Object AMServiceEnabled,AntivirusEnabled,AntispywareEnabled,
        RealTimeProtectionEnabled,OnAccessProtectionEnabled,BehaviorMonitorEnabled,IoavProtectionEnabled,
        NISEnabled,IsTamperProtected,AMEngineVersion,AntivirusSignatureVersion,AntivirusSignatureLastUpdated,
        QuickScanEndTime,FullScanEndTime,ComputerState
} catch { $result.ComputerStatus = $null }

try {
    $result.ThreatDetections = @(Get-MpThreatDetection | Select-Object ThreatID,ProcessName,Resources,
        InitialDetectionTime,LastThreatStatusChangeTime,ThreatStatusID,AdditionalActionsBitMask)
} catch { $result.ThreatDetections = @() }

try {
    $result.Threats = @(Get-MpThreat | Select-Object ThreatID,ThreatName,SeverityID,CategoryID)
} catch { $result.Threats = @() }

try {
    $tpm = Get-Tpm
    $result.Tpm = $tpm | Select-Object TpmPresent,TpmReady,TpmEnabled,SpecVersion
} catch { $result.Tpm = $null }

try {
    $mi = Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity' -Name Enabled -ErrorAction Stop
    $result.MemoryIntegrityEnabled = [int]$mi.Enabled
} catch { $result.MemoryIntegrityEnabled = $null }

try {
    $sb = Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\SecureBoot\State' -Name UEFISecureBootEnabled -ErrorAction Stop
    $result.SecureBootEnabled = [int]$sb.UEFISecureBootEnabled
} catch { $result.SecureBootEnabled = $null }

try {
    $pol = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' -ErrorAction Stop
    $result.SmartScreenPolicyEnabled = $pol.EnableSmartScreen
    $result.SmartScreenPolicyLevel = $pol.ShellSmartScreenLevel
} catch { $result.SmartScreenPolicyEnabled = $null; $result.SmartScreenPolicyLevel = $null }

try {
    $sse = Get-ItemProperty -Path 'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name SmartScreenEnabled -ErrorAction Stop
    $result.SmartScreenLocal = $sse.SmartScreenEnabled
} catch { $result.SmartScreenLocal = $null }

try {
    $edge = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Edge' -Name SmartScreenEnabled -ErrorAction Stop
    $result.EdgeSmartScreenPolicy = [int]$edge.SmartScreenEnabled
} catch { $result.EdgeSmartScreenPolicy = $null }

try {
    $pm = Get-ProcessMitigation -System
    $result.ExploitProtection = @{
        DEP = $pm.DEP.Enable
        CFG = $pm.CFG.Enable
        ASLRBottomUp = $pm.ASLR.BottomUp
        ASLRHighEntropy = $pm.ASLR.HighEntropy
        SEHOP = $pm.SEHOP.Enable
    }
} catch { $result.ExploitProtection = $null }

try {
    $events = Get-WinEvent -LogName 'Microsoft-Windows-Windows Defender/Operational' -MaxEvents 60 -ErrorAction Stop |
        Select-Object TimeCreated,Id,LevelDisplayName,Message
    $result.ProtectionHistory = @($events)
} catch { $result.ProtectionHistory = @() }

try {
    $os = Get-CimInstance Win32_OperatingSystem
    $result.LastBootUpTime = $os.LastBootUpTime
} catch { $result.LastBootUpTime = $null }

$result | ConvertTo-Json -Depth 6
";

        // ----- JSON parsing (all defensive - a missing/renamed field shows blank, never throws) -----

        private static JsonElement? Prop(JsonElement obj, string name)
        {
            if (obj.ValueKind == JsonValueKind.Object && obj.TryGetProperty(name, out var v) &&
                v.ValueKind != JsonValueKind.Undefined)
                return v;
            return null;
        }

        private static bool? GetBool(JsonElement obj, string name)
        {
            var v = Prop(obj, name);
            if (v is null) return null;
            var el = v.Value;
            return el.ValueKind switch
            {
                JsonValueKind.True => true,
                JsonValueKind.False => false,
                JsonValueKind.Number => el.TryGetInt32(out int n) ? n != 0 : (bool?)null,
                JsonValueKind.String => bool.TryParse(el.GetString(), out bool b) ? b : (bool?)null,
                _ => null,
            };
        }

        private static string GetString(JsonElement obj, string name, string fallback = "")
        {
            var v = Prop(obj, name);
            if (v is null) return fallback;
            var el = v.Value;
            return el.ValueKind switch
            {
                JsonValueKind.String => el.GetString() ?? fallback,
                JsonValueKind.Number => el.ToString(),
                JsonValueKind.True => "True",
                JsonValueKind.False => "False",
                _ => fallback,
            };
        }

        private static int? GetInt(JsonElement obj, string name)
        {
            var v = Prop(obj, name);
            if (v is null) return null;
            var el = v.Value;
            if (el.ValueKind == JsonValueKind.Number && el.TryGetInt32(out int n)) return n;
            if (el.ValueKind == JsonValueKind.String && int.TryParse(el.GetString(), out int n2)) return n2;
            return null;
        }

        private static DateTime? GetDateTime(JsonElement obj, string name)
        {
            var v = Prop(obj, name);
            if (v is null) return null;
            var el = v.Value;
            if (el.ValueKind != JsonValueKind.String) return null;
            string s = el.GetString() ?? "";
            if (string.IsNullOrWhiteSpace(s)) return null;
            if (DateTime.TryParse(s, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out var dt))
                return dt;
            if (DateTime.TryParse(s, CultureInfo.InvariantCulture, DateTimeStyles.None, out var dt2))
                return dt2;
            return null;
        }

        // Handles PowerShell's ConvertTo-Json quirk of collapsing a single-item array into a
        // bare object rather than a one-element JSON array.
        private static IEnumerable<JsonElement> AsArray(JsonElement? maybe)
        {
            if (maybe is null) yield break;
            var el = maybe.Value;
            if (el.ValueKind == JsonValueKind.Array)
            {
                foreach (var item in el.EnumerateArray()) yield return item;
            }
            else if (el.ValueKind == JsonValueKind.Object)
            {
                yield return el;
            }
        }

        private static DefenderStatusInfo ParseStatus(JsonElement root)
        {
            var info = new DefenderStatusInfo();

            var cs = Prop(root, "ComputerStatus");
            if (cs is JsonElement csEl && csEl.ValueKind == JsonValueKind.Object)
            {
                info.AMServiceEnabled = GetBool(csEl, "AMServiceEnabled");
                info.AntivirusEnabled = GetBool(csEl, "AntivirusEnabled");
                info.AntispywareEnabled = GetBool(csEl, "AntispywareEnabled");
                info.RealTimeProtectionEnabled = GetBool(csEl, "RealTimeProtectionEnabled");
                info.OnAccessProtectionEnabled = GetBool(csEl, "OnAccessProtectionEnabled");
                info.BehaviorMonitorEnabled = GetBool(csEl, "BehaviorMonitorEnabled");
                info.IoavProtectionEnabled = GetBool(csEl, "IoavProtectionEnabled");
                info.NISEnabled = GetBool(csEl, "NISEnabled");
                info.IsTamperProtected = GetBool(csEl, "IsTamperProtected");
                info.AMEngineVersion = GetString(csEl, "AMEngineVersion");
                info.AntivirusSignatureVersion = GetString(csEl, "AntivirusSignatureVersion");
                info.AntivirusSignatureLastUpdated = GetDateTime(csEl, "AntivirusSignatureLastUpdated");
                info.QuickScanEndTime = GetDateTime(csEl, "QuickScanEndTime");
                info.FullScanEndTime = GetDateTime(csEl, "FullScanEndTime");
                info.ComputerState = GetString(csEl, "ComputerState");
            }

            // App & browser control - SmartScreen for apps/files: a policy value wins over the
            // local per-user setting, matching how Windows itself resolves it.
            var polEnabled = GetInt(root, "SmartScreenPolicyEnabled");
            string policyLevel = "";
            var polLevelEl = Prop(root, "SmartScreenPolicyLevel");
            if (polLevelEl is JsonElement pl && pl.ValueKind == JsonValueKind.String) policyLevel = pl.GetString() ?? "";

            if (polEnabled.HasValue)
            {
                info.SmartScreenAppsFilesStatus = polEnabled.Value == 0
                    ? "Off (policy-managed)"
                    : (string.IsNullOrEmpty(policyLevel) ? "On (policy-managed)" : $"{policyLevel} (policy-managed)");
            }
            else
            {
                string local = GetString(root, "SmartScreenLocal", "");
                info.SmartScreenAppsFilesStatus = local switch
                {
                    "Off" => "Off",
                    "Warn" => "Warn",
                    "RequireAdmin" or "Block" => "Block",
                    "" => "Not configured / unavailable",
                    _ => local,
                };
            }

            var edgePolicy = GetInt(root, "EdgeSmartScreenPolicy");
            info.SmartScreenEdgeStatus = edgePolicy.HasValue
                ? (edgePolicy.Value != 0 ? "On (policy-managed)" : "Off (policy-managed)")
                : "Not policy-managed (per-user setting in Edge)";

            var exploit = Prop(root, "ExploitProtection");
            if (exploit is JsonElement exEl && exEl.ValueKind == JsonValueKind.Object)
            {
                var parts = new List<string>();
                void Add(string label, string prop)
                {
                    var b = GetBool(exEl, prop);
                    if (b.HasValue) parts.Add($"{label}: {(b.Value ? "On" : "Off")}");
                }
                Add("DEP", "DEP");
                Add("CFG", "CFG");
                Add("ASLR (bottom-up)", "ASLRBottomUp");
                Add("ASLR (high entropy)", "ASLRHighEntropy");
                Add("SEHOP", "SEHOP");
                info.ExploitProtectionSummary = parts.Count > 0 ? string.Join(" \u00b7 ", parts) : "Unavailable on this system";
            }

            info.MemoryIntegrityEnabled = GetInt(root, "MemoryIntegrityEnabled") is int mi ? mi != 0 : (bool?)null;
            info.SecureBootEnabled = GetInt(root, "SecureBootEnabled") is int sbv ? sbv != 0 : (bool?)null;

            var tpm = Prop(root, "Tpm");
            if (tpm is JsonElement tpmEl && tpmEl.ValueKind == JsonValueKind.Object)
            {
                info.TpmPresent = GetBool(tpmEl, "TpmPresent");
                info.TpmReady = GetBool(tpmEl, "TpmReady");
                info.TpmEnabled = GetBool(tpmEl, "TpmEnabled");
                info.TpmSpecVersion = GetString(tpmEl, "SpecVersion");
            }

            try
            {
                string root2 = Path.GetPathRoot(Environment.SystemDirectory) ?? "C:\\";
                var drive = new DriveInfo(root2);
                if (drive.IsReady && drive.TotalSize > 0)
                {
                    info.SystemDriveTotalGB = Math.Round(drive.TotalSize / 1024.0 / 1024 / 1024, 1);
                    info.SystemDriveFreeGB = Math.Round(drive.TotalFreeSpace / 1024.0 / 1024 / 1024, 1);
                    info.SystemDriveFreePercent = Math.Round(100.0 * drive.TotalFreeSpace / drive.TotalSize, 1);
                }
            }
            catch { /* best effort */ }

            info.LastBootUpTime = GetDateTime(root, "LastBootUpTime");

            return info;
        }

        private static List<ThreatDetectionInfo> ParseThreats(JsonElement root)
        {
            var threatsById = new Dictionary<string, (string Name, int? SeverityId, int? CategoryId)>(StringComparer.OrdinalIgnoreCase);
            foreach (var t in AsArray(Prop(root, "Threats")))
            {
                string id = GetString(t, "ThreatID");
                if (string.IsNullOrEmpty(id)) continue;
                threatsById[id] = (GetString(t, "ThreatName", "Unknown threat"), GetInt(t, "SeverityID"), GetInt(t, "CategoryID"));
            }

            var results = new List<ThreatDetectionInfo>();
            foreach (var d in AsArray(Prop(root, "ThreatDetections")))
            {
                string id = GetString(d, "ThreatID");
                threatsById.TryGetValue(id, out var meta);

                int? actionMask = GetInt(d, "AdditionalActionsBitMask");

                results.Add(new ThreatDetectionInfo
                {
                    ThreatName = string.IsNullOrEmpty(meta.Name) ? "Unknown threat" : meta.Name,
                    Category = meta.CategoryId.HasValue ? $"Category {meta.CategoryId}" : "",
                    Severity = DescribeSeverity(meta.SeverityId),
                    Status = DescribeThreatStatus(GetInt(d, "ThreatStatusID")),
                    ActionNeeded = actionMask.HasValue && actionMask.Value != 0,
                    DetectionTime = GetDateTime(d, "InitialDetectionTime"),
                    LastStatusChangeTime = GetDateTime(d, "LastThreatStatusChangeTime"),
                    ProcessName = GetString(d, "ProcessName"),
                    Resources = DescribeResources(d),
                });
            }

            return results.OrderByDescending(t => t.DetectionTime ?? DateTime.MinValue).ToList();
        }

        private static string DescribeResources(JsonElement d)
        {
            var v = Prop(d, "Resources");
            if (v is null) return "";
            var el = v.Value;
            if (el.ValueKind == JsonValueKind.Array)
                return string.Join("; ", el.EnumerateArray().Select(x => x.ToString()));
            if (el.ValueKind == JsonValueKind.String)
                return el.GetString() ?? "";
            return "";
        }

        // SeverityID is documented for the Defender WMIv2 provider (MSFT_MpThreat):
        // 0 Unknown, 1 Low, 2 Moderate, 4 High, 5 Severe.
        private static string DescribeSeverity(int? severityId) => severityId switch
        {
            5 => "Critical",
            4 => "High",
            2 => "Medium",
            1 => "Low",
            _ => "Unknown",
        };

        // ThreatStatusID's full enum isn't officially published, so this is a best-effort
        // label with the raw code shown alongside it rather than asserted as fact.
        // ActionNeeded (from AdditionalActionsBitMask) is the reliable "needs attention" signal.
        private static string DescribeThreatStatus(int? statusId) => statusId switch
        {
            null => "Unknown",
            2 => $"Cleaned (code {statusId})",
            3 => $"Quarantined (code {statusId})",
            4 => $"Removed (code {statusId})",
            5 => $"Allowed (code {statusId})",
            6 => $"Blocked (code {statusId})",
            _ => $"Code {statusId}",
        };

        private static readonly Dictionary<int, string> KnownEventCategories = new()
        {
            [1000] = "Scan started",
            [1001] = "Scan finished",
            [1002] = "Scan stopped",
            [1005] = "Scan failed",
            [1006] = "Malware/threat detected",
            [1007] = "Action taken on detected threat",
            [1008] = "Remediation action failed",
            [1009] = "Item restored from quarantine",
            [1116] = "Malware or other threat detected",
            [1117] = "Action taken on malware",
            [1150] = "Scan completed successfully",
            [2000] = "Security intelligence (signature) updated",
            [2001] = "Security intelligence update failed",
            [5001] = "Real-time protection disabled",
            [5004] = "Real-time protection configuration changed",
            [5007] = "Configuration setting changed",
            [5010] = "Scanning for malware disabled",
            [5012] = "Attempt to disable via tamper protection blocked",
        };

        private static readonly Dictionary<int, string> EventSeverityOverride = new()
        {
            [5010] = "Critical",
            [5012] = "Critical",
            [1008] = "High",
            [2001] = "Medium",
            [5001] = "High",
            [5004] = "Medium",
            [1006] = "High",
            [1116] = "High",
        };

        private static List<ProtectionEventInfo> ParseProtectionHistory(JsonElement root)
        {
            var results = new List<ProtectionEventInfo>();
            foreach (var e in AsArray(Prop(root, "ProtectionHistory")))
            {
                int id = GetInt(e, "Id") ?? 0;
                string level = GetString(e, "LevelDisplayName", "Information");

                string severity = EventSeverityOverride.TryGetValue(id, out var ov)
                    ? ov
                    : level switch
                    {
                        "Critical" => "Critical",
                        "Error" => "High",
                        "Warning" => "Medium",
                        _ => "Info",
                    };

                results.Add(new ProtectionEventInfo
                {
                    TimeCreated = GetDateTime(e, "TimeCreated"),
                    EventId = id,
                    Category = KnownEventCategories.TryGetValue(id, out var cat) ? cat : $"Defender event {id}",
                    Level = level,
                    Severity = severity,
                    Message = Truncate(GetString(e, "Message"), 500),
                });
            }

            return results.OrderByDescending(e => e.TimeCreated ?? DateTime.MinValue).ToList();
        }

        private static string Truncate(string s, int max) =>
            string.IsNullOrEmpty(s) || s.Length <= max ? s : s.Substring(0, max) + "\u2026";

        private static List<SecurityIssueInfo> ComputeIssues(DefenderStatusInfo s, List<ThreatDetectionInfo> threats)
        {
            var issues = new List<SecurityIssueInfo>();
            void Add(string area, string severity, string desc, string rec) =>
                issues.Add(new SecurityIssueInfo { Area = area, Severity = severity, Description = desc, Recommendation = rec });

            if (s.AntivirusEnabled == false)
                Add("Antivirus", "Critical", "Microsoft Defender Antivirus is disabled.",
                    "Enable antivirus protection immediately, or confirm another antivirus product is active and up to date.");
            if (s.RealTimeProtectionEnabled == false)
                Add("Real-time protection", "Critical", "Real-time protection is turned off.",
                    "Turn real-time protection back on in Windows Security.");
            if (s.IsTamperProtected == false)
                Add("Tamper protection", "High", "Tamper protection is turned off.",
                    "Turn tamper protection on so malware cannot change Defender's own settings.");

            if (s.AntivirusEnabled != false && s.SignatureAgeDays >= 0)
            {
                if (s.SignatureAgeDays > 7)
                    Add("Signatures", "High", $"Antivirus definitions are {s.SignatureAgeDays:0} day(s) old.",
                        "Update Defender signatures - check internet access and the Windows Update service.");
                else if (s.SignatureAgeDays > 2)
                    Add("Signatures", "Medium", $"Antivirus definitions are {s.SignatureAgeDays:0} day(s) old.",
                        "Run a signature update check soon.");
            }

            if (s.FullScanAgeDays < 0)
                Add("Scans", "Medium", "No full scan on record.", "Run a full Defender scan.");
            else if (s.FullScanAgeDays > 30)
                Add("Scans", "Medium", $"Last full scan was {s.FullScanAgeDays:0} day(s) ago.", "Run a full Defender scan.");

            var pendingThreats = threats.Where(t => t.ActionNeeded).ToList();
            if (pendingThreats.Count > 0)
                Add("Threats", "Critical", $"{pendingThreats.Count} detected threat(s) still need action.",
                    "Open Windows Security > Virus & threat protection > Protection history and resolve the pending item(s).");
            else if (threats.Count > 0)
                Add("Threats", "Medium", $"{threats.Count} threat(s) in history (all resolved).",
                    "Review Protection history for details; no action currently required.");

            if (s.MemoryIntegrityEnabled == false)
                Add("Device security", "Medium", "Memory integrity (Core isolation) is off.",
                    "Turn on Memory integrity in Windows Security > Device security, if hardware/drivers support it.");
            if (s.SecureBootEnabled == false)
                Add("Device security", "Medium", "Secure Boot is off.",
                    "Enable Secure Boot in UEFI firmware settings, if supported.");
            if (s.TpmPresent == false)
                Add("Device security", "Low", "No TPM (security processor) detected.",
                    "Hardware-dependent - not always actionable on older PCs.");
            else if (s.TpmEnabled == false)
                Add("Device security", "Medium", "TPM is present but not enabled.",
                    "Enable the TPM in UEFI firmware settings.");

            if (s.SmartScreenAppsFilesStatus.StartsWith("Off", StringComparison.OrdinalIgnoreCase))
                Add("App & browser control", "Medium", "SmartScreen for apps & files is off.",
                    "Turn on SmartScreen in Windows Security > App & browser control.");

            if (s.SystemDriveTotalGB > 0 && s.SystemDriveFreePercent < 10)
                Add("Device performance", "Medium",
                    $"System drive has only {s.SystemDriveFreePercent:0.#}% free space ({s.SystemDriveFreeGB:0.#} GB).",
                    "Free up disk space - low storage can prevent updates and scans from completing.");

            return issues.OrderBy(i => SeverityRank(i.Severity)).ToList();
        }

        private static int SeverityRank(string severity) => severity switch
        {
            "Critical" => 0,
            "High" => 1,
            "Medium" => 2,
            "Low" => 3,
            _ => 4,
        };

        private static string FirstLine(string s)
        {
            int idx = s.IndexOfAny(new[] { '\r', '\n' });
            return idx > 0 ? s.Substring(0, idx) : s;
        }

        private static (int ExitCode, string StdOut, string StdErr) RunCapture(string fileName, string arguments, int timeoutMs)
        {
            var psi = new ProcessStartInfo
            {
                FileName = fileName,
                Arguments = arguments,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding = Encoding.UTF8,
            };

            using var process = new Process { StartInfo = psi };
            var stdout = new StringBuilder();
            var stderr = new StringBuilder();

            process.OutputDataReceived += (_, e) => { if (e.Data != null) stdout.AppendLine(e.Data); };
            process.ErrorDataReceived += (_, e) => { if (e.Data != null) stderr.AppendLine(e.Data); };

            process.Start();
            process.BeginOutputReadLine();
            process.BeginErrorReadLine();

            if (!process.WaitForExit(timeoutMs))
            {
                try { process.Kill(entireProcessTree: true); } catch { /* best effort */ }
                throw new TimeoutException($"PowerShell did not respond within {timeoutMs / 1000}s.");
            }

            return (process.ExitCode, stdout.ToString(), stderr.ToString());
        }
    }
}
