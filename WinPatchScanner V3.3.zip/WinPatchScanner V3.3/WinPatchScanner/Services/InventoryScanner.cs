using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Management;
using Microsoft.Win32;
using WinPatchScanner.Models;

namespace WinPatchScanner.Services
{
    /// <summary>
    /// Detects installed applications (via the registry Uninstall keys, same source
    /// "Programs and Features" reads from) and Windows services (via WMI Win32_Service),
    /// and classifies each as Microsoft or Non-Microsoft. Entirely read-only - no
    /// elevation, no system changes.
    /// </summary>
    public class InventoryScanner
    {
        public event Action<string>? StatusChanged;

        private static readonly string[] UninstallKeyPaths =
        {
            @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
            @"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall",
        };

        public List<ApplicationInfo> ScanInstalledApplications()
        {
            var results = new List<ApplicationInfo>();
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            StatusChanged?.Invoke("Reading installed applications from the registry...");

            ReadUninstallKeys(Registry.LocalMachine, "Machine (all users)", results, seen);
            ReadUninstallKeys(Registry.CurrentUser, "User (current user)", results, seen);

            StatusChanged?.Invoke($"Found {results.Count} installed application(s).");
            return results.OrderBy(a => a.Name, StringComparer.OrdinalIgnoreCase).ToList();
        }

        private void ReadUninstallKeys(RegistryKey root, string scopeLabel, List<ApplicationInfo> results, HashSet<string> seen)
        {
            foreach (string keyPath in UninstallKeyPaths)
            {
                RegistryKey? uninstallKey = null;
                try { uninstallKey = root.OpenSubKey(keyPath); }
                catch { /* inaccessible - skip */ }

                if (uninstallKey == null) continue;

                foreach (string subKeyName in uninstallKey.GetSubKeyNames())
                {
                    try
                    {
                        using var sub = uninstallKey.OpenSubKey(subKeyName);
                        if (sub == null) continue;

                        string name = sub.GetValue("DisplayName") as string ?? "";
                        if (string.IsNullOrWhiteSpace(name)) continue;

                        // Skip Windows Update / hotfix entries and non-visible system components -
                        // those belong in the patch scan, not the application inventory.
                        int systemComponent = SafeToInt(sub.GetValue("SystemComponent"));
                        if (systemComponent == 1) continue;
                        if (sub.GetValue("ParentKeyName") != null) continue;
                        if (name.StartsWith("KB", StringComparison.OrdinalIgnoreCase) &&
                            name.Contains("Update", StringComparison.OrdinalIgnoreCase)) continue;

                        string dedupeKey = name + "|" + (sub.GetValue("DisplayVersion") as string ?? "");
                        if (!seen.Add(dedupeKey)) continue;

                        string publisher = sub.GetValue("Publisher") as string ?? "Unknown";

                        var app = new ApplicationInfo
                        {
                            Name = name,
                            Publisher = string.IsNullOrWhiteSpace(publisher) ? "Unknown" : publisher,
                            Version = sub.GetValue("DisplayVersion") as string ?? "",
                            InstallDate = FormatInstallDate(sub.GetValue("InstallDate") as string),
                            SizeMB = EstimatedSizeToMb(sub.GetValue("EstimatedSize")),
                            InstallScope = scopeLabel,
                            Architecture = keyPath.Contains("WOW6432Node") ? "32-bit" : "64-bit",
                        };
                        app.IsMicrosoft = LooksLikeMicrosoft(app.Publisher);

                        results.Add(app);
                    }
                    catch
                    {
                        // A single malformed key shouldn't abort the whole scan.
                    }
                }
            }
        }

        private static int SafeToInt(object? value)
        {
            try { return value == null ? 0 : Convert.ToInt32(value); }
            catch { return 0; }
        }

        private static double EstimatedSizeToMb(object? value)
        {
            try
            {
                // EstimatedSize is stored in KB.
                double kb = value == null ? 0 : Convert.ToDouble(value);
                return Math.Round(kb / 1024.0, 1);
            }
            catch { return 0; }
        }

        private static string FormatInstallDate(string? raw)
        {
            if (string.IsNullOrWhiteSpace(raw) || raw.Length != 8) return "";
            if (DateTime.TryParseExact(raw, "yyyyMMdd", null,
                System.Globalization.DateTimeStyles.None, out var dt))
            {
                return dt.ToString("yyyy-MM-dd");
            }
            return "";
        }

        private static bool LooksLikeMicrosoft(string publisher) =>
            publisher.Contains("Microsoft", StringComparison.OrdinalIgnoreCase);

        public List<ServiceInfo> ScanServices()
        {
            var results = new List<ServiceInfo>();

            StatusChanged?.Invoke("Enumerating Windows services...");

            using var searcher = new ManagementObjectSearcher(
                "SELECT Name, DisplayName, State, StartMode, PathName, StartName FROM Win32_Service");

            foreach (ManagementObject mo in searcher.Get())
            {
                string pathName = mo["PathName"]?.ToString() ?? "";
                string exePath = ExtractExecutablePath(pathName);
                string publisher = ResolvePublisher(exePath, pathName);

                var svc = new ServiceInfo
                {
                    Name = mo["Name"]?.ToString() ?? "",
                    DisplayName = mo["DisplayName"]?.ToString() ?? "",
                    State = mo["State"]?.ToString() ?? "",
                    StartMode = mo["StartMode"]?.ToString() ?? "",
                    PathName = pathName,
                    Account = mo["StartName"]?.ToString() ?? "",
                    Publisher = publisher,
                };
                svc.IsMicrosoft = LooksLikeMicrosoft(publisher) || LooksLikeSystemPath(exePath);

                results.Add(svc);
            }

            StatusChanged?.Invoke($"Found {results.Count} service(s).");
            return results.OrderBy(s => s.DisplayName, StringComparer.OrdinalIgnoreCase).ToList();
        }

        private static string ExtractExecutablePath(string pathName)
        {
            if (string.IsNullOrWhiteSpace(pathName)) return "";

            string trimmed = pathName.Trim();
            if (trimmed.StartsWith("\""))
            {
                int endQuote = trimmed.IndexOf('"', 1);
                return endQuote > 1 ? trimmed.Substring(1, endQuote - 1) : trimmed;
            }

            // Unquoted path possibly followed by arguments - take up to the first
            // ".exe" occurrence (case-insensitive), which is the common convention.
            int exeIdx = trimmed.IndexOf(".exe", StringComparison.OrdinalIgnoreCase);
            return exeIdx >= 0 ? trimmed.Substring(0, exeIdx + 4) : trimmed.Split(' ')[0];
        }

        private static string ResolvePublisher(string exePath, string fallbackPathName)
        {
            try
            {
                if (!string.IsNullOrWhiteSpace(exePath) && File.Exists(exePath))
                {
                    var info = FileVersionInfo.GetVersionInfo(exePath);
                    if (!string.IsNullOrWhiteSpace(info.CompanyName))
                        return info.CompanyName!.Trim();
                }
            }
            catch { /* locked/inaccessible file - fall through to path heuristic */ }

            return LooksLikeSystemPath(exePath) || LooksLikeSystemPath(fallbackPathName)
                ? "Microsoft Corporation (system path)"
                : "Unknown";
        }

        private static bool LooksLikeSystemPath(string path)
        {
            if (string.IsNullOrWhiteSpace(path)) return false;
            string p = path.ToLowerInvariant();
            return p.Contains(@"\windows\system32") || p.Contains(@"\windows\syswow64")
                || p.Contains(@"\windows\servicing") || p.Contains(@"\windows\winsxs");
        }
    }
}
