using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using Microsoft.Win32;
using WinPatchScanner.Models;

namespace WinPatchScanner.Services
{
    public class InstallResultItem
    {
        public string UpdateId { get; set; } = "";
        public string Title { get; set; } = "";
        public string Status { get; set; } = "";
    }

    public class InstallSummary
    {
        public List<InstallResultItem> Results { get; set; } = new();
        public bool RebootRequired { get; set; }
        public string OverallMessage { get; set; } = "";
    }

    /// <summary>
    /// Scans the local machine for missing Windows updates, and can download/install
    /// selected ones - all via the native Windows Update Agent COM API
    /// (Microsoft.Update.Session). Scanning needs no elevation; installing does
    /// (the caller is responsible for checking/prompting for administrator rights
    /// before calling InstallUpdates).
    /// </summary>
    public class PatchScanner
    {
        public event Action<string>? StatusChanged;

        // Kept alive between Scan and Install calls so we can map a PatchInfo
        // back to the real COM update object without re-searching.
        private dynamic? _session;
        private readonly Dictionary<string, object> _comUpdatesById = new();

        /// <summary>
        /// Set after every ScanForMissingUpdates call: a human-readable note on which
        /// server this machine's Windows Update is actually talking to. A "0 missing
        /// updates" result means something very different on a machine managed by a
        /// WSUS/Intune policy than on one using public Windows Update directly, so this
        /// is surfaced in the UI rather than left for the user to guess at.
        /// </summary>
        public string LastUpdateSourceInfo { get; private set; } = "";

        public List<PatchInfo> ScanForMissingUpdates(bool includeOptional = true)
        {
            var results = new List<PatchInfo>();
            _comUpdatesById.Clear();
            LastUpdateSourceInfo = DescribeUpdateSource();

            Type? sessionType = Type.GetTypeFromProgID("Microsoft.Update.Session");
            if (sessionType == null)
            {
                throw new InvalidOperationException(
                    "The Windows Update Agent COM API is not available on this system. " +
                    "Confirm this is running on Windows 10/11 and that the 'Windows Update' (wuauserv) service is enabled.");
            }

            dynamic session = Activator.CreateInstance(sessionType)!;
            _session = session;
            dynamic searcher = session.CreateUpdateSearcher();
            searcher.Online = true;

            string criteria = includeOptional
                ? "IsInstalled=0 and Type='Software' and IsHidden=0"
                : "IsInstalled=0 and Type='Software' and IsHidden=0 and BrowseOnly=0";

            StatusChanged?.Invoke("Contacting Windows Update service...");

            dynamic searchResult;
            try
            {
                searchResult = searcher.Search(criteria);
            }
            catch (Exception ex)
            {
                throw new InvalidOperationException(DescribeSearchFailure(ex) + " " + LastUpdateSourceInfo, ex);
            }

            dynamic updates = searchResult.Updates;
            int count = updates.Count;

            StatusChanged?.Invoke($"Found {count} missing update(s). Reading details...");

            var now = DateTime.Now;

            for (int i = 0; i < count; i++)
            {
                dynamic u = updates.Item(i);
                StatusChanged?.Invoke($"Reading update {i + 1} of {count}...");

                var info = new PatchInfo
                {
                    Title = SafeGet(() => (string)u.Title, "Unknown update"),
                    Severity = SafeGet(() =>
                    {
                        string s = u.MsrcSeverity;
                        return string.IsNullOrWhiteSpace(s) ? "Unspecified" : s;
                    }, "Unspecified"),
                    Description = SafeGet(() => (string)u.Description, ""),
                    SupportUrl = SafeGet(() => (string)u.SupportUrl, ""),
                    IsDownloaded = SafeGet(() => (bool)u.IsDownloaded, false),
                    UpdateId = SafeGet(() => (string)u.Identity.UpdateID, Guid.NewGuid().ToString()),
                };

                info.KB = SafeGet(() =>
                {
                    dynamic kbIds = u.KBArticleIDs;
                    return kbIds.Count > 0 ? "KB" + kbIds.Item(0) : "";
                }, "");

                info.Categories = SafeGet(() =>
                {
                    dynamic cats = u.Categories;
                    var names = new List<string>();
                    for (int c = 0; c < cats.Count; c++)
                    {
                        names.Add((string)cats.Item(c).Name);
                    }
                    return string.Join(", ", names);
                }, "");

                info.SizeMB = SafeGet(() =>
                {
                    double bytes = u.MaxDownloadSize;
                    return Math.Round(bytes / (1024.0 * 1024.0), 1);
                }, 0.0);

                info.ReleaseDate = SafeGet(() =>
                {
                    DateTime dt = u.LastDeploymentChangeTime;
                    return dt.ToString("yyyy-MM-dd");
                }, "");

                (info.ImpactScore, info.ImpactLabel) = ImpactAnalyzer.Analyze(info, now);

                info.CatalogUrl = !string.IsNullOrEmpty(info.KB)
                    ? $"https://www.catalog.update.microsoft.com/Search.aspx?q={info.KB}"
                    : (string.IsNullOrEmpty(info.SupportUrl) ? "" : info.SupportUrl);

                _comUpdatesById[info.UpdateId] = u;
                results.Add(info);
            }

            StatusChanged?.Invoke("Scan complete.");
            return results;
        }

        /// <summary>
        /// Downloads and installs the given updates on THIS machine. Requires the process
        /// to already be running elevated - the Windows Update Agent install API will
        /// otherwise fail. Must be called after ScanForMissingUpdates in the same
        /// PatchScanner instance (it reuses the COM objects from that scan).
        /// </summary>
        public InstallSummary InstallUpdates(List<PatchInfo> selected, Action<string>? onStatus = null)
        {
            if (_session == null || _comUpdatesById.Count == 0)
                throw new InvalidOperationException("Run a scan first before installing.");

            Type? collType = Type.GetTypeFromProgID("Microsoft.Update.UpdateColl");
            if (collType == null)
                throw new InvalidOperationException("Windows Update Agent update-collection type is unavailable.");

            dynamic updatesToProcess = Activator.CreateInstance(collType)!;

            foreach (var p in selected)
            {
                if (_comUpdatesById.TryGetValue(p.UpdateId, out var comObj))
                {
                    dynamic u = comObj;
                    try { if (!(bool)u.EulaAccepted) u.AcceptEula(); } catch { /* best effort */ }
                    updatesToProcess.Add(u);
                }
            }

            if (updatesToProcess.Count == 0)
            {
                throw new InvalidOperationException(
                    "The selected updates are no longer available in this session. Please rescan and try again.");
            }

            onStatus?.Invoke($"Downloading {updatesToProcess.Count} update(s)...");
            dynamic downloader = _session.CreateUpdateDownloader();
            downloader.Updates = updatesToProcess;
            downloader.Download();

            dynamic toInstall = Activator.CreateInstance(collType)!;
            foreach (dynamic u in updatesToProcess)
            {
                if (u.IsDownloaded) toInstall.Add(u);
            }

            var summary = new InstallSummary();

            if (toInstall.Count == 0)
            {
                summary.OverallMessage = "Download failed for all selected updates. Nothing was installed.";
                return summary;
            }

            onStatus?.Invoke($"Installing {toInstall.Count} update(s)...");
            dynamic installer = _session.CreateUpdateInstaller();
            installer.Updates = toInstall;
            dynamic installResult = installer.Install();

            summary.RebootRequired = SafeGet(() => (bool)installResult.RebootRequired, false);

            int installedOk = 0, failed = 0;
            for (int i = 0; i < toInstall.Count; i++)
            {
                dynamic u = toInstall.Item(i);
                dynamic r = installResult.GetUpdateResult(i);
                int code = SafeGet(() => (int)r.ResultCode, 4);
                string status = code switch
                {
                    2 => "Installed",
                    3 => "Installed (with errors)",
                    4 => "Failed",
                    5 => "Cancelled",
                    _ => "Unknown",
                };

                if (status.StartsWith("Installed")) installedOk++;
                else if (status == "Failed") failed++;

                summary.Results.Add(new InstallResultItem
                {
                    UpdateId = SafeGet(() => (string)u.Identity.UpdateID, ""),
                    Title = SafeGet(() => (string)u.Title, ""),
                    Status = status,
                });
            }

            summary.OverallMessage = $"{installedOk} installed, {failed} failed" +
                (summary.RebootRequired ? " - restart required to finish." : ".");

            onStatus?.Invoke("Install complete.");
            return summary;
        }

        private static T SafeGet<T>(Func<T> getter, T fallback)
        {
            try { return getter(); }
            catch { return fallback; }
        }

        // A handful of the WUA search failures that actually show up in the field,
        // mapped to plain-English causes - the raw COM exception message is usually
        // just "Exception from HRESULT: 0x8024402C", which tells a user nothing.
        private static readonly Dictionary<uint, string> KnownSearchErrors = new()
        {
            [0x8024402C] = "Could not reach the Windows Update servers (DNS/name resolution failed) - check this PC's internet connection or proxy settings.",
            [0x80244022] = "The Windows Update service responded with 'server unavailable' - it may be temporarily overloaded, or a proxy/firewall is blocking the request. Try again shortly.",
            [0x80072EE2] = "The connection to Windows Update timed out - check this PC's internet connection or proxy settings.",
            [0x80070422] = "The Windows Update service (wuauserv) is disabled on this PC. Enable it via services.msc (set to Manual or Automatic) and try again.",
            [0x8024001E] = "The scan was interrupted (Windows Update service stopped mid-search). Try again.",
            [0x80240438] = "The Windows Update Agent could not establish a secure connection - check date/time and TLS settings on this PC.",
            [0x8024D009] = "This PC's Windows Update Agent needs updating before it can search for updates.",
        };

        private static string DescribeSearchFailure(Exception ex)
        {
            uint hr = unchecked((uint)(ex is COMException comEx ? comEx.ErrorCode : ex.HResult));
            if (KnownSearchErrors.TryGetValue(hr, out var known))
                return known;

            return $"Windows Update search failed (error 0x{hr:X8}): {ex.Message.Trim()}";
        }

        /// <summary>
        /// Best-effort read of the Group Policy keys that redirect a machine's Windows
        /// Update to an internal WSUS/Configuration Manager server instead of public
        /// Windows Update. A machine in this state can legitimately show far fewer (or
        /// zero) missing updates than one using public Windows Update directly, since it
        /// only ever sees what that internal server has synced and approved - that's not
        /// a bug in the scan, it's what Windows Update itself would show on that PC too.
        /// </summary>
        private static string DescribeUpdateSource()
        {
            try
            {
                using var auKey = Registry.LocalMachine.OpenSubKey(
                    @"SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU");
                using var wuKey = Registry.LocalMachine.OpenSubKey(
                    @"SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate");

                object? useWuServer = auKey?.GetValue("UseWUServer");
                object? wuServer = wuKey?.GetValue("WUServer");

                if (useWuServer is int i && i == 1 && wuServer is string server && !string.IsNullOrWhiteSpace(server))
                {
                    return $"Update source: managed by your organization's WSUS server ({server}). " +
                           "Results reflect what that server has synced/approved, not the full public Windows Update catalog.";
                }

                return "Update source: public Windows Update (no WSUS/Intune policy redirect detected).";
            }
            catch
            {
                return "";
            }
        }
    }
}
