using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using WinPatchScanner.Models;

namespace WinPatchScanner.Services
{
    public static class HtmlReportBuilder
    {
        public static string Build(string hostname, string osCaption, string osBuild, List<PatchInfo> updates, DateTime scanTime)
        {
            int critical = updates.Count(u => u.Severity == "Critical");
            int important = updates.Count(u => u.Severity == "Important");
            int moderate = updates.Count(u => u.Severity == "Moderate");
            int low = updates.Count(u => u.Severity == "Low");
            int unspecified = updates.Count - critical - important - moderate - low;
            double totalSizeMb = Math.Round(updates.Sum(u => u.SizeMB), 1);
            int total = updates.Count;

            double peakRisk = total > 0 ? updates.Max(u => u.ImpactScore) : 0;
            double avgRisk = total > 0 ? Math.Round(updates.Average(u => u.ImpactScore), 1) : 0;
            string peakLabel = total > 0 ? updates.OrderByDescending(u => u.ImpactScore).First().ImpactLabel : "No missing patches";

            var sb = new StringBuilder();
            sb.Append($@"<!DOCTYPE html>
<html lang=""en"">
<head>
<meta charset=""UTF-8"">
<title>Patch Scan Report - {Enc(hostname)}</title>
<style>
  :root {{
    --bg:#0A0E14; --panel:#10161F; --panel-alt:#151C27; --border:#243040;
    --cyan:#38E1FF; --green:#3DFFA0; --amber:#FFB03B; --red:#FF4D5E;
    --text:#C9D6E3; --muted:#7A8896;
  }}
  * {{ box-sizing:border-box; }}
  body {{
    background:var(--bg); color:var(--text); margin:0; padding:32px;
    font-family:Consolas,'Courier New',monospace;
  }}
  .header {{
    display:flex; justify-content:space-between; align-items:flex-start;
    border-bottom:1px solid var(--border); padding-bottom:16px; margin-bottom:24px;
  }}
  h1 {{ color:var(--cyan); font-size:20px; letter-spacing:2px; margin:0 0 6px 0; text-transform:uppercase; }}
  .meta {{ color:var(--muted); font-size:12px; line-height:1.7; }}
  .meta b {{ color:var(--text); }}
  .top-row {{ display:flex; gap:16px; margin-bottom:24px; align-items:stretch; flex-wrap:wrap; }}
  .risk-panel {{
    background:var(--panel); border:1px solid var(--border); border-radius:4px;
    padding:16px 24px; display:flex; align-items:center; gap:20px; min-width:280px;
  }}
  .risk-number {{ font-size:48px; font-weight:bold; line-height:1; }}
  .risk-meta .label {{ color:var(--muted); font-size:10px; letter-spacing:1px; text-transform:uppercase; margin-bottom:4px; }}
  .risk-meta .desc {{ font-size:13px; font-weight:bold; }}
  .risk-meta .sub {{ font-size:11px; color:var(--muted); margin-top:4px; }}
  .r-critical {{ color:var(--red); }}
  .r-high {{ color:var(--amber); }}
  .r-medium {{ color:var(--cyan); }}
  .r-low {{ color:var(--green); }}
  .r-info {{ color:var(--muted); }}
  .cards {{ display:flex; gap:12px; flex-wrap:wrap; flex:1; }}
  .card {{
    background:var(--panel); border:1px solid var(--border); border-radius:4px;
    padding:14px 18px; min-width:110px;
  }}
  .card .label {{ color:var(--muted); font-size:10px; letter-spacing:1px; text-transform:uppercase; }}
  .card .value {{ font-size:24px; font-weight:bold; margin-top:6px; }}
  .c-total .value {{ color:var(--text); }}
  .c-critical .value {{ color:var(--red); }}
  .c-important .value {{ color:var(--amber); }}
  .c-moderate .value {{ color:var(--cyan); }}
  .c-low .value {{ color:var(--green); }}
  .c-size .value {{ color:var(--text); font-size:18px; }}
  .bar-wrap {{
    background:var(--panel); border:1px solid var(--border); border-radius:4px;
    padding:16px 18px; margin-bottom:24px;
  }}
  .bar-title {{ color:var(--muted); font-size:10px; letter-spacing:1px; text-transform:uppercase; margin-bottom:10px; }}
  .bar {{ display:flex; height:14px; border-radius:3px; overflow:hidden; background:var(--panel-alt); }}
  .bar div {{ height:100%; }}
  .bar .seg-critical {{ background:var(--red); }}
  .bar .seg-important {{ background:var(--amber); }}
  .bar .seg-moderate {{ background:var(--cyan); }}
  .bar .seg-low {{ background:var(--green); }}
  .bar .seg-unspecified {{ background:var(--muted); }}
  .legend {{ display:flex; gap:18px; margin-top:10px; font-size:11px; color:var(--muted); flex-wrap:wrap; }}
  .legend span.dot {{ display:inline-block; width:8px; height:8px; border-radius:50%; margin-right:5px; }}
  table {{ width:100%; border-collapse:collapse; background:var(--panel); border:1px solid var(--border); border-radius:4px; overflow:hidden; }}
  th {{
    background:var(--panel-alt); color:var(--muted); text-align:left; font-size:10px;
    letter-spacing:1px; text-transform:uppercase; padding:10px 12px; border-bottom:1px solid var(--border);
  }}
  td {{ padding:10px 12px; font-size:12px; border-bottom:1px solid var(--border); vertical-align:top; }}
  tr:last-child td {{ border-bottom:none; }}
  tr:hover td {{ background:#1C2733; }}
  .badge {{
    display:inline-block; padding:2px 8px; border-radius:10px; font-size:10px; font-weight:bold;
    letter-spacing:0.5px; text-transform:uppercase; white-space:nowrap;
  }}
  .b-critical {{ background:rgba(255,77,94,0.15); color:var(--red); border:1px solid var(--red); }}
  .b-important {{ background:rgba(255,176,59,0.15); color:var(--amber); border:1px solid var(--amber); }}
  .b-moderate {{ background:rgba(56,225,255,0.15); color:var(--cyan); border:1px solid var(--cyan); }}
  .b-low {{ background:rgba(61,255,160,0.15); color:var(--green); border:1px solid var(--green); }}
  .b-unspecified {{ background:rgba(122,136,150,0.15); color:var(--muted); border:1px solid var(--muted); }}
  .impact {{ font-weight:bold; font-size:13px; }}
  .kb {{ color:var(--cyan); }}
  .cat-link {{ color:var(--cyan); text-decoration:none; border-bottom:1px dotted var(--cyan); white-space:nowrap; }}
  .cat-link:hover {{ color:var(--text); }}
  .empty {{ text-align:center; color:var(--muted); padding:40px; }}
  footer {{ margin-top:24px; color:var(--muted); font-size:10px; text-align:center; letter-spacing:1px; }}
  .disclaimer {{ margin-top:8px; color:var(--muted); font-size:10px; text-align:center; }}
  .copyright {{ margin-top:4px; color:var(--muted); font-size:10px; text-align:center; letter-spacing:0.5px; }}
  .brand-logo {{ margin-left:auto; margin-bottom:8px; }}
</style>
</head>
<body>

<div class=""header"">
  <div>
    <h1>&#9679; Windows Patch Scan Report</h1>
    <div class=""meta"">
      <div>Host: <b>{Enc(hostname)}</b></div>
      <div>OS: <b>{Enc(osCaption)}</b> (Build {Enc(osBuild)})</div>
    </div>
  </div>
  <div style=""text-align:right"">
    {ReportBranding.LogoImgHtml(28)}
    <div class=""meta"" style=""text-align:right"">
      <div>Scan time</div>
      <div><b>{scanTime:yyyy-MM-dd HH:mm:ss}</b></div>
    </div>
  </div>
</div>

<div class=""top-row"">
  <div class=""risk-panel"">
    <div class=""risk-number {RiskClass(peakRisk)}"">{(total > 0 ? peakRisk.ToString("0.#") : "—")}<span style=""font-size:16px"">/10</span></div>
    <div class=""risk-meta"">
      <div class=""label"">Peak Impact / Risk Score</div>
      <div class=""desc {RiskClass(peakRisk)}"">{Enc(peakLabel)}</div>
      <div class=""sub"">Average across all findings: {avgRisk}/10 &middot; {total} missing patch(es)</div>
    </div>
  </div>

  <div class=""cards"">
    <div class=""card c-total""><div class=""label"">Missing Total</div><div class=""value"">{total}</div></div>
    <div class=""card c-critical""><div class=""label"">Critical</div><div class=""value"">{critical}</div></div>
    <div class=""card c-important""><div class=""label"">Important</div><div class=""value"">{important}</div></div>
    <div class=""card c-moderate""><div class=""label"">Moderate</div><div class=""value"">{moderate}</div></div>
    <div class=""card c-low""><div class=""label"">Low / Other</div><div class=""value"">{low + unspecified}</div></div>
    <div class=""card c-size""><div class=""label"">Download Size</div><div class=""value"">{totalSizeMb} MB</div></div>
  </div>
</div>
");

            if (total > 0)
            {
                double PctOf(int n) => total == 0 ? 0 : Math.Round(100.0 * n / total, 2);
                sb.Append($@"
<div class=""bar-wrap"">
  <div class=""bar-title"">Severity Breakdown</div>
  <div class=""bar"">
    <div class=""seg-critical"" style=""width:{PctOf(critical)}%""></div>
    <div class=""seg-important"" style=""width:{PctOf(important)}%""></div>
    <div class=""seg-moderate"" style=""width:{PctOf(moderate)}%""></div>
    <div class=""seg-low"" style=""width:{PctOf(low)}%""></div>
    <div class=""seg-unspecified"" style=""width:{PctOf(unspecified)}%""></div>
  </div>
  <div class=""legend"">
    <div><span class=""dot"" style=""background:var(--red)""></span>Critical ({critical})</div>
    <div><span class=""dot"" style=""background:var(--amber)""></span>Important ({important})</div>
    <div><span class=""dot"" style=""background:var(--cyan)""></span>Moderate ({moderate})</div>
    <div><span class=""dot"" style=""background:var(--green)""></span>Low ({low})</div>
    <div><span class=""dot"" style=""background:var(--muted)""></span>Unspecified ({unspecified})</div>
  </div>
</div>
");
            }

            sb.Append(@"
<table>
  <thead>
    <tr>
      <th style=""width:60px"">Risk</th>
      <th style=""width:95px"">Severity</th>
      <th style=""width:85px"">KB</th>
      <th>Title</th>
      <th style=""width:160px"">Category</th>
      <th style=""width:70px"">Size</th>
      <th style=""width:95px"">Released</th>
      <th style=""width:90px"">Install</th>
    </tr>
  </thead>
  <tbody>
");

            if (total == 0)
            {
                sb.Append(@"<tr><td colspan=""8"" class=""empty"">No missing updates found. System is up to date as of this scan.</td></tr>");
            }
            else
            {
                foreach (var u in updates.OrderByDescending(u => u.ImpactScore))
                {
                    string badgeClass = "b-" + u.Severity.ToLowerInvariant();
                    string riskClass = RiskClass(u.ImpactScore);
                    string linkHtml = string.IsNullOrEmpty(u.CatalogUrl)
                        ? "<span style=\"color:var(--muted)\">n/a</span>"
                        : $@"<a class=""cat-link"" href=""{Enc(u.CatalogUrl)}"" target=""_blank"" rel=""noopener"">Get patch &#8599;</a>";

                    sb.Append($@"
    <tr>
      <td><span class=""impact {riskClass}"">{u.ImpactScore:0.#}</span></td>
      <td><span class=""badge {badgeClass}"">{Enc(u.Severity)}</span></td>
      <td class=""kb"">{Enc(u.KB)}</td>
      <td>{Enc(u.Title)}</td>
      <td>{Enc(u.Categories)}</td>
      <td>{u.SizeMB} MB</td>
      <td>{Enc(u.ReleaseDate)}</td>
      <td>{linkHtml}</td>
    </tr>");
                }
            }

            sb.Append($@"
  </tbody>
</table>

<div class=""disclaimer"">Risk score = severity + security-category weighting + time missing (1 = informational, 10 = critical/immediate). Install links open the Microsoft Update Catalog.</div>
<footer>GENERATED BY WIN PATCH SCANNER &middot; {scanTime:yyyy-MM-dd HH:mm:ss}</footer>
<div class=""copyright"">{Enc(ReportBranding.CopyrightText)}</div>

</body>
</html>");

            return sb.ToString();
        }

        private static string RiskClass(double score) => score switch
        {
            >= 9 => "r-critical",
            >= 7 => "r-high",
            >= 5 => "r-medium",
            >= 3 => "r-low",
            _ => "r-info",
        };

        private static string Enc(string? s) => WebUtility.HtmlEncode(s ?? "");
    }
}
