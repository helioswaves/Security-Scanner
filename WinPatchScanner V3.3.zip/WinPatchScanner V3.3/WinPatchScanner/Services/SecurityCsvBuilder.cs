using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using WinPatchScanner.Models;

namespace WinPatchScanner.Services
{
    /// <summary>CSV export for the Security Center tab: status summary, threats,
    /// protection history and the severity-ranked highlights, as one file.</summary>
    public static class SecurityCsvBuilder
    {
        public static string Build(string hostname, DefenderStatusInfo status, List<ThreatDetectionInfo> threats,
            List<ProtectionEventInfo> history, List<SecurityIssueInfo> issues, DateTime scanTime)
        {
            var sb = new StringBuilder();
            sb.AppendLine(Csv("Report", "Windows Security / Defender Status"));
            sb.AppendLine(Csv("Host", hostname));
            sb.AppendLine(Csv("Scan Time", scanTime.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture)));
            sb.AppendLine();

            sb.AppendLine(Csv("Defender Status", ""));
            sb.AppendLine(Csv("Antivirus Enabled", B(status.AntivirusEnabled)));
            sb.AppendLine(Csv("Real-Time Protection Enabled", B(status.RealTimeProtectionEnabled)));
            sb.AppendLine(Csv("Tamper Protection Enabled", B(status.IsTamperProtected)));
            sb.AppendLine(Csv("Behavior Monitor Enabled", B(status.BehaviorMonitorEnabled)));
            sb.AppendLine(Csv("AM Engine Version", status.AMEngineVersion));
            sb.AppendLine(Csv("Antivirus Signature Version", status.AntivirusSignatureVersion));
            sb.AppendLine(Csv("Last Signature Update", D(status.AntivirusSignatureLastUpdated)));
            sb.AppendLine(Csv("Last Quick Scan", D(status.QuickScanEndTime)));
            sb.AppendLine(Csv("Last Full Scan", D(status.FullScanEndTime)));
            sb.AppendLine(Csv("Computer State", status.ComputerState));
            sb.AppendLine();

            sb.AppendLine(Csv("App & Browser Control", ""));
            sb.AppendLine(Csv("SmartScreen (apps & files)", status.SmartScreenAppsFilesStatus));
            sb.AppendLine(Csv("SmartScreen (Microsoft Edge)", status.SmartScreenEdgeStatus));
            sb.AppendLine(Csv("Exploit Protection", status.ExploitProtectionSummary));
            sb.AppendLine();

            sb.AppendLine(Csv("Device Security", ""));
            sb.AppendLine(Csv("Memory Integrity (Core Isolation) Enabled", B(status.MemoryIntegrityEnabled)));
            sb.AppendLine(Csv("Secure Boot Enabled", B(status.SecureBootEnabled)));
            sb.AppendLine(Csv("TPM Present", B(status.TpmPresent)));
            sb.AppendLine(Csv("TPM Enabled", B(status.TpmEnabled)));
            sb.AppendLine(Csv("TPM Spec Version", status.TpmSpecVersion));
            sb.AppendLine();

            sb.AppendLine(Csv("Device Performance & Health", ""));
            sb.AppendLine(Csv("System Drive Free Space (GB)", status.SystemDriveFreeGB.ToString(CultureInfo.InvariantCulture)));
            sb.AppendLine(Csv("System Drive Free (%)", status.SystemDriveFreePercent.ToString(CultureInfo.InvariantCulture)));
            sb.AppendLine(Csv("Last Boot Time", D(status.LastBootUpTime)));
            sb.AppendLine();

            sb.AppendLine(Csv("Highlights (severity-ranked)", ""));
            sb.AppendLine(Csv("Severity", "Area", "Issue", "Recommendation"));
            foreach (var i in issues)
                sb.AppendLine(Csv(i.Severity, i.Area, i.Description, i.Recommendation));
            sb.AppendLine();

            sb.AppendLine(Csv("Threat Detections", ""));
            sb.AppendLine(Csv("Severity", "Threat Name", "Category", "Status", "Action Needed", "Detected", "Last Status Change", "Process", "Resources"));
            foreach (var t in threats)
                sb.AppendLine(Csv(t.Severity, t.ThreatName, t.Category, t.Status, t.ActionNeeded ? "Yes" : "No",
                    D(t.DetectionTime), D(t.LastStatusChangeTime), t.ProcessName, t.Resources));
            sb.AppendLine();

            sb.AppendLine(Csv("Protection History", ""));
            sb.AppendLine(Csv("Severity", "Time", "Event Id", "Category", "Level", "Message"));
            foreach (var e in history)
                sb.AppendLine(Csv(e.Severity, D(e.TimeCreated), e.EventId.ToString(CultureInfo.InvariantCulture), e.Category, e.Level, e.Message));

            return sb.ToString();
        }

        private static string B(bool? b) => b.HasValue ? (b.Value ? "Yes" : "No") : "Unavailable";
        private static string D(DateTime? d) => d.HasValue ? d.Value.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture) : "Unavailable";

        private static string Csv(params string?[] fields) => string.Join(",", fields.Select(Escape));

        private static string Escape(string? field)
        {
            field ??= "";
            bool needsQuoting = field.Contains(',') || field.Contains('"') || field.Contains('\n') || field.Contains('\r');
            if (!needsQuoting) return field;
            return "\"" + field.Replace("\"", "\"\"") + "\"";
        }
    }
}
