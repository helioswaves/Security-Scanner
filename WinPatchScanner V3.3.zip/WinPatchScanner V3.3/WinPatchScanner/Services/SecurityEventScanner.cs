using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using WinPatchScanner.Models;

namespace WinPatchScanner.Services
{
    public class SecurityEventScanResult
    {
        public List<SecurityEventInfo> Events { get; set; } = new();
        public List<SecurityFindingInfo> Findings { get; set; } = new();
        public int LookbackDays { get; set; }
    }

    /// <summary>
    /// Captures the Windows Security log plus a curated set of other
    /// investigation-relevant channels (System, PowerShell/Operational, RDP connection
    /// manager, Task Scheduler, Application) and correlates raw events into
    /// analyst-relevant findings - a brute-force/password-spray burst of failed logons,
    /// an audit log clear, an account added to a privileged group, a suspicious
    /// PowerShell script block.
    ///
    /// Only well-documented, high-confidence event IDs are given specific category
    /// labels and severity/urgency; every channel is queried independently so one
    /// channel being unavailable (feature not enabled, access denied, channel absent on
    /// this Windows edition) never blocks the others - it just contributes zero events.
    /// No administrator rights are required to read these channels on a normal Windows
    /// 10/11 install (the Security log's default ACL grants read to the built-in
    /// Event Log Readers group and interactive users).
    /// </summary>
    public class SecurityEventScanner
    {
        public event Action<string>? StatusChanged;

        private const int LookbackDays = 7;
        private const int MaxEventsPerChannel = 300;

        public SecurityEventScanResult Scan()
        {
            StatusChanged?.Invoke("Reading Windows Security log and related channels...");

            string encoded = Convert.ToBase64String(Encoding.Unicode.GetBytes(BuildScript()));

            var (exitCode, stdout, stderr) = RunCapture(
                "powershell.exe",
                $"-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand {encoded}",
                120_000);

            if (string.IsNullOrWhiteSpace(stdout))
            {
                throw new InvalidOperationException(
                    "Could not read Windows event logs (no output from PowerShell)." +
                    (string.IsNullOrWhiteSpace(stderr) ? $" Exit code {exitCode}." : " " + FirstLine(stderr)));
            }

            StatusChanged?.Invoke("Parsing and correlating events...");

            using var doc = JsonDocument.Parse(stdout);
            var events = ParseEvents(doc.RootElement);
            var findings = ComputeFindings(events);

            StatusChanged?.Invoke($"Security event scan complete. {events.Count} event(s), {findings.Count} finding(s).");

            return new SecurityEventScanResult { Events = events, Findings = findings, LookbackDays = LookbackDays };
        }

        private static string BuildScript() => $@"
$ErrorActionPreference = 'Stop'
try {{ [Console]::OutputEncoding = [Text.Encoding]::UTF8 }} catch {{ }}
$cutoff = (Get-Date).AddDays(-{LookbackDays})
$all = New-Object System.Collections.Generic.List[object]

function Add-Channel($channel, $ids) {{
    try {{
        $filter = @{{ LogName = $channel; StartTime = $cutoff }}
        if ($ids) {{ $filter.Id = $ids }}
        $evts = Get-WinEvent -FilterHashtable $filter -MaxEvents {MaxEventsPerChannel} -ErrorAction Stop
        foreach ($e in $evts) {{
            $all.Add([pscustomobject]@{{
                Channel = $channel
                TimeCreated = $e.TimeCreated
                Id = $e.Id
                LevelDisplayName = $e.LevelDisplayName
                Message = $e.Message
            }})
        }}
    }} catch {{ }}
}}

Add-Channel 'Security' @(4624,4625,4634,4647,4648,4672,4720,4722,4724,4725,4726,4728,4732,4738,4740,4756,4767,4771,4776,1102,4697)
Add-Channel 'System' @(7045)
Add-Channel 'Microsoft-Windows-PowerShell/Operational' @(4104,4103)
Add-Channel 'Microsoft-Windows-TerminalServices-RemoteConnectionManager/Operational' @(1149)
Add-Channel 'Microsoft-Windows-TaskScheduler/Operational' @(106)

try {{
    $appErrs = Get-WinEvent -FilterHashtable @{{ LogName='Application'; StartTime=$cutoff; Level=1,2 }} -MaxEvents 100 -ErrorAction Stop
    foreach ($e in $appErrs) {{
        $all.Add([pscustomobject]@{{
            Channel = 'Application'
            TimeCreated = $e.TimeCreated
            Id = $e.Id
            LevelDisplayName = $e.LevelDisplayName
            Message = $e.Message
        }})
    }}
}} catch {{ }}

$all | Select-Object Channel,TimeCreated,Id,LevelDisplayName,Message | ConvertTo-Json -Depth 4
";

        // ----- Known event IDs: category label + baseline severity/urgency -----
        // These are extremely well-documented, canonical Windows security event IDs.
        // Anything captured outside this table (a channel-level filter can still let an
        // unexpected ID through) falls back to a generic label with the native Level
        // deciding severity, rather than a guessed meaning.
        private record EventMeta(string Category, string Severity, string Urgency);

        private static readonly Dictionary<(string Channel, int Id), EventMeta> KnownEvents = new()
        {
            [("Security", 4624)] = new("Successful logon", "Low", "Low"),
            [("Security", 4625)] = new("Failed logon", "Medium", "Normal"),
            [("Security", 4634)] = new("Account logoff", "Info", "Low"),
            [("Security", 4647)] = new("User-initiated logoff", "Info", "Low"),
            [("Security", 4648)] = new("Logon using explicit credentials", "Medium", "Normal"),
            [("Security", 4672)] = new("Special privileges assigned to new logon", "Medium", "Normal"),
            [("Security", 4720)] = new("User account created", "Medium", "Normal"),
            [("Security", 4722)] = new("User account enabled", "Low", "Low"),
            [("Security", 4724)] = new("Password reset attempted", "Medium", "Normal"),
            [("Security", 4725)] = new("User account disabled", "Low", "Low"),
            [("Security", 4726)] = new("User account deleted", "Medium", "Normal"),
            [("Security", 4728)] = new("Member added to a security-enabled global group", "High", "High"),
            [("Security", 4732)] = new("Member added to a security-enabled local group", "High", "High"),
            [("Security", 4756)] = new("Member added to a security-enabled universal group", "High", "High"),
            [("Security", 4738)] = new("User account changed", "Low", "Low"),
            [("Security", 4740)] = new("Account locked out", "Medium", "Normal"),
            [("Security", 4767)] = new("Account unlocked", "Low", "Low"),
            [("Security", 4771)] = new("Kerberos pre-authentication failed", "Medium", "Normal"),
            [("Security", 4776)] = new("Credential validation attempted (NTLM)", "Medium", "Normal"),
            [("Security", 1102)] = new("Security audit log was cleared", "Critical", "Immediate"),
            [("Security", 4697)] = new("Service installed on the system", "Medium", "Normal"),
            [("System", 7045)] = new("Service installed on the system", "Medium", "Normal"),
            [("Microsoft-Windows-PowerShell/Operational", 4104)] = new("PowerShell script block logged", "Low", "Normal"),
            [("Microsoft-Windows-PowerShell/Operational", 4103)] = new("PowerShell module/pipeline logged", "Info", "Low"),
            [("Microsoft-Windows-TerminalServices-RemoteConnectionManager/Operational", 1149)] = new("RDP network connection", "Low", "Normal"),
            [("Microsoft-Windows-TaskScheduler/Operational", 106)] = new("Scheduled task registered", "Medium", "Normal"),
        };

        // Keywords that show up disproportionately in malicious PowerShell one-liners
        // and post-exploitation frameworks - a real, well-established detection
        // heuristic (not a claim of certainty; a match is a reason to look, not a verdict).
        private static readonly string[] SuspiciousPowerShellKeywords =
        {
            "-enc", "-encodedcommand", "invoke-expression", "iex ", "downloadstring",
            "downloadfile", "net.webclient", "invoke-mimikatz", "invoke-webrequest -uri",
            "frombase64string", "bypass", "hidden -windowstyle", "reflection.assembly",
            "start-bitstransfer", "invoke-shellcode", "invoke-reflectivepeinjection",
        };

        private static List<SecurityEventInfo> ParseEvents(JsonElement root)
        {
            var results = new List<SecurityEventInfo>();
            foreach (var e in AsArray(root))
            {
                string channel = GetString(e, "Channel");
                int id = GetInt(e, "Id") ?? 0;
                string level = GetString(e, "LevelDisplayName", "Information");
                string message = GetString(e, "Message");

                KnownEvents.TryGetValue((channel, id), out var meta);
                string category = meta?.Category ?? $"{channel} event {id}";
                string severity = meta?.Severity ?? LevelToSeverity(level);
                string urgency = meta?.Urgency ?? LevelToUrgency(level);

                // Escalate a PowerShell script-block event if the logged script text
                // contains a known-suspicious pattern.
                if (channel == "Microsoft-Windows-PowerShell/Operational" && id == 4104 &&
                    ContainsSuspiciousKeyword(message))
                {
                    severity = "Critical";
                    urgency = "Immediate";
                    category = "PowerShell script block - suspicious content";
                }

                results.Add(new SecurityEventInfo
                {
                    TimeCreated = GetDateTime(e, "TimeCreated"),
                    Channel = channel,
                    EventId = id,
                    Category = category,
                    Level = level,
                    Severity = severity,
                    Urgency = urgency,
                    Account = ExtractField(message, "Account Name"),
                    Source = FirstNonEmpty(
                        ExtractField(message, "Source Network Address"),
                        ExtractField(message, "Workstation Name")),
                    Message = Truncate(message, 500),
                });
            }

            return results.OrderByDescending(e => e.TimeCreated ?? DateTime.MinValue).ToList();
        }

        private static bool ContainsSuspiciousKeyword(string message)
        {
            string lower = message.ToLowerInvariant();
            return SuspiciousPowerShellKeywords.Any(k => lower.Contains(k));
        }

        private static string LevelToSeverity(string level) => level switch
        {
            "Critical" => "Critical",
            "Error" => "High",
            "Warning" => "Medium",
            _ => "Info",
        };

        private static string LevelToUrgency(string level) => level switch
        {
            "Critical" => "Immediate",
            "Error" => "High",
            "Warning" => "Normal",
            _ => "Low",
        };

        // Takes the LAST match of "<label>:" in a rendered event message. The standard
        // logon-event message template lists a "Subject" section (often the SYSTEM
        // account) before a "New Logon"/target section - the later occurrence is almost
        // always the more investigation-relevant one. Best-effort: returns "" if the
        // event's message template doesn't include this label at all.
        private static string ExtractField(string message, string label)
        {
            var matches = Regex.Matches(message, $@"(?m)^\s*{Regex.Escape(label)}:\s*(.+)$");
            if (matches.Count == 0) return "";
            string val = matches[^1].Groups[1].Value.Trim();
            return val is "-" or "" ? "" : val;
        }

        private static string FirstNonEmpty(params string[] values) =>
            values.FirstOrDefault(v => !string.IsNullOrWhiteSpace(v)) ?? "";

        private static List<SecurityFindingInfo> ComputeFindings(List<SecurityEventInfo> events)
        {
            var findings = new List<SecurityFindingInfo>();

            // Audit log cleared - always worth a standalone finding, one per occurrence.
            foreach (var e in events.Where(e => e.Channel == "Security" && e.EventId == 1102))
            {
                findings.Add(new SecurityFindingInfo
                {
                    Title = "Security audit log was cleared",
                    Severity = "Critical",
                    Urgency = "Immediate",
                    Description = $"The Security event log was cleared{(e.Account != "" ? $" by {e.Account}" : "")} at {DateText(e.TimeCreated)}. This is a classic anti-forensics action and erases the audit trail up to this point.",
                    Recommendation = "Investigate immediately - identify who cleared the log and why; check other machines/backups for the missing history.",
                    EventCount = 1,
                    FirstSeen = e.TimeCreated,
                    LastSeen = e.TimeCreated,
                });
            }

            // Brute-force / password-spray: many failed logons for the same account or
            // from the same source within the captured window.
            var failedLogons = events.Where(e => e.Channel == "Security" && e.EventId == 4625).ToList();
            foreach (var group in failedLogons.GroupBy(e => string.IsNullOrEmpty(e.Account) ? e.Source : e.Account))
            {
                if (string.IsNullOrEmpty(group.Key) || group.Count() < 5) continue;
                var ordered = group.OrderBy(e => e.TimeCreated).ToList();
                findings.Add(new SecurityFindingInfo
                {
                    Title = $"Possible brute-force / password-spray: {group.Key}",
                    Severity = group.Count() >= 10 ? "Critical" : "High",
                    Urgency = group.Count() >= 10 ? "Immediate" : "High",
                    Description = $"{group.Count()} failed logon attempts for \"{group.Key}\" between {DateText(ordered.First().TimeCreated)} and {DateText(ordered.Last().TimeCreated)}.",
                    Recommendation = "Confirm whether this account/source is expected. If not, lock the account, block the source, and review for successful logons around the same window.",
                    EventCount = group.Count(),
                    FirstSeen = ordered.First().TimeCreated,
                    LastSeen = ordered.Last().TimeCreated,
                });
            }

            // Privilege escalation: additions to a security-enabled group.
            var groupAdds = events.Where(e => e.Channel == "Security" && e.EventId is 4728 or 4732 or 4756).ToList();
            foreach (var group in groupAdds.GroupBy(e => e.Account))
            {
                if (string.IsNullOrEmpty(group.Key)) continue;
                var ordered = group.OrderBy(e => e.TimeCreated).ToList();
                findings.Add(new SecurityFindingInfo
                {
                    Title = $"Account added to a security group: {group.Key}",
                    Severity = "High",
                    Urgency = "High",
                    Description = $"\"{group.Key}\" was added to a security-enabled group {group.Count()} time(s) in the captured window (most recent: {DateText(ordered.Last().TimeCreated)}).",
                    Recommendation = "Confirm this membership change was authorized (change ticket / approval). Unexplained group membership changes are a common privilege-escalation indicator.",
                    EventCount = group.Count(),
                    FirstSeen = ordered.First().TimeCreated,
                    LastSeen = ordered.Last().TimeCreated,
                });
            }

            // Suspicious PowerShell script blocks - one finding per matching event (usually few).
            foreach (var e in events.Where(e => e.Category == "PowerShell script block - suspicious content"))
            {
                findings.Add(new SecurityFindingInfo
                {
                    Title = "Suspicious PowerShell script block logged",
                    Severity = "Critical",
                    Urgency = "Immediate",
                    Description = $"A logged PowerShell script block at {DateText(e.TimeCreated)} contains a pattern commonly seen in obfuscated/malicious scripts (encoded command, download cradle, reflection-based injection, or similar).",
                    Recommendation = "Review the full script block in Event Viewer (Applications and Services Logs > Microsoft > Windows > PowerShell > Operational, event 4104) and the process that ran it.",
                    EventCount = 1,
                    FirstSeen = e.TimeCreated,
                    LastSeen = e.TimeCreated,
                });
            }

            return findings.OrderBy(f => SeverityRank(f.Severity)).ThenByDescending(f => f.LastSeen ?? DateTime.MinValue).ToList();
        }

        private static int SeverityRank(string severity) => severity switch
        {
            "Critical" => 0,
            "High" => 1,
            "Medium" => 2,
            "Low" => 3,
            _ => 4,
        };

        private static string DateText(DateTime? d) => d.HasValue ? d.Value.ToString("yyyy-MM-dd HH:mm") : "unknown time";

        private static string Truncate(string s, int max) =>
            string.IsNullOrEmpty(s) || s.Length <= max ? s : s.Substring(0, max) + "…";

        // ----- JSON parsing helpers (defensive - a missing/renamed field is blank, never throws) -----

        private static JsonElement? Prop(JsonElement obj, string name)
        {
            if (obj.ValueKind == JsonValueKind.Object && obj.TryGetProperty(name, out var v) &&
                v.ValueKind != JsonValueKind.Undefined)
                return v;
            return null;
        }

        private static string GetString(JsonElement obj, string name, string fallback = "")
        {
            var v = Prop(obj, name);
            if (v is null) return fallback;
            var el = v.Value;
            return el.ValueKind switch
            {
                JsonValueKind.String => el.GetString() ?? fallback,
                JsonValueKind.Number => el.ToString(),
                _ => fallback,
            };
        }

        private static int? GetInt(JsonElement obj, string name)
        {
            var v = Prop(obj, name);
            if (v is null) return null;
            var el = v.Value;
            if (el.ValueKind == JsonValueKind.Number && el.TryGetInt32(out int n)) return n;
            if (el.ValueKind == JsonValueKind.String && int.TryParse(el.GetString(), out int n2)) return n2;
            return null;
        }

        private static DateTime? GetDateTime(JsonElement obj, string name)
        {
            var v = Prop(obj, name);
            if (v is null) return null;
            var el = v.Value;
            if (el.ValueKind != JsonValueKind.String) return null;
            string s = el.GetString() ?? "";
            if (string.IsNullOrWhiteSpace(s)) return null;
            if (DateTime.TryParse(s, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out var dt)) return dt;
            if (DateTime.TryParse(s, CultureInfo.InvariantCulture, DateTimeStyles.None, out var dt2)) return dt2;
            return null;
        }

        // Handles PowerShell's ConvertTo-Json quirk of collapsing a single-item array into
        // a bare object rather than a one-element JSON array (and a wholly empty result,
        // which serializes as JSON null).
        private static IEnumerable<JsonElement> AsArray(JsonElement root)
        {
            if (root.ValueKind == JsonValueKind.Array)
            {
                foreach (var item in root.EnumerateArray()) yield return item;
            }
            else if (root.ValueKind == JsonValueKind.Object)
            {
                yield return root;
            }
        }

        private static string FirstLine(string s)
        {
            int idx = s.IndexOfAny(new[] { '\r', '\n' });
            return idx > 0 ? s.Substring(0, idx) : s;
        }

        private static (int ExitCode, string StdOut, string StdErr) RunCapture(string fileName, string arguments, int timeoutMs)
        {
            var psi = new ProcessStartInfo
            {
                FileName = fileName,
                Arguments = arguments,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding = Encoding.UTF8,
            };

            using var process = new Process { StartInfo = psi };
            var stdout = new StringBuilder();
            var stderr = new StringBuilder();

            process.OutputDataReceived += (_, e) => { if (e.Data != null) stdout.AppendLine(e.Data); };
            process.ErrorDataReceived += (_, e) => { if (e.Data != null) stderr.AppendLine(e.Data); };

            process.Start();
            process.BeginOutputReadLine();
            process.BeginErrorReadLine();

            if (!process.WaitForExit(timeoutMs))
            {
                try { process.Kill(entireProcessTree: true); } catch { /* best effort */ }
                throw new TimeoutException($"PowerShell did not respond within {timeoutMs / 1000}s.");
            }

            return (process.ExitCode, stdout.ToString(), stderr.ToString());
        }
    }
}
