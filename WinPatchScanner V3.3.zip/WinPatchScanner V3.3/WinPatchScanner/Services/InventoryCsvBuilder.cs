using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using WinPatchScanner.Models;

namespace WinPatchScanner.Services
{
    /// <summary>CSV export for the installed-applications and services inventories.</summary>
    public static class InventoryCsvBuilder
    {
        public static string BuildApplications(string hostname, List<ApplicationInfo> apps, DateTime scanTime)
        {
            var sb = new StringBuilder();
            sb.AppendLine(Csv("Report", "Installed Applications"));
            sb.AppendLine(Csv("Host", hostname));
            sb.AppendLine(Csv("Scan Time", scanTime.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture)));
            sb.AppendLine(Csv("Total", apps.Count.ToString(CultureInfo.InvariantCulture)));
            sb.AppendLine();
            sb.AppendLine(Csv("Name", "Vendor Group", "Publisher", "Version", "Install Date", "Size (MB)", "Scope", "Architecture"));

            foreach (var a in apps.OrderBy(a => a.VendorGroup).ThenBy(a => a.Name, StringComparer.OrdinalIgnoreCase))
            {
                sb.AppendLine(Csv(a.Name, a.VendorGroup, a.Publisher, a.Version, a.InstallDate,
                    a.SizeMB.ToString(CultureInfo.InvariantCulture), a.InstallScope, a.Architecture));
            }

            return sb.ToString();
        }

        public static string BuildServices(string hostname, List<ServiceInfo> services, DateTime scanTime)
        {
            var sb = new StringBuilder();
            sb.AppendLine(Csv("Report", "Windows Services"));
            sb.AppendLine(Csv("Host", hostname));
            sb.AppendLine(Csv("Scan Time", scanTime.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture)));
            sb.AppendLine(Csv("Total", services.Count.ToString(CultureInfo.InvariantCulture)));
            sb.AppendLine();
            sb.AppendLine(Csv("Display Name", "Service Name", "Vendor Group", "Publisher", "State", "Start Mode", "Account", "Path"));

            foreach (var s in services.OrderBy(s => s.VendorGroup).ThenBy(s => s.DisplayName, StringComparer.OrdinalIgnoreCase))
            {
                sb.AppendLine(Csv(s.DisplayName, s.Name, s.VendorGroup, s.Publisher, s.State, s.StartMode, s.Account, s.PathName));
            }

            return sb.ToString();
        }

        public static string BuildAppUpdates(string hostname, List<AppUpdateInfo> updates, DateTime scanTime)
        {
            var sb = new StringBuilder();
            sb.AppendLine(Csv("Report", "Available Application Updates"));
            sb.AppendLine(Csv("Host", hostname));
            sb.AppendLine(Csv("Scan Time", scanTime.ToString("yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture)));
            sb.AppendLine(Csv("Total", updates.Count.ToString(CultureInfo.InvariantCulture)));
            sb.AppendLine();
            sb.AppendLine(Csv("Name", "Package Id", "Installed Version", "Available Version", "Source", "Upgrade Status", "Catalog Link"));

            foreach (var u in updates.OrderBy(u => u.Name, StringComparer.OrdinalIgnoreCase))
            {
                sb.AppendLine(Csv(u.Name, u.PackageId, u.InstalledVersion, u.AvailableVersion, u.Source, u.UpgradeStatus, u.CatalogUrl));
            }

            return sb.ToString();
        }

        private static string Csv(params string?[] fields) => string.Join(",", fields.Select(Escape));

        private static string Escape(string? field)
        {
            field ??= "";
            bool needsQuoting = field.Contains(',') || field.Contains('"') || field.Contains('\n') || field.Contains('\r');
            if (!needsQuoting) return field;
            return "\"" + field.Replace("\"", "\"\"") + "\"";
        }
    }
}
