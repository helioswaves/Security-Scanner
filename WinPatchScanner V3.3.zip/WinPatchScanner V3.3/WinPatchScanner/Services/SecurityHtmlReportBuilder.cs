using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using WinPatchScanner.Models;

namespace WinPatchScanner.Services
{
    /// <summary>Builds a standalone, dark-HUD styled HTML report covering Microsoft
    /// Defender / Windows Security status - the report-side counterpart to the
    /// dashboard's Security Center tab.</summary>
    public static class SecurityHtmlReportBuilder
    {
        public static string Build(string hostname, string osCaption, string osBuild, DefenderStatusInfo status,
            List<ThreatDetectionInfo> threats, List<ProtectionEventInfo> history, List<SecurityIssueInfo> issues,
            DateTime scanTime)
        {
            string overallSeverity = issues.Count > 0 ? issues[0].Severity : "Low";
            string overallLabel = issues.Count == 0
                ? "No issues flagged"
                : $"{issues.Count} issue(s) flagged · highest: {overallSeverity}";
            int pendingThreats = threats.Count(t => t.ActionNeeded);

            var sb = new StringBuilder();
            sb.Append($@"<!DOCTYPE html>
<html lang=""en"">
<head>
<meta charset=""UTF-8"">
<title>Security Status Report - {Enc(hostname)}</title>
<style>
  :root {{
    --bg:#0A0E14; --panel:#10161F; --panel-alt:#151C27; --border:#243040;
    --cyan:#38E1FF; --green:#3DFFA0; --amber:#FFB03B; --red:#FF4D5E;
    --text:#C9D6E3; --muted:#7A8896;
  }}
  * {{ box-sizing:border-box; }}
  body {{
    background:var(--bg); color:var(--text); margin:0; padding:32px;
    font-family:Consolas,'Courier New',monospace;
  }}
  .header {{
    display:flex; justify-content:space-between; align-items:flex-start;
    border-bottom:1px solid var(--border); padding-bottom:16px; margin-bottom:24px;
  }}
  h1 {{ color:var(--cyan); font-size:20px; letter-spacing:2px; margin:0 0 6px 0; text-transform:uppercase; }}
  h2 {{ color:var(--cyan); font-size:14px; letter-spacing:1px; text-transform:uppercase; margin:28px 0 12px 0; }}
  .meta {{ color:var(--muted); font-size:12px; line-height:1.7; }}
  .meta b {{ color:var(--text); }}
  .top-row {{ display:flex; gap:16px; margin-bottom:24px; align-items:stretch; flex-wrap:wrap; }}
  .risk-panel {{
    background:var(--panel); border:1px solid var(--border); border-radius:4px;
    padding:16px 24px; display:flex; align-items:center; gap:20px; min-width:280px;
  }}
  .risk-number {{ font-size:30px; font-weight:bold; line-height:1; }}
  .risk-meta .label {{ color:var(--muted); font-size:10px; letter-spacing:1px; text-transform:uppercase; margin-bottom:4px; }}
  .risk-meta .desc {{ font-size:13px; font-weight:bold; }}
  .risk-meta .sub {{ font-size:11px; color:var(--muted); margin-top:4px; }}
  .r-critical {{ color:var(--red); }}
  .r-high {{ color:var(--amber); }}
  .r-medium {{ color:var(--cyan); }}
  .r-low {{ color:var(--green); }}
  .r-info {{ color:var(--muted); }}
  .cards {{ display:flex; gap:12px; flex-wrap:wrap; flex:1; }}
  .card {{
    background:var(--panel); border:1px solid var(--border); border-radius:4px;
    padding:14px 18px; min-width:130px;
  }}
  .card .label {{ color:var(--muted); font-size:10px; letter-spacing:1px; text-transform:uppercase; }}
  .card .value {{ font-size:20px; font-weight:bold; margin-top:6px; }}
  .v-ok .value {{ color:var(--green); }}
  .v-bad .value {{ color:var(--red); }}
  .v-neutral .value {{ color:var(--text); }}
  table {{ width:100%; border-collapse:collapse; background:var(--panel); border:1px solid var(--border); border-radius:4px; overflow:hidden; }}
  th {{
    background:var(--panel-alt); color:var(--muted); text-align:left; font-size:10px;
    letter-spacing:1px; text-transform:uppercase; padding:10px 12px; border-bottom:1px solid var(--border);
  }}
  td {{ padding:9px 12px; font-size:12px; border-bottom:1px solid var(--border); vertical-align:top; }}
  tr:last-child td {{ border-bottom:none; }}
  tr:hover td {{ background:#1C2733; }}
  .badge {{
    display:inline-block; padding:2px 8px; border-radius:10px; font-size:10px; font-weight:bold;
    letter-spacing:0.5px; text-transform:uppercase; white-space:nowrap;
  }}
  .b-critical {{ background:rgba(255,77,94,0.15); color:var(--red); border:1px solid var(--red); }}
  .b-high {{ background:rgba(255,176,59,0.15); color:var(--amber); border:1px solid var(--amber); }}
  .b-medium {{ background:rgba(56,225,255,0.15); color:var(--cyan); border:1px solid var(--cyan); }}
  .b-low {{ background:rgba(61,255,160,0.15); color:var(--green); border:1px solid var(--green); }}
  .b-info, .b-unknown {{ background:rgba(122,136,150,0.15); color:var(--muted); border:1px solid var(--muted); }}
  .empty {{ text-align:center; color:var(--muted); padding:32px; }}
  footer {{ margin-top:24px; color:var(--muted); font-size:10px; text-align:center; letter-spacing:1px; }}
  .disclaimer {{ margin-top:8px; color:var(--muted); font-size:10px; text-align:center; }}
  .copyright {{ margin-top:4px; color:var(--muted); font-size:10px; text-align:center; letter-spacing:0.5px; }}
  .brand-logo {{ margin-left:auto; margin-bottom:8px; }}
</style>
</head>
<body>

<div class=""header"">
  <div>
    <h1>&#9679; Windows Security Status Report</h1>
    <div class=""meta"">
      <div>Host: <b>{Enc(hostname)}</b></div>
      <div>OS: <b>{Enc(osCaption)}</b> (Build {Enc(osBuild)})</div>
    </div>
  </div>
  <div style=""text-align:right"">
    {ReportBranding.LogoImgHtml(28)}
    <div class=""meta"" style=""text-align:right"">
      <div>Scan time</div>
      <div><b>{scanTime:yyyy-MM-dd HH:mm:ss}</b></div>
    </div>
  </div>
</div>

<div class=""top-row"">
  <div class=""risk-panel"">
    <div class=""risk-number {RiskClass(overallSeverity)}"">{Enc(overallSeverity)}</div>
    <div class=""risk-meta"">
      <div class=""label"">Overall Severity Highlight</div>
      <div class=""desc {RiskClass(overallSeverity)}"">{Enc(overallLabel)}</div>
      <div class=""sub"">{threats.Count} threat detection(s) in history · {pendingThreats} needing action</div>
    </div>
  </div>

  <div class=""cards"">
    <div class=""card {(status.AntivirusEnabled == true ? "v-ok" : "v-bad")}""><div class=""label"">Antivirus</div><div class=""value"">{YesNo(status.AntivirusEnabled)}</div></div>
    <div class=""card {(status.RealTimeProtectionEnabled == true ? "v-ok" : "v-bad")}""><div class=""label"">Real-Time Protection</div><div class=""value"">{YesNo(status.RealTimeProtectionEnabled)}</div></div>
    <div class=""card v-neutral""><div class=""label"">Signature Age</div><div class=""value"" style=""font-size:16px"">{AgeText(status.SignatureAgeDays)}</div></div>
    <div class=""card v-neutral""><div class=""label"">Last Full Scan</div><div class=""value"" style=""font-size:16px"">{DateText(status.FullScanEndTime)}</div></div>
    <div class=""card v-neutral""><div class=""label"">Last Quick Scan</div><div class=""value"" style=""font-size:16px"">{DateText(status.QuickScanEndTime)}</div></div>
  </div>
</div>

<h2>Highlights (severity-ranked)</h2>
<table>
  <thead><tr><th style=""width:90px"">Severity</th><th style=""width:160px"">Area</th><th>Issue</th><th>Recommendation</th></tr></thead>
  <tbody>
");
            if (issues.Count == 0)
            {
                sb.Append(@"<tr><td colspan=""4"" class=""empty"">No issues flagged - Defender, device security and performance checks all came back clean.</td></tr>");
            }
            else
            {
                foreach (var i in issues)
                {
                    sb.Append($@"
    <tr>
      <td><span class=""badge {BadgeClass(i.Severity)}"">{Enc(i.Severity)}</span></td>
      <td>{Enc(i.Area)}</td>
      <td>{Enc(i.Description)}</td>
      <td>{Enc(i.Recommendation)}</td>
    </tr>");
                }
            }
            sb.Append(@"
  </tbody>
</table>
");

            sb.Append($@"
<h2>Defender Status</h2>
<div class=""cards"">
  <div class=""card v-neutral""><div class=""label"">Antispyware</div><div class=""value"" style=""font-size:16px"">{YesNo(status.AntispywareEnabled)}</div></div>
  <div class=""card v-neutral""><div class=""label"">Behavior Monitor</div><div class=""value"" style=""font-size:16px"">{YesNo(status.BehaviorMonitorEnabled)}</div></div>
  <div class=""card v-neutral""><div class=""label"">Tamper Protection</div><div class=""value"" style=""font-size:16px"">{YesNo(status.IsTamperProtected)}</div></div>
  <div class=""card v-neutral""><div class=""label"">Engine Version</div><div class=""value"" style=""font-size:14px"">{Enc(NA(status.AMEngineVersion))}</div></div>
  <div class=""card v-neutral""><div class=""label"">Signature Version</div><div class=""value"" style=""font-size:14px"">{Enc(NA(status.AntivirusSignatureVersion))}</div></div>
  <div class=""card v-neutral""><div class=""label"">Computer State</div><div class=""value"" style=""font-size:14px"">{Enc(NA(status.ComputerState))}</div></div>
</div>

<h2>App &amp; Browser Control</h2>
<div class=""cards"">
  <div class=""card v-neutral""><div class=""label"">SmartScreen (apps &amp; files)</div><div class=""value"" style=""font-size:14px"">{Enc(status.SmartScreenAppsFilesStatus)}</div></div>
  <div class=""card v-neutral""><div class=""label"">SmartScreen (Edge)</div><div class=""value"" style=""font-size:14px"">{Enc(status.SmartScreenEdgeStatus)}</div></div>
  <div class=""card v-neutral""><div class=""label"">Exploit Protection</div><div class=""value"" style=""font-size:13px"">{Enc(status.ExploitProtectionSummary)}</div></div>
</div>

<h2>Device Security</h2>
<div class=""cards"">
  <div class=""card v-neutral""><div class=""label"">Memory Integrity</div><div class=""value"" style=""font-size:16px"">{YesNo(status.MemoryIntegrityEnabled)}</div></div>
  <div class=""card v-neutral""><div class=""label"">Secure Boot</div><div class=""value"" style=""font-size:16px"">{YesNo(status.SecureBootEnabled)}</div></div>
  <div class=""card v-neutral""><div class=""label"">TPM Present</div><div class=""value"" style=""font-size:16px"">{YesNo(status.TpmPresent)}</div></div>
  <div class=""card v-neutral""><div class=""label"">TPM Enabled</div><div class=""value"" style=""font-size:16px"">{YesNo(status.TpmEnabled)}</div></div>
  <div class=""card v-neutral""><div class=""label"">TPM Spec Version</div><div class=""value"" style=""font-size:14px"">{Enc(NA(status.TpmSpecVersion))}</div></div>
</div>

<h2>Device Performance &amp; Health <span style=""font-size:10px;color:var(--muted);text-transform:none;letter-spacing:0"">(best-effort - storage &amp; uptime)</span></h2>
<div class=""cards"">
  <div class=""card {(status.SystemDriveFreePercent < 10 ? "v-bad" : "v-ok")}""><div class=""label"">System Drive Free</div><div class=""value"" style=""font-size:16px"">{status.SystemDriveFreeGB:0.#} GB ({status.SystemDriveFreePercent:0.#}%)</div></div>
  <div class=""card v-neutral""><div class=""label"">Last Boot</div><div class=""value"" style=""font-size:14px"">{DateText(status.LastBootUpTime)}</div></div>
</div>

<h2>Threat Detections</h2>
<table>
  <thead>
    <tr>
      <th style=""width:90px"">Severity</th><th>Threat</th><th style=""width:130px"">Status</th>
      <th style=""width:90px"">Action</th><th style=""width:110px"">Detected</th><th>Process / Resource</th>
    </tr>
  </thead>
  <tbody>
");
            if (threats.Count == 0)
            {
                sb.Append(@"<tr><td colspan=""6"" class=""empty"">No threat detections in Defender's history.</td></tr>");
            }
            else
            {
                foreach (var t in threats)
                {
                    sb.Append($@"
    <tr>
      <td><span class=""badge {BadgeClass(t.Severity)}"">{Enc(t.Severity)}</span></td>
      <td>{Enc(t.ThreatName)}</td>
      <td>{Enc(t.Status)}</td>
      <td>{(t.ActionNeeded ? "<span class=\"badge b-critical\">Needed</span>" : "<span class=\"badge b-low\">None</span>")}</td>
      <td>{DateText(t.DetectionTime)}</td>
      <td>{Enc(t.ProcessName)} {Enc(t.Resources)}</td>
    </tr>");
                }
            }
            sb.Append(@"
  </tbody>
</table>
");

            sb.Append($@"
<h2>Protection History <span style=""font-size:10px;color:var(--muted);text-transform:none;letter-spacing:0"">(most recent {history.Count} event(s))</span></h2>
<table>
  <thead><tr><th style=""width:90px"">Severity</th><th style=""width:140px"">Time</th><th style=""width:220px"">Category</th><th>Message</th></tr></thead>
  <tbody>
");
            if (history.Count == 0)
            {
                sb.Append(@"<tr><td colspan=""4"" class=""empty"">No protection history events found (or the Defender operational log isn't accessible on this PC).</td></tr>");
            }
            else
            {
                foreach (var e in history)
                {
                    sb.Append($@"
    <tr>
      <td><span class=""badge {BadgeClass(e.Severity)}"">{Enc(e.Severity)}</span></td>
      <td>{DateText(e.TimeCreated)}</td>
      <td>{Enc(e.Category)} <span style=""color:var(--muted)"">(ID {e.EventId})</span></td>
      <td>{Enc(e.Message)}</td>
    </tr>");
                }
            }

            sb.Append($@"
  </tbody>
</table>

<div class=""disclaimer"">Severity for threat detections uses Microsoft's published SeverityID scale (Low/Moderate/High/Severe). Protection history severity is derived from the event's own Windows level plus a best-effort category lookup for well-known Defender event IDs - treat this report as a strong starting point, not a replacement for reviewing Windows Security directly.</div>
<footer>GENERATED BY WIN PATCH SCANNER &middot; {scanTime:yyyy-MM-dd HH:mm:ss}</footer>
<div class=""copyright"">{Enc(ReportBranding.CopyrightText)}</div>

</body>
</html>");

            return sb.ToString();
        }

        private static string RiskClass(string severity) => severity switch
        {
            "Critical" => "r-critical",
            "High" => "r-high",
            "Medium" => "r-medium",
            "Low" => "r-low",
            _ => "r-info",
        };

        private static string BadgeClass(string severity) => severity switch
        {
            "Critical" => "b-critical",
            "High" => "b-high",
            "Medium" => "b-medium",
            "Low" => "b-low",
            _ => "b-info",
        };

        private static string YesNo(bool? b) => b.HasValue ? (b.Value ? "Yes" : "No") : "N/A";
        private static string NA(string s) => string.IsNullOrWhiteSpace(s) ? "N/A" : s;
        private static string DateText(DateTime? d) => d.HasValue ? d.Value.ToString("yyyy-MM-dd HH:mm") : "N/A";
        private static string AgeText(double days) => days < 0 ? "N/A" : $"{days:0} day(s)";

        private static string Enc(string? s) => WebUtility.HtmlEncode(s ?? "");
    }
}
