using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using WinPatchScanner.Models;

namespace WinPatchScanner.Services
{
    /// <summary>Builds a standalone, dark-HUD styled HTML report covering the Security
    /// Events tab's investigation findings and captured events - the report-side
    /// counterpart to the dashboard.</summary>
    public static class SecurityEventHtmlReportBuilder
    {
        public static string Build(string hostname, string osCaption, string osBuild,
            List<SecurityEventInfo> events, List<SecurityFindingInfo> findings, int lookbackDays, DateTime scanTime)
        {
            string overallSeverity = findings.Count > 0 ? findings[0].Severity : "Low";
            string overallLabel = findings.Count == 0
                ? "No findings - nothing correlated stands out"
                : $"{findings.Count} finding(s) · highest: {overallSeverity}";

            int critical = events.Count(e => e.Severity == "Critical");
            int high = events.Count(e => e.Severity == "High");
            int medium = events.Count(e => e.Severity == "Medium");

            var sb = new StringBuilder();
            sb.Append($@"<!DOCTYPE html>
<html lang=""en"">
<head>
<meta charset=""UTF-8"">
<title>Security Events Report - {Enc(hostname)}</title>
<style>
  :root {{
    --bg:#0A0E14; --panel:#10161F; --panel-alt:#151C27; --border:#243040;
    --cyan:#38E1FF; --green:#3DFFA0; --amber:#FFB03B; --red:#FF4D5E;
    --text:#C9D6E3; --muted:#7A8896;
  }}
  * {{ box-sizing:border-box; }}
  body {{
    background:var(--bg); color:var(--text); margin:0; padding:32px;
    font-family:Consolas,'Courier New',monospace;
  }}
  .header {{
    display:flex; justify-content:space-between; align-items:flex-start;
    border-bottom:1px solid var(--border); padding-bottom:16px; margin-bottom:24px;
  }}
  h1 {{ color:var(--cyan); font-size:20px; letter-spacing:2px; margin:0 0 6px 0; text-transform:uppercase; }}
  h2 {{ color:var(--cyan); font-size:14px; letter-spacing:1px; text-transform:uppercase; margin:28px 0 12px 0; }}
  .meta {{ color:var(--muted); font-size:12px; line-height:1.7; }}
  .meta b {{ color:var(--text); }}
  .top-row {{ display:flex; gap:16px; margin-bottom:24px; align-items:stretch; flex-wrap:wrap; }}
  .risk-panel {{
    background:var(--panel); border:1px solid var(--border); border-radius:4px;
    padding:16px 24px; display:flex; align-items:center; gap:20px; min-width:280px;
  }}
  .risk-number {{ font-size:30px; font-weight:bold; line-height:1; }}
  .risk-meta .label {{ color:var(--muted); font-size:10px; letter-spacing:1px; text-transform:uppercase; margin-bottom:4px; }}
  .risk-meta .desc {{ font-size:13px; font-weight:bold; }}
  .risk-meta .sub {{ font-size:11px; color:var(--muted); margin-top:4px; }}
  .r-critical {{ color:var(--red); }}
  .r-high {{ color:var(--amber); }}
  .r-medium {{ color:var(--cyan); }}
  .r-low {{ color:var(--green); }}
  .r-info {{ color:var(--muted); }}
  .cards {{ display:flex; gap:12px; flex-wrap:wrap; flex:1; }}
  .card {{
    background:var(--panel); border:1px solid var(--border); border-radius:4px;
    padding:14px 18px; min-width:110px;
  }}
  .card .label {{ color:var(--muted); font-size:10px; letter-spacing:1px; text-transform:uppercase; }}
  .card .value {{ font-size:24px; font-weight:bold; margin-top:6px; }}
  .c-total .value {{ color:var(--text); }}
  .c-critical .value {{ color:var(--red); }}
  .c-high .value {{ color:var(--amber); }}
  .c-medium .value {{ color:var(--cyan); }}
  table {{ width:100%; border-collapse:collapse; background:var(--panel); border:1px solid var(--border); border-radius:4px; overflow:hidden; }}
  th {{
    background:var(--panel-alt); color:var(--muted); text-align:left; font-size:10px;
    letter-spacing:1px; text-transform:uppercase; padding:10px 12px; border-bottom:1px solid var(--border);
  }}
  td {{ padding:9px 12px; font-size:12px; border-bottom:1px solid var(--border); vertical-align:top; }}
  tr:last-child td {{ border-bottom:none; }}
  tr:hover td {{ background:#1C2733; }}
  .badge {{
    display:inline-block; padding:2px 8px; border-radius:10px; font-size:10px; font-weight:bold;
    letter-spacing:0.5px; text-transform:uppercase; white-space:nowrap;
  }}
  .b-critical, .b-immediate {{ background:rgba(255,77,94,0.15); color:var(--red); border:1px solid var(--red); }}
  .b-high {{ background:rgba(255,176,59,0.15); color:var(--amber); border:1px solid var(--amber); }}
  .b-medium, .b-normal {{ background:rgba(56,225,255,0.15); color:var(--cyan); border:1px solid var(--cyan); }}
  .b-low {{ background:rgba(61,255,160,0.15); color:var(--green); border:1px solid var(--green); }}
  .b-info, .b-unknown {{ background:rgba(122,136,150,0.15); color:var(--muted); border:1px solid var(--muted); }}
  .empty {{ text-align:center; color:var(--muted); padding:32px; }}
  footer {{ margin-top:24px; color:var(--muted); font-size:10px; text-align:center; letter-spacing:1px; }}
  .disclaimer {{ margin-top:8px; color:var(--muted); font-size:10px; text-align:center; }}
  .copyright {{ margin-top:4px; color:var(--muted); font-size:10px; text-align:center; letter-spacing:0.5px; }}
  .brand-logo {{ margin-left:auto; margin-bottom:8px; }}
</style>
</head>
<body>

<div class=""header"">
  <div>
    <h1>&#9679; Security Events Report</h1>
    <div class=""meta"">
      <div>Host: <b>{Enc(hostname)}</b></div>
      <div>OS: <b>{Enc(osCaption)}</b> (Build {Enc(osBuild)})</div>
      <div>Lookback window: <b>{lookbackDays} day(s)</b></div>
    </div>
  </div>
  <div style=""text-align:right"">
    {ReportBranding.LogoImgHtml(28)}
    <div class=""meta"" style=""text-align:right"">
      <div>Scan time</div>
      <div><b>{scanTime:yyyy-MM-dd HH:mm:ss}</b></div>
    </div>
  </div>
</div>

<div class=""top-row"">
  <div class=""risk-panel"">
    <div class=""risk-number {RiskClass(overallSeverity)}"">{Enc(overallSeverity)}</div>
    <div class=""risk-meta"">
      <div class=""label"">Investigation Summary</div>
      <div class=""desc {RiskClass(overallSeverity)}"">{Enc(overallLabel)}</div>
      <div class=""sub"">{events.Count} event(s) captured across Security, System, PowerShell, RDP, Task Scheduler and Application logs</div>
    </div>
  </div>

  <div class=""cards"">
    <div class=""card c-total""><div class=""label"">Events Captured</div><div class=""value"">{events.Count}</div></div>
    <div class=""card c-critical""><div class=""label"">Critical</div><div class=""value"">{critical}</div></div>
    <div class=""card c-high""><div class=""label"">High</div><div class=""value"">{high}</div></div>
    <div class=""card c-medium""><div class=""label"">Medium</div><div class=""value"">{medium}</div></div>
    <div class=""card c-total""><div class=""label"">Findings</div><div class=""value"">{findings.Count}</div></div>
  </div>
</div>

<h2>Investigation Findings</h2>
<table>
  <thead><tr><th style=""width:90px"">Severity</th><th style=""width:90px"">Urgency</th><th>Finding</th><th style=""width:130px"">First / Last Seen</th><th>Recommendation</th></tr></thead>
  <tbody>
");
            if (findings.Count == 0)
            {
                sb.Append(@"<tr><td colspan=""5"" class=""empty"">No correlated findings in this window - no audit-log clears, failed-logon bursts, privileged group changes, or suspicious PowerShell detected.</td></tr>");
            }
            else
            {
                foreach (var f in findings)
                {
                    sb.Append($@"
    <tr>
      <td><span class=""badge {BadgeClass(f.Severity)}"">{Enc(f.Severity)}</span></td>
      <td><span class=""badge {BadgeClass(f.Urgency)}"">{Enc(f.Urgency)}</span></td>
      <td><b>{Enc(f.Title)}</b><br/><span style=""color:var(--muted)"">{Enc(f.Description)}</span></td>
      <td>{DateText(f.FirstSeen)}<br/>{DateText(f.LastSeen)}</td>
      <td>{Enc(f.Recommendation)}</td>
    </tr>");
                }
            }
            sb.Append(@"
  </tbody>
</table>
");

            sb.Append($@"
<h2>Captured Events <span style=""font-size:10px;color:var(--muted);text-transform:none;letter-spacing:0"">({events.Count} event(s), most recent first)</span></h2>
<table>
  <thead>
    <tr>
      <th style=""width:80px"">Severity</th><th style=""width:80px"">Urgency</th><th style=""width:130px"">Time</th>
      <th style=""width:110px"">Channel</th><th>Category</th><th style=""width:140px"">Account / Source</th>
    </tr>
  </thead>
  <tbody>
");
            if (events.Count == 0)
            {
                sb.Append(@"<tr><td colspan=""6"" class=""empty"">No events captured in this window.</td></tr>");
            }
            else
            {
                foreach (var e in events)
                {
                    sb.Append($@"
    <tr>
      <td><span class=""badge {BadgeClass(e.Severity)}"">{Enc(e.Severity)}</span></td>
      <td><span class=""badge {BadgeClass(e.Urgency)}"">{Enc(e.Urgency)}</span></td>
      <td>{DateText(e.TimeCreated)}</td>
      <td>{Enc(e.Channel)}</td>
      <td>{Enc(e.Category)} <span style=""color:var(--muted)"">(ID {e.EventId})</span></td>
      <td>{Enc(e.Account)} {Enc(e.Source)}</td>
    </tr>");
                }
            }

            sb.Append($@"
  </tbody>
</table>

<div class=""disclaimer"">Only well-documented, canonical event IDs receive a specific category label and baseline severity/urgency; anything else falls back to the event's native Windows level. Findings are correlated from patterns in the captured events (repeated failures, group changes, log clears, flagged script content) and are a starting point for investigation, not a verdict.</div>
<footer>GENERATED BY WIN PATCH SCANNER &middot; {scanTime:yyyy-MM-dd HH:mm:ss}</footer>
<div class=""copyright"">{Enc(ReportBranding.CopyrightText)}</div>

</body>
</html>");

            return sb.ToString();
        }

        private static string RiskClass(string severity) => severity switch
        {
            "Critical" or "Immediate" => "r-critical",
            "High" => "r-high",
            "Medium" or "Normal" => "r-medium",
            "Low" => "r-low",
            _ => "r-info",
        };

        private static string BadgeClass(string severity) => severity switch
        {
            "Critical" => "b-critical",
            "Immediate" => "b-immediate",
            "High" => "b-high",
            "Medium" => "b-medium",
            "Normal" => "b-normal",
            "Low" => "b-low",
            _ => "b-info",
        };

        private static string DateText(DateTime? d) => d.HasValue ? d.Value.ToString("yyyy-MM-dd HH:mm") : "N/A";

        private static string Enc(string? s) => WebUtility.HtmlEncode(s ?? "");
    }
}
