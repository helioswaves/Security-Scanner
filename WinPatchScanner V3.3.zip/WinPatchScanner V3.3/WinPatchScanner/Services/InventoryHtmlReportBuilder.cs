using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using WinPatchScanner.Models;

namespace WinPatchScanner.Services
{
    /// <summary>
    /// Builds a standalone, dark-HUD styled HTML report covering installed applications,
    /// Windows services (each split Microsoft vs. Non-Microsoft), and any available
    /// application updates found via winget - the report-side counterpart to the
    /// dashboard's Installed Applications / Windows Services / Application Updates tabs.
    /// </summary>
    public static class InventoryHtmlReportBuilder
    {
        public static string Build(string hostname, string osCaption, string osBuild,
            List<ApplicationInfo> apps, List<ServiceInfo> services, DateTime scanTime,
            List<AppUpdateInfo>? updates = null)
        {
            updates ??= new List<AppUpdateInfo>();
            int appsTotal = apps.Count;
            int appsMs = apps.Count(a => a.IsMicrosoft);
            int appsNonMs = appsTotal - appsMs;
            double appsSizeMb = Math.Round(apps.Sum(a => a.SizeMB), 1);

            int svcTotal = services.Count;
            int svcRunning = services.Count(s => s.State == "Running");
            int svcStopped = svcTotal - svcRunning;
            int svcMs = services.Count(s => s.IsMicrosoft);
            int svcNonMs = svcTotal - svcMs;

            var sb = new StringBuilder();
            sb.Append($@"<!DOCTYPE html>
<html lang=""en"">
<head>
<meta charset=""UTF-8"">
<title>Applications, Services &amp; Updates Report - {Enc(hostname)}</title>
<style>
  :root {{
    --bg:#0A0E14; --panel:#10161F; --panel-alt:#151C27; --border:#243040;
    --cyan:#38E1FF; --green:#3DFFA0; --amber:#FFB03B; --red:#FF4D5E;
    --text:#C9D6E3; --muted:#7A8896;
  }}
  * {{ box-sizing:border-box; }}
  body {{
    background:var(--bg); color:var(--text); margin:0; padding:32px;
    font-family:Consolas,'Courier New',monospace;
  }}
  .header {{
    display:flex; justify-content:space-between; align-items:flex-start;
    border-bottom:1px solid var(--border); padding-bottom:16px; margin-bottom:24px;
  }}
  h1 {{ color:var(--cyan); font-size:20px; letter-spacing:2px; margin:0 0 6px 0; text-transform:uppercase; }}
  h2 {{ color:var(--cyan); font-size:14px; letter-spacing:1.5px; text-transform:uppercase; margin:36px 0 14px 0; }}
  .meta {{ color:var(--muted); font-size:12px; line-height:1.7; }}
  .meta b {{ color:var(--text); }}
  .cards {{ display:flex; gap:12px; flex-wrap:wrap; margin-bottom:16px; }}
  .card {{
    background:var(--panel); border:1px solid var(--border); border-radius:4px;
    padding:14px 18px; min-width:120px;
  }}
  .card .label {{ color:var(--muted); font-size:10px; letter-spacing:1px; text-transform:uppercase; }}
  .card .value {{ font-size:24px; font-weight:bold; margin-top:6px; }}
  .v-total .value {{ color:var(--text); }}
  .v-ms .value {{ color:var(--cyan); }}
  .v-nonms .value {{ color:var(--amber); }}
  .v-running .value {{ color:var(--green); }}
  .v-stopped .value {{ color:var(--muted); }}
  .v-size .value {{ color:var(--text); font-size:18px; }}
  .bar-wrap {{
    background:var(--panel); border:1px solid var(--border); border-radius:4px;
    padding:14px 18px; margin-bottom:24px;
  }}
  .bar-title {{ color:var(--muted); font-size:10px; letter-spacing:1px; text-transform:uppercase; margin-bottom:10px; }}
  .bar {{ display:flex; height:12px; border-radius:3px; overflow:hidden; background:var(--panel-alt); }}
  .bar div {{ height:100%; }}
  .seg-ms {{ background:var(--cyan); }}
  .seg-nonms {{ background:var(--amber); }}
  .legend {{ display:flex; gap:18px; margin-top:10px; font-size:11px; color:var(--muted); flex-wrap:wrap; }}
  .legend span.dot {{ display:inline-block; width:8px; height:8px; border-radius:50%; margin-right:5px; }}
  table {{ width:100%; border-collapse:collapse; background:var(--panel); border:1px solid var(--border); border-radius:4px; overflow:hidden; }}
  th {{
    background:var(--panel-alt); color:var(--muted); text-align:left; font-size:10px;
    letter-spacing:1px; text-transform:uppercase; padding:10px 12px; border-bottom:1px solid var(--border);
  }}
  td {{ padding:9px 12px; font-size:12px; border-bottom:1px solid var(--border); vertical-align:top; }}
  tr:last-child td {{ border-bottom:none; }}
  tr:hover td {{ background:#1C2733; }}
  .badge {{
    display:inline-block; padding:2px 8px; border-radius:10px; font-size:10px; font-weight:bold;
    letter-spacing:0.5px; text-transform:uppercase; white-space:nowrap;
  }}
  .b-ms {{ background:rgba(56,225,255,0.15); color:var(--cyan); border:1px solid var(--cyan); }}
  .b-nonms {{ background:rgba(255,176,59,0.15); color:var(--amber); border:1px solid var(--amber); }}
  .b-running {{ color:var(--green); }}
  .b-stopped {{ color:var(--muted); }}
  .cat-link {{ color:var(--cyan); text-decoration:none; border-bottom:1px dotted var(--cyan); white-space:nowrap; }}
  .cat-link:hover {{ color:var(--text); }}
  .empty {{ text-align:center; color:var(--muted); padding:40px; }}
  footer {{ margin-top:24px; color:var(--muted); font-size:10px; text-align:center; letter-spacing:1px; }}
  .disclaimer {{ margin-top:8px; color:var(--muted); font-size:10px; text-align:center; }}
  .copyright {{ margin-top:4px; color:var(--muted); font-size:10px; text-align:center; letter-spacing:0.5px; }}
  .brand-logo {{ margin-left:auto; margin-bottom:8px; }}
</style>
</head>
<body>

<div class=""header"">
  <div>
    <h1>&#9679; Applications, Services &amp; Updates Report</h1>
    <div class=""meta"">
      <div>Host: <b>{Enc(hostname)}</b></div>
      <div>OS: <b>{Enc(osCaption)}</b> (Build {Enc(osBuild)})</div>
    </div>
  </div>
  <div style=""text-align:right"">
    {ReportBranding.LogoImgHtml(28)}
    <div class=""meta"" style=""text-align:right"">
      <div>Scan time</div>
      <div><b>{scanTime:yyyy-MM-dd HH:mm:ss}</b></div>
    </div>
  </div>
</div>

<h2>Available Application Updates</h2>
<div class=""cards"">
  <div class=""card v-total""><div class=""label"">Updates Available</div><div class=""value"">{updates.Count}</div></div>
</div>
<table>
  <thead>
    <tr>
      <th>Application</th>
      <th style=""width:190px"">Package Id</th>
      <th style=""width:110px"">Installed</th>
      <th style=""width:110px"">Available</th>
      <th style=""width:90px"">Source</th>
      <th style=""width:120px"">Status</th>
      <th style=""width:90px"">Details</th>
    </tr>
  </thead>
  <tbody>
");
            if (updates.Count == 0)
            {
                sb.Append(@"<tr><td colspan=""7"" class=""empty"">No application updates found (or CHECK FOR UPDATES hasn't been run yet).</td></tr>");
            }
            else
            {
                foreach (var u in updates.OrderBy(u => u.Name, StringComparer.OrdinalIgnoreCase))
                {
                    string linkHtml = string.IsNullOrEmpty(u.CatalogUrl)
                        ? "<span style=\"color:var(--muted)\">n/a</span>"
                        : $@"<a class=""cat-link"" href=""{Enc(u.CatalogUrl)}"" target=""_blank"" rel=""noopener"">View &#8599;</a>";

                    sb.Append($@"
    <tr>
      <td>{Enc(u.Name)}</td>
      <td>{Enc(u.PackageId)}</td>
      <td>{Enc(u.InstalledVersion)}</td>
      <td>{Enc(u.AvailableVersion)}</td>
      <td>{Enc(u.Source)}</td>
      <td>{Enc(u.UpgradeStatus)}</td>
      <td>{linkHtml}</td>
    </tr>");
                }
            }
            sb.Append($@"
  </tbody>
</table>

<h2>Installed Applications</h2>
<div class=""cards"">
  <div class=""card v-total""><div class=""label"">Total Installed</div><div class=""value"">{appsTotal}</div></div>
  <div class=""card v-ms""><div class=""label"">Microsoft</div><div class=""value"">{appsMs}</div></div>
  <div class=""card v-nonms""><div class=""label"">Non-Microsoft</div><div class=""value"">{appsNonMs}</div></div>
  <div class=""card v-size""><div class=""label"">Total Disk Use</div><div class=""value"">{appsSizeMb} MB</div></div>
</div>
");
            if (appsTotal > 0)
            {
                double pctMs = Math.Round(100.0 * appsMs / appsTotal, 1);
                double pctNonMs = Math.Round(100.0 * appsNonMs / appsTotal, 1);
                sb.Append($@"
<div class=""bar-wrap"">
  <div class=""bar-title"">Vendor Split</div>
  <div class=""bar"">
    <div class=""seg-ms"" style=""width:{pctMs}%""></div>
    <div class=""seg-nonms"" style=""width:{pctNonMs}%""></div>
  </div>
  <div class=""legend"">
    <div><span class=""dot"" style=""background:var(--cyan)""></span>Microsoft ({appsMs})</div>
    <div><span class=""dot"" style=""background:var(--amber)""></span>Non-Microsoft ({appsNonMs})</div>
  </div>
</div>
");
            }

            sb.Append(@"
<table>
  <thead>
    <tr>
      <th style=""width:100px"">Vendor</th>
      <th>Name</th>
      <th style=""width:190px"">Publisher</th>
      <th style=""width:90px"">Version</th>
      <th style=""width:90px"">Installed</th>
      <th style=""width:80px"">Size</th>
      <th style=""width:150px"">Scope</th>
      <th style=""width:70px"">Arch</th>
    </tr>
  </thead>
  <tbody>
");
            if (appsTotal == 0)
            {
                sb.Append(@"<tr><td colspan=""8"" class=""empty"">No applications detected. Run DETECT APPS &amp; SERVICES first.</td></tr>");
            }
            else
            {
                foreach (var a in apps.OrderBy(a => a.VendorGroup).ThenBy(a => a.Name, StringComparer.OrdinalIgnoreCase))
                {
                    string badgeClass = a.IsMicrosoft ? "b-ms" : "b-nonms";
                    sb.Append($@"
    <tr>
      <td><span class=""badge {badgeClass}"">{Enc(a.VendorGroup)}</span></td>
      <td>{Enc(a.Name)}</td>
      <td>{Enc(a.Publisher)}</td>
      <td>{Enc(a.Version)}</td>
      <td>{Enc(a.InstallDate)}</td>
      <td>{a.SizeMB} MB</td>
      <td>{Enc(a.InstallScope)}</td>
      <td>{Enc(a.Architecture)}</td>
    </tr>");
                }
            }
            sb.Append(@"
  </tbody>
</table>
");

            sb.Append($@"
<h2>Windows Services</h2>
<div class=""cards"">
  <div class=""card v-total""><div class=""label"">Total Services</div><div class=""value"">{svcTotal}</div></div>
  <div class=""card v-running""><div class=""label"">Running</div><div class=""value"">{svcRunning}</div></div>
  <div class=""card v-stopped""><div class=""label"">Stopped</div><div class=""value"">{svcStopped}</div></div>
  <div class=""card v-ms""><div class=""label"">Microsoft</div><div class=""value"">{svcMs}</div></div>
  <div class=""card v-nonms""><div class=""label"">Non-Microsoft</div><div class=""value"">{svcNonMs}</div></div>
</div>
");
            if (svcTotal > 0)
            {
                double pctMs = Math.Round(100.0 * svcMs / svcTotal, 1);
                double pctNonMs = Math.Round(100.0 * svcNonMs / svcTotal, 1);
                sb.Append($@"
<div class=""bar-wrap"">
  <div class=""bar-title"">Vendor Split</div>
  <div class=""bar"">
    <div class=""seg-ms"" style=""width:{pctMs}%""></div>
    <div class=""seg-nonms"" style=""width:{pctNonMs}%""></div>
  </div>
  <div class=""legend"">
    <div><span class=""dot"" style=""background:var(--cyan)""></span>Microsoft ({svcMs})</div>
    <div><span class=""dot"" style=""background:var(--amber)""></span>Non-Microsoft ({svcNonMs})</div>
  </div>
</div>
");
            }

            sb.Append(@"
<table>
  <thead>
    <tr>
      <th style=""width:100px"">Vendor</th>
      <th>Display Name</th>
      <th style=""width:160px"">Service Name</th>
      <th style=""width:170px"">Publisher</th>
      <th style=""width:80px"">State</th>
      <th style=""width:90px"">Start Mode</th>
      <th style=""width:160px"">Account</th>
    </tr>
  </thead>
  <tbody>
");
            if (svcTotal == 0)
            {
                sb.Append(@"<tr><td colspan=""7"" class=""empty"">No services detected. Run DETECT APPS &amp; SERVICES first.</td></tr>");
            }
            else
            {
                foreach (var s in services.OrderBy(s => s.VendorGroup).ThenBy(s => s.DisplayName, StringComparer.OrdinalIgnoreCase))
                {
                    string badgeClass = s.IsMicrosoft ? "b-ms" : "b-nonms";
                    string stateClass = s.State == "Running" ? "b-running" : "b-stopped";
                    sb.Append($@"
    <tr>
      <td><span class=""badge {badgeClass}"">{Enc(s.VendorGroup)}</span></td>
      <td>{Enc(s.DisplayName)}</td>
      <td>{Enc(s.Name)}</td>
      <td>{Enc(s.Publisher)}</td>
      <td class=""{stateClass}"">{Enc(s.State)}</td>
      <td>{Enc(s.StartMode)}</td>
      <td>{Enc(s.Account)}</td>
    </tr>");
                }
            }

            sb.Append($@"
  </tbody>
</table>

<div class=""disclaimer"">Vendor classification: applications by registry Publisher; services by binary file metadata, falling back to install path under System32/SysWOW64. Treat as a strong starting split, not a definitive vendor audit. Application updates are sourced from winget (Windows Package Manager) and reflect what winget's configured sources report as newer than the installed version.</div>
<footer>GENERATED BY WIN PATCH SCANNER &middot; {scanTime:yyyy-MM-dd HH:mm:ss}</footer>
<div class=""copyright"">{Enc(ReportBranding.CopyrightText)}</div>

</body>
</html>");

            return sb.ToString();
        }

        private static string Enc(string? s) => WebUtility.HtmlEncode(s ?? "");
    }
}
